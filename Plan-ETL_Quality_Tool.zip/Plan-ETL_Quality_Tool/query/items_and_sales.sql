SELECT A.Wm_Yr_Wk,
CURRENT_DATE AS ISD_LoadDate_Time,
C.Brand_Family_Name,  
B.BRAND_ID,
C.Brand_Name, 
B.Dept_Nbr, 
E.DEPT_DESC,
E.DEPT_CATEGORY_NBR AS Category_No,
E.DEPT_CATEGORY_DESC, 
E.DEPT_SUBCATG_NBR,
B.FINELINE_NBR, 
E.FineLine_Desc,
B.ITEM1_DESC, 
B.ITEM2_DESC, 
B.UPC_NBR,
B.UPC_DESC,
B.SIGNING_DESC,
B.VENDOR_NBR AS Vendor_ID, 
--Import_Supplier_ID, 
A.Item_Nbr,  
G.MFG_COMPANY_ID AS Factory_ID,
A.POS_Sales,
F.TotWklySales AS TotPOSSales, 
A.POS_Qty,  
F.TotWklyQty AS TotPOSQty, 
H.Customer_Defective_Return_$, 
H.Customer_Defective_Return_QTY,
J.Total_Customer_Return_$, 
J.Total_Customer_Return_QTY,
k.Available_In_Store,

CASE WHEN A.POS_Qty<>0 THEN (J.Total_Customer_Return_QTY/A.POS_Qty) ELSE 0 END AS Calc_CRR,
CASE WHEN A.POS_Qty<>0 THEN (H.Customer_Defective_Return_QTY/A.POS_Qty) ELSE 0 END AS Calc_DRR

FROM ca_WM_vm.ITEM_WKLY_GPR A 
INNER JOIN ca_wm_vm.Item B ON A.Item_Nbr=B.Item_Nbr 
INNER JOIN ca_wm_vm.brand C ON C.Brand_Id = B.Brand_Id
INNER JOIN ca_wm_vm.vendor_master D ON D.Vndr_Nbr = B.Vendor_Nbr
INNER JOIN ww_mdse_dm_vm.fineline_dim E ON E.FineLine_Nbr = B.FineLine_Nbr AND B.Dept_Nbr = E.Dept_Nbr
INNER JOIN ca_wm_vm.item_factory G ON A.Item_Nbr=G.Item_Nbr 

INNER JOIN (SELECT Item_Nbr, Wm_Yr_Wk, SUM(Wkly_Sales) AS TotWklySales, SUM(Wkly_Qty) AS TotWklyQty 
            FROM ca_wm_vm.sku_dly_pos 
            GROUP BY Item_Nbr, Wm_Yr_Wk) AS F ON F.Item_Nbr=B.Item_Nbr AND F.Wm_Yr_Wk=A.Wm_Yr_Wk 
                        
INNER JOIN(SELECT Item_Nbr, Wm_Yr_Wk,SUM(Wkly_Returns) AS Customer_Defective_Return_$, SUM(Wkly_Qty) AS Customer_Defective_Return_QTY 
            FROM ca_wm_vm.sku_wkly_cust_rtn 
            WHERE RETURN_RSN_CODE=1
            GROUP BY Item_Nbr, Wm_Yr_Wk) AS H ON H.Item_Nbr=B.Item_Nbr AND H.Wm_Yr_Wk=A.Wm_Yr_Wk 

INNER JOIN(SELECT Item_Nbr, Wm_Yr_Wk, SUM(Wkly_Returns) AS Total_Customer_Return_$, SUM(Wkly_Qty) AS Total_Customer_Return_QTY 
            FROM ca_wm_vm.sku_wkly_cust_rtn 
            GROUP BY Item_Nbr, Wm_Yr_Wk) AS J ON J.Item_Nbr=B.Item_Nbr AND J.Wm_Yr_Wk=A.Wm_Yr_Wk 
			
INNER JOIN (SELECT x.item_nbr,  COUNT(wkly_qty) AS available_in_store 
			FROM (SELECT item_nbr, store_nbr, COUNT(wkly_qty)  AS wkly_qty 
					FROM ca_wm_vm.sku_dly_pos 
					WHERE wkly_qty >0
					GROUP BY  item_nbr,store_nbr) x
			GROUP BY item_nbr) K ON B.item_nbr = K.item_nbr
       
WHERE B.OBSOLETE_DATE IS NULL
AND E.current_ind = 'Y' AND E.country_code = 'CA' 
AND E.base_div_nbr = 1 AND E.hierarchy_active_ind = 'Y' 
AND A.Wm_Yr_Wk = weekNbr
AND C.Brand_Family_Id IN (100,74,73,72,71,68,48,3)
ORDER BY B.Old_Nbr, B.Dept_Nbr

