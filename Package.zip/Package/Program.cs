﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Package
{
    class Program
    {
        static void CopyDataToFile(String strToFile, String strFromFile)
        {
            try
            {   // Open the From File with Stream Reader
                using (StreamReader sr = new StreamReader(strFromFile))
                {
                    // Read the first header line and drop it.
                    String line = sr.ReadLine();

                    //Open the To file with Stream Writer
                    //using (StreamWriter writer = new StreamWriter(strToFile))
                    //StreamWriter writer = new StreamWriter(strToFile);
                    StreamWriter writer = File.AppendText(strToFile);

                    try 
                    {
                        // Begin reading the Data Lines
                        while ((line = sr.ReadLine()) != null)
                        {
                            writer.WriteLine(line); 
                        }
                    }
                    finally
                    {
                        writer.Flush();
                        writer.Close();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("File might not exist to: [" + strToFile + "] from : [" + strFromFile + "]" );
            }
        }
        static void Main(string[] args)
        {
            // Test if input arguments were supplied:
            if (args.Length == 0)
            {
                System.Console.WriteLine("Please enter a File Name argument.");
                System.Console.WriteLine("Usage: Distribute <DOMAIN>");
            }
            else
            {
                String strDomain = args[0];
                String strWorkingDirectory = Directory.GetCurrentDirectory();
                String strDomainDirectory = strWorkingDirectory + @"\" + strDomain;

                String strGroupsFileOld = strDomainDirectory + @"\ADGroups\ADGroups.txt";
                String strGroupsFileNew = strWorkingDirectory + @"\" + strDomain + "ADGroups.txt";
                try
                {
                    File.Move(strGroupsFileOld, strGroupsFileNew);
                }
                catch (Exception exp)
                {
                    System.Console.WriteLine(exp.ToString());
                }

                if(0 == strDomain.CompareTo("CORP"))
                {
                    String strGroupsFileOldAssignments1 = strDomainDirectory + @"\ADUsers\GetAssignments1\ADGroupsAssignments.txt";
                    String strGroupsFileNewAssignments1 = strWorkingDirectory + @"\" + strDomain + "ADGroupsAssignments1.txt";
                    String strGroupsFileOldAssignments2 = strDomainDirectory + @"\ADUsers\GetAssignments2\ADGroupsAssignments.txt";
                    String strGroupsFileNewAssignments2 = strWorkingDirectory + @"\" + strDomain + "ADGroupsAssignments2.txt";
                    String strGroupsFileOldAssignments3 = strDomainDirectory + @"\ADUsers\GetAssignments3\ADGroupsAssignments.txt";
                    String strGroupsFileNewAssignments3 = strWorkingDirectory + @"\" + strDomain + "ADGroupsAssignments3.txt";
                    String strGroupsFileOldAssignments4 = strDomainDirectory + @"\ADUsers\GetAssignments4\ADGroupsAssignments.txt";
                    String strGroupsFileNewAssignments4 = strWorkingDirectory + @"\" + strDomain + "ADGroupsAssignments4.txt";
                    
                    try
                    {
                        File.Move(strGroupsFileOldAssignments1, strGroupsFileNewAssignments1);
                        File.Move(strGroupsFileOldAssignments2, strGroupsFileNewAssignments2);
                        File.Move(strGroupsFileOldAssignments3, strGroupsFileNewAssignments3);
                        File.Move(strGroupsFileOldAssignments4, strGroupsFileNewAssignments4);
                    }
                    catch (Exception exp)
                    {
                        System.Console.WriteLine(exp.ToString());
                    }
                }
                else
                {
                    String strGroupsFileOldAssignments1 = strDomainDirectory + @"\ADUsers\GetAssignments1\ADGroupsAssignments.txt";
                    String strGroupsFileOldAssignments2 = strDomainDirectory + @"\ADUsers\GetAssignments2\ADGroupsAssignments.txt";
                    String strGroupsFileOldAssignments3 = strDomainDirectory + @"\ADUsers\GetAssignments3\ADGroupsAssignments.txt";
                    String strGroupsFileOldAssignments4 = strDomainDirectory + @"\ADUsers\GetAssignments4\ADGroupsAssignments.txt";
                    
                    String strGroupsFileNewAssignments = strWorkingDirectory + @"\" + strDomain + "ADGroupsAssignments.txt";

                    try
                    {
                        //Move with Rename
                        File.Move(strGroupsFileOldAssignments1, strGroupsFileNewAssignments);

                        // Concat remaining 3
                        // File.Copy(strGroupsFileNewAssignments, strGroupsFileOldAssignments2);
                        CopyDataToFile(strGroupsFileNewAssignments, strGroupsFileOldAssignments2);
                        File.Delete(strGroupsFileOldAssignments2);
                        CopyDataToFile(strGroupsFileNewAssignments, strGroupsFileOldAssignments3);
                        //File.Copy(strGroupsFileNewAssignments, strGroupsFileOldAssignments3);
                        File.Delete(strGroupsFileOldAssignments3);
                        CopyDataToFile(strGroupsFileNewAssignments, strGroupsFileOldAssignments4);
                        //File.Copy(strGroupsFileNewAssignments, strGroupsFileOldAssignments4);
                        File.Delete(strGroupsFileOldAssignments4);
                    }
                    catch (Exception exp)
                    {
                        System.Console.WriteLine(exp.ToString());

                    }
                }

                String strAccountsFileOld1 = strDomainDirectory + @"\ADUsers\GetUsers1\ADAccounts.txt";
                String strAccountsFileOld2 = strDomainDirectory + @"\ADUsers\GetUsers2\ADAccounts.txt";
                String strAccountsFileOld3 = strDomainDirectory + @"\ADUsers\GetUsers3\ADAccounts.txt";
                String strAccountsFileOld4 = strDomainDirectory + @"\ADUsers\GetUsers4\ADAccounts.txt";

                String strAccountsFileNew = strWorkingDirectory + @"\" + strDomain + "ADAccounts.txt";

                try
                {
                    //Move with Rename
                    File.Move(strAccountsFileOld1, strAccountsFileNew);

                    // Concat remaining 3
                    CopyDataToFile(strAccountsFileNew, strAccountsFileOld2);
                    // File.Copy(strAccountsFileNew, strAccountsFileOld2);
                    File.Delete(strAccountsFileOld2);
                    CopyDataToFile(strAccountsFileNew, strAccountsFileOld3);
                    // File.Copy(strAccountsFileNew, strAccountsFileOld3);
                    File.Delete(strAccountsFileOld3);
                    CopyDataToFile(strAccountsFileNew, strAccountsFileOld4);
                    // File.A(strAccountsFileNew, strAccountsFileOld4);
                    File.Delete(strAccountsFileOld4);
                }
                catch (Exception exp)
                {
                    System.Console.WriteLine(exp.ToString());

                }

                String strManagedObjectsFileOld1 = strDomainDirectory + @"\ADUsers\GetUsers1\ADManagedObjects.txt";
                String strManagedObjectsFileOld2 = strDomainDirectory + @"\ADUsers\GetUsers2\ADManagedObjects.txt";
                String strManagedObjectsFileOld3 = strDomainDirectory + @"\ADUsers\GetUsers3\ADManagedObjects.txt";
                String strManagedObjectsFileOld4 = strDomainDirectory + @"\ADUsers\GetUsers4\ADManagedObjects.txt";

                String strManagedObjectsFileNew = strWorkingDirectory + @"\" + strDomain + "ADManagedObjects.txt";

                try
                {
                    //Move with Rename
                    File.Move(strManagedObjectsFileOld1, strManagedObjectsFileNew);

                    // Concat remaining 3
                    CopyDataToFile(strManagedObjectsFileNew, strManagedObjectsFileOld2);
                    File.Delete(strManagedObjectsFileOld2);
                    CopyDataToFile(strManagedObjectsFileNew, strManagedObjectsFileOld3);
                    File.Delete(strManagedObjectsFileOld3);
                    CopyDataToFile(strManagedObjectsFileNew, strManagedObjectsFileOld4);
                    File.Delete(strManagedObjectsFileOld4);
                }
                catch (Exception exp)
                {
                    System.Console.WriteLine(exp.ToString());

                }

            }
        }
    }
}
