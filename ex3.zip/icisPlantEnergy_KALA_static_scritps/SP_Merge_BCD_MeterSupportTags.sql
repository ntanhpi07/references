USE [icisPlantEnergy_KALA]
GO
/****** Object:  StoredProcedure [bcd].[SP_Merge_BCD_MeterSupportTags]    Script Date: 3/10/2020 11:09:35 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [bcd].SP_Merge_BCD_MeterSupportTags 'dbo', 'icisPlantEnergy_KALA', 'bcd'

ALTER PROCEDURE [bcd].[SP_Merge_BCD_MeterSupportTags]
(
@source_schema varchar(100) --= 'dbo'
, @db_name varchar(100) --= 'icisPlantEnergy_KALA'
, @target_schema varchar(100) --= 'bcd'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec bcd.[SP_Merge_StartLog] 'Merging data on [BCD_MeterSupportTags]', @source_schema, @db_name, @target_schema, @log_id output

BEGIN TRY

--create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID uniqueidentifier, DeletedID uniqueidentifier)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##BCD_MeterSupportTags'') drop table ##BCD_MeterSupportTags
SELECT distinct * INTO ##BCD_MeterSupportTags FROM '+ @source_schema + '.icisEMS_MeterSupportTags'

--print @strsql

EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

set @strsql='
MERGE ' + @target_schema + '.[BCD_MeterSupportTags] a 
USING ##BCD_MeterSupportTags b
ON (a.[meterID]=b.[meterID]
)
WHEN MATCHED AND (a.[infoTag1]<>b.[infoTag1]
OR a.[infoTag2]<>b.[infoTag2]
OR a.[infoTag3]<>b.[infoTag3]
OR a.[infoTag4]<>b.[infoTag4]
OR a.[infoTag5]<>b.[infoTag5]
OR a.[infoTag6]<>b.[infoTag6]
OR a.[infoTag7]<>b.[infoTag7]
OR a.[infoTag8]<>b.[infoTag8]
OR a.[infoTag9]<>b.[infoTag9]
OR a.[infoTag10]<>b.[infoTag10])
THEN 
UPDATE SET a.[infoTag1]=b.[infoTag1]
, a.[infoTag2]=b.[infoTag2]
, a.[infoTag3]=b.[infoTag3]
, a.[infoTag4]=b.[infoTag4]
, a.[infoTag5]=b.[infoTag5]
, a.[infoTag6]=b.[infoTag6]
, a.[infoTag7]=b.[infoTag7]
, a.[infoTag8]=b.[infoTag8]
, a.[infoTag9]=b.[infoTag9]
, a.[infoTag10]=b.[infoTag10]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([meterID]
      ,[infoTag1]
      ,[infoTag2]
      ,[infoTag3]
      ,[infoTag4]
      ,[infoTag5]
      ,[infoTag6]
      ,[infoTag7]
      ,[infoTag8]
      ,[infoTag9]
      ,[infoTag10]) 
VALUES (b.[meterID]
      ,b.[infoTag1]
      ,b.[infoTag2]
      ,b.[infoTag3]
      ,b.[infoTag4]
      ,b.[infoTag5]
      ,b.[infoTag6]
      ,b.[infoTag7]
      ,b.[infoTag8]
      ,b.[infoTag9]
      ,b.[infoTag10] 
) OUTPUT
      $action, inserted.meterID ''inserted'', deleted.meterID ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec bcd.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update bcd.BCD_KALA_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec bcd.[SP_Merge_EndLog] @log_id, @logmessage

end
