/*

use master
go

grant exec on sp_OACreate to iiot_energy_kal_usr

GO

grant exec on sp_OACreate to iiot_energy_kal_login
GO


*/

Declare @Object as Int;
Declare @ResponseText as Varchar(8000);

--Code Snippet
Exec sp_OACreate 'MSXML2.XMLHTTP', @Object OUT;
Exec sp_OAMethod @Object, 'open', NULL, 'get',
                 'http://amrvsp000005218.amer.pfizer.com:8686/ExAPIRestService/sendMail?subject=Testing_Email&toEmail=Anh.Nguyen3@pfizer.com&toMessage="This is test email"' 
                 ,'false'
Exec sp_OAMethod @Object, 'send'
Exec sp_OAMethod @Object, 'responseText', @ResponseText OUTPUT

Select @ResponseText

Exec sp_OADestroy @Object
