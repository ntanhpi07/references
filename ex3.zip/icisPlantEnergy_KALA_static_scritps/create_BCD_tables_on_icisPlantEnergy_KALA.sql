USE [icisPlantEnergy_KALA]

/*
GO
INSERT INTO [dbo].[icisEMS_MeterPowerChilledTags]
           ([meterID]
           ,[tagType]
           ,[tagName])
SELECT [meterID]
      ,[tagType]
      ,[tagName]
  FROM [icisPlantEnergy_KAL].[dbo].[icisEMS_MeterPowerChilledTags]
GO

INSERT INTO [dbo].[icisEMS_MeterWaterVesselOutlets]
           ([meterID]
           ,[outIndex]
           ,[outValve]
           ,[outFlow])
SELECT [meterID]
      ,[outIndex]
      ,[outValve]
      ,[outFlow]
  FROM [icisPlantEnergy_KAL].[dbo].[icisEMS_MeterWaterVesselOutlets]

*/

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterList

CREATE TABLE [bcd].[BCD_MeterList](
	[meterID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[meterName] [varchar](64) NULL,
	[meterSystem] [varchar](16) NULL,
	[id] [int] NOT NULL,
 CONSTRAINT [PK_icisPMS_MeterList] PRIMARY KEY CLUSTERED 
(
	[meterID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterList] ADD  CONSTRAINT [DF_icisPMS_MeterList_meterID]  DEFAULT (newid()) FOR [meterID]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterSettings

GO

CREATE TABLE [bcd].[BCD_MeterSettings](
	[meterID] [uniqueidentifier] NULL,
	[meterHistorian] [varchar](128) NULL,
	[meterDescription] [varchar](256) NULL,
	[meterMeasureType] [varchar](16) NULL,
	[meterCountType] [varchar](16) NULL,
	[meterUnit] [varchar](32) NULL,
	[meterSamplePeriod] [int] NULL,
	[meterTag] [varchar](128) NULL,
	[meterTarget] [int] NULL,
	[meterEnabled] [bit] NULL,
	[meterCarbonRate] [float] NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterSettings]  WITH CHECK ADD  CONSTRAINT [FK_icisPMS_MeterSettings_icisPMS_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterSettings] CHECK CONSTRAINT [FK_icisPMS_MeterSettings_icisPMS_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterSupportTags

CREATE TABLE [bcd].[BCD_MeterSupportTags](
	[meterID] [uniqueidentifier] NOT NULL,
	[infoTag1] [varchar](128) NOT NULL,
	[infoTag2] [varchar](128) NOT NULL,
	[infoTag3] [varchar](128) NOT NULL,
	[infoTag4] [varchar](128) NOT NULL,
	[infoTag5] [varchar](128) NOT NULL,
	[infoTag6] [varchar](128) NOT NULL,
	[infoTag7] [varchar](128) NOT NULL,
	[infoTag8] [varchar](128) NOT NULL,
	[infoTag9] [varchar](128) NOT NULL,
	[infoTag10] [varchar](128) NOT NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterCustomEquations

CREATE TABLE [bcd].[BCD_MeterCustomEquations](
	[customID] [int] NOT NULL,
	[meterID] [uniqueidentifier] NULL,
	[paramOrder] [int] NULL,
	[paramType] [varchar](32) NULL,
	[paramName] [varchar](128) NULL,
	[paramValue] [varchar](32) NULL,
	[paramCorrection] [varchar](16) NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterGasSettings

CREATE TABLE [bcd].[BCD_MeterGasSettings](
	[meterID] [uniqueidentifier] NOT NULL,
	[calcType] [int] NOT NULL,
	[ratedFlow] [float] NOT NULL,
	[meterCorrection] [int] NOT NULL,
	[ratedCharType] [int] NULL,
	[ratedRangeability] [float] NULL,
	[pressureDrop] [float] NULL,
	[linearLow] [int] NULL,
	[linearHigh] [int] NULL,
	[logLow] [int] NULL,
	[logHigh] [int] NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterGasCalcFormula

CREATE TABLE [bcd].[BCD_MeterGasCalcFormula](
	[meterID] [uniqueidentifier] NULL,
	[meterCalcID] [uniqueidentifier] NULL,
	[meterCalcName] [varchar](128) NULL,
	[meterCalcType] [varchar](8) NULL,
	[meterCorrection] [float] NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterGasCalcFormula]  WITH CHECK ADD  CONSTRAINT [FK_BCD_MeterGasCalcFormula_BCD_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterGasCalcFormula] CHECK CONSTRAINT [FK_BCD_MeterGasCalcFormula_BCD_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterGenSettings

CREATE TABLE [bcd].[BCD_MeterGenSettings](
	[meterID] [uniqueidentifier] NOT NULL,
	[calcType] [int] NOT NULL,
	[ratedFlow] [float] NOT NULL,
	[ratedCharType] [int] NOT NULL,
	[ratedRangeability] [float] NOT NULL,
	[meterCorrection] [int] NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterGenSettings]  WITH CHECK ADD  CONSTRAINT [FK_icisGMS_MeterGenSettings_icisGMS_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterGenSettings] CHECK CONSTRAINT [FK_icisGMS_MeterGenSettings_icisGMS_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterGenCalcFormula

CREATE TABLE [bcd].[BCD_MeterGenCalcFormula](
	[meterID] [uniqueidentifier] NULL,
	[meterCalcID] [uniqueidentifier] NULL,
	[meterCalcName] [varchar](128) NULL,
	[meterCalcType] [varchar](8) NULL,
	[meterCorrection] [float] NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterGenCalcFormula]  WITH CHECK ADD  CONSTRAINT [FK_BCD_MeterGenCalcFormula_BCD_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterGenCalcFormula] CHECK CONSTRAINT [FK_BCD_MeterGenCalcFormula_BCD_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterPowerSettings


CREATE TABLE [bcd].[BCD_MeterPowerSettings](
	[meterID] [uniqueidentifier] NULL,
	[calcType] [int] NULL,
	[ratedHP] [float] NULL,
	[ratedI] [float] NULL,
	[ratedV] [float] NULL,
	[ratedRpm] [int] NULL,
	[ratedPF] [float] NULL,
	[onTarget] [int] NULL,
	[offTarget] [int] NULL,
	[correctionFactor] [float] NULL,
	[powerCurve] [int] NULL,
	[phaseRating] [int] NULL,
	[splitLoad] [int] NULL,
	[splitTagname] [varchar](128) NULL,
	[tempTagUsed] [int] NULL,
	[supplyTagValue] [varchar](128) NULL,
	[returnTagValue] [varchar](128) NULL,
	[flowTagUsed] [int] NULL,
	[flowTagValue] [varchar](128) NULL,
	[conversionFactor] [float] NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterPowerSettings]  WITH CHECK ADD  CONSTRAINT [FK_icisPMS_MeterPowerSettings_icisPMS_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterPowerSettings] CHECK CONSTRAINT [FK_icisPMS_MeterPowerSettings_icisPMS_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterPowerCalcFormula

CREATE TABLE [bcd].[BCD_MeterPowerCalcFormula](
	[meterID] [uniqueidentifier] NULL,
	[meterCalcID] [uniqueidentifier] NULL,
	[meterCalcName] [varchar](128) NULL,
	[meterCalcType] [varchar](8) NULL,
	[meterCorrection] [float] NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterPowerCalcFormula]  WITH CHECK ADD  CONSTRAINT [FK_BCD_MeterPowerCalcFormula_BCD_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterPowerCalcFormula] CHECK CONSTRAINT [FK_BCD_MeterPowerCalcFormula_BCD_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterPowerChilledTags  -- created from icisPlantEnergy_KAL database

CREATE TABLE [bcd].[BCD_MeterPowerChilledTags](
	[mIndex] [int] NOT NULL,
	[meterID] [uniqueidentifier] NOT NULL,
	[tagType] [varchar](16) NOT NULL,
	[tagName] [varchar](128) NOT NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterSteamSettings

CREATE TABLE [bcd].[BCD_MeterSteamSettings](
	[meterID] [uniqueidentifier] NOT NULL,
	[calcType] [int] NOT NULL,
	[ratedHeatCapacity] [float] NOT NULL,
	[ratedEnthalpy] [float] NOT NULL,
	[ratedSpecificGravity] [float] NOT NULL,
	[ratedMinTemp] [float] NOT NULL,
	[ratedMaxTemp] [float] NOT NULL,
	[ratedFlow] [float] NOT NULL,
	[ratedCharType] [int] NOT NULL,
	[ratedRangeability] [float] NOT NULL,
	[tempTag] [varchar](128) NOT NULL,
	[weighType] [int] NOT NULL,
	[weighTag] [varchar](128) NOT NULL,
	[meterCorrection] [int] NOT NULL,
	[flowUnit] [varchar](64) NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterSteamSettings]  WITH CHECK ADD  CONSTRAINT [FK_icisSMS_MeterSteamSettings_icisSMS_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterSteamSettings] CHECK CONSTRAINT [FK_icisSMS_MeterSteamSettings_icisSMS_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterSteamCalcFormula

CREATE TABLE [bcd].[BCD_MeterSteamCalcFormula](
	[meterID] [uniqueidentifier] NULL,
	[meterCalcID] [uniqueidentifier] NULL,
	[meterCalcName] [varchar](128) NULL,
	[meterCalcType] [varchar](8) NULL,
	[meterCorrection] [float] NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterSteamCalcFormula]  WITH CHECK ADD  CONSTRAINT [FK_BCD_MeterSteamCalcFormula_BCD_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterSteamCalcFormula] CHECK CONSTRAINT [FK_BCD_MeterSteamCalcFormula_BCD_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterWaterSettings


CREATE TABLE [bcd].[BCD_MeterWaterSettings](
	[meterID] [uniqueidentifier] NOT NULL,
	[calcType] [int] NOT NULL,
	[ratedFlow] [float] NOT NULL,
	[ratedCharType] [int] NOT NULL,
	[ratedRangeability] [float] NOT NULL,
	[meterCorrection] [int] NOT NULL,
	[pressureDrop] [float] NOT NULL,
	[linearLow] [int] NOT NULL,
	[linearHigh] [int] NOT NULL,
	[logLow] [int] NOT NULL,
	[logHigh] [int] NOT NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterWaterCalcFormula

CREATE TABLE [bcd].[BCD_MeterWaterCalcFormula](
	[meterID] [uniqueidentifier] NULL,
	[meterCalcID] [uniqueidentifier] NULL,
	[meterCalcName] [varchar](128) NULL,
	[meterCalcType] [varchar](8) NULL,
	[meterCorrection] [float] NULL
) ON [PRIMARY]

GO

ALTER TABLE [bcd].[BCD_MeterWaterCalcFormula]  WITH CHECK ADD  CONSTRAINT [FK_BCD_MeterWaterCalcFormula_BCD_MeterList] FOREIGN KEY([meterID])
REFERENCES [bcd].[BCD_MeterList] ([meterID])
GO

ALTER TABLE [bcd].[BCD_MeterWaterCalcFormula] CHECK CONSTRAINT [FK_BCD_MeterWaterCalcFormula_BCD_MeterList]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_MeterWaterVesselOutlets -- created from icisPlantEnergy_KAL database

CREATE TABLE [bcd].[BCD_MeterWaterVesselOutlets](
	[meterID] [uniqueidentifier] NOT NULL,
	[outIndex] [int] NOT NULL,
	[outValve] [varchar](128) NOT NULL,
	[outFlow] [varchar](128) NOT NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_KPISettings

CREATE TABLE [bcd].[BCD_KPISettings](
	[kpiID] [int] NOT NULL,
	[kpiName] [varchar](128) NULL,
	[kpiDescription] [varchar](256) NULL,
	[kpiLocation] [varchar](256) NULL,
	[kpiTarget] [float] NULL,
	[kpiSystem] [varchar](128) NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_KPIEquations

CREATE TABLE [bcd].[BCD_KPIEquations](
	[kpiID] [int] NULL,
	[paramOrder] [int] NULL,
	[paramType] [varchar](32) NULL,
	[paramName] [varchar](128) NULL,
	[paramValue] [varchar](32) NULL,
	[paramCorrection] [varchar](16) NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_BatchUnits

CREATE TABLE [bcd].[BCD_BatchUnits](
	[unitID] [int] NOT NULL,
	[unitName] [varchar](128) NOT NULL,
	[unitDescription] [varchar](256) NOT NULL,
	[unitBatchTag] [varchar](128) NOT NULL,
	[unitProductTag] [varchar](128) NOT NULL,
	[unitRecipeTag] [varchar](128) NOT NULL,
	[unitInfoTag1] [varchar](128) NOT NULL,
	[unitInfoTag2] [varchar](128) NOT NULL,
	[unitInfoTag3] [varchar](128) NOT NULL,
	[unitInfoTag4] [varchar](128) NOT NULL,
	[unitInfoTag5] [varchar](128) NOT NULL,
	[unitInfoTag6] [varchar](128) NOT NULL,
	[unitInfoTag7] [varchar](128) NOT NULL,
	[unitInfoTag8] [varchar](128) NOT NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

-- BCD_BatchUnitMeters 

CREATE TABLE [bcd].[BCD_BatchUnitMeters](
	[unitID] [int] NOT NULL,
	[meterID] [uniqueidentifier] NOT NULL,
	[meterName] [varchar](256) NOT NULL,
	[meterSystem] [varchar](8) NOT NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE [bcd].[BCD_iCIS_History](
	Id [int] identity(1,1) NOT NULL,
	PK1 nvarchar(max) NOT NULL,
	PK2 nvarchar(max) NULL,
	tableName	varchar(256) NOT NULL,
	icisValue	varchar(256) NOT NULL,
	bcdValue	varchar(256) NOT NULL,
	insertedDate	datetime NULL,
	modifiedDate	datetime NULL,
	insertedBy	varchar(50) NULL,
	modifiedBy	varchar(50) NULL,
	[status]	varchar(50) NULL
)

GO-------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE [bcd].[BCD_KALA_Logs](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DBSource] [varchar](100) NULL,
	[Source] [varchar](100) NULL,
	[DBTarget] [varchar](100) NULL,
	[Schema] [varchar](100) NULL,
	[Process] [varchar](100) NULL,
	[DurationSec]  AS (case when [EndTime] IS NULL then (0) else datediff(second,[StartTime],[EndTime]) end),
	[Msg] [varchar](200) NULL,
	[ErrMsg] [nvarchar](max) NULL,
	[Loaded] [int] NULL,
	[Inserted] [int] NULL,
	[Updated] [int] NULL,
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NULL,
	[Deleted] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE [bcd].[BCD_Email_List](
	[First_Name] [nvarchar](50) NULL,
	[Last_Name] [nvarchar](50) NULL,
	[Email] [nvarchar](200) NULL,
	[Active_Flag] [nvarchar](2) NULL
) ON [PRIMARY]

GO-------------------------------------------------------------------------------------------------------------------------------------

--DROP TABLE [bcd].[BCD_iCIS_Mapping]
CREATE TABLE [bcd].[BCD_iCIS_Mapping](
	Id int identity(1,1) not null
	,BCD_Table_Name varchar(100) not null
	,iCIS_Table_Name varchar(100) not null
	,[PK1] [nvarchar](max) not null
	,[PK2] [nvarchar](max) null
	,[Status] varchar(10) not null
	,[insertedDate] [datetime] NULL
	,[modifiedDate] [datetime] NULL
	,[insertedBy] [varchar](50) NULL
	,[modifiedBy] [varchar](50) NULL
)

INSERT INTO [bcd].[BCD_iCIS_Mapping](BCD_Table_Name, iCIS_Table_Name,[PK1],[PK2],[Status],[insertedDate],[insertedBy])
VALUES
('BCD_MeterList','icisEMS_MeterList','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterSettings','icisEMS_MeterSettings','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterSupportTags','icisEMS_MeterSupportTags','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterCustomEquations','icisEMS_MeterCustomEquations','customID','meterID','Active',getdate(),'SYSTEM')
,('BCD_MeterGasSettings','icisEMS_MeterGasSettings','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterGasCalcFormula','icisEMS_MeterGasCalcFormula','meterID','meterCalcID','Active',getdate(),'SYSTEM')
,('BCD_MeterGenSettings','icisEMS_MeterGenSettings','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterGenCalcFormula','icisEMS_MeterGenCalcFormula','meterID','meterCalcID','Active',getdate(),'SYSTEM')
,('BCD_MeterPowerSettings','icisEMS_MeterPowerSettings','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterPowerCalcFormula','icisEMS_MeterPowerCalcFormula','meterID','meterCalcID','Active',getdate(),'SYSTEM')
,('BCD_MeterPowerChilledTags','icisEMS_MeterPowerChilledTags','mIndex','meterID','Active',getdate(),'SYSTEM')
,('BCD_MeterSteamSettings','icisEMS_MeterSteamSettings','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterSteamCalcFormula','icisEMS_MeterSteamCalcFormula','meterID','meterCalcID','Active',getdate(),'SYSTEM')
,('BCD_MeterWaterSettings','icisEMS_MeterWaterSettings','meterID','','Active',getdate(),'SYSTEM')
,('BCD_MeterWaterCalcFormula','icisEMS_MeterWaterCalcFormula','meterID','meterCalcID','Active',getdate(),'SYSTEM')
,('BCD_MeterWaterVesselOutlets','icisEMS_MeterWaterVesselOutlets','meterID','','Active',getdate(),'SYSTEM')
,('BCD_KPISettings','icisEMS_KPISettings','kpiID','','Active',getdate(),'SYSTEM')
,('BCD_KPIEquations','icisEMS_KPIEquations','kpiID','paramOrder','Active',getdate(),'SYSTEM')
,('BCD_BatchUnits','icisEMS_BatchUnits','unitID','','Active',getdate(),'SYSTEM')
,('BCD_BatchUnitMeters','icisEMS_BatchUnitMeters','unitID','meterID','Active',getdate(),'SYSTEM');

GO-------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE ##BCD_iCIS_History(
	[PK1] [varchar](256) NOT NULL,
	[PK2] [varchar](256) NULL,
	[tableName] [varchar](256) NOT NULL,
	[icisValue] [varchar](256) NOT NULL,
	[bcdValue] [varchar](256) NOT NULL,
	[insertedDate] [datetime] NULL,
	[modifiedDate] [datetime] NULL,
	[insertedBy] [varchar](50) NULL,
	[modifiedBy] [varchar](50) NULL,
	[status] [varchar](50) NULL
) 

GO-------------------------------------------------------------------------------------------------------------------------------------