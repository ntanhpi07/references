USE [icisPlantEnergy_KALA]
GO
/****** Object:  StoredProcedure [bcd].[SP_Merge_BCD_KPIEquations]    Script Date: 3/18/2020 11:15:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [bcd].SP_Merge_BCD_KPIEquations 'dbo', 'icisPlantEnergy_KALA', 'bcd'

ALTER PROCEDURE [bcd].[SP_Merge_BCD_KPIEquations]
(
@source_schema varchar(100) --= 'dbo'
, @db_name varchar(100) --= 'icisPlantEnergy_KALA'
, @target_schema varchar(100) --= 'bcd'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec bcd.[SP_Merge_StartLog] 'Merging data on [BCD_KPIEquations]', @source_schema, @db_name, @target_schema, @log_id output

BEGIN TRY

--create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##BCD_KPIEquations'') drop table ##BCD_KPIEquations
SELECT distinct * INTO ##BCD_KPIEquations FROM '+ @source_schema + '.icisEMS_KPIEquations'

--print @strsql

EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

set @strsql='
MERGE ' + @target_schema + '.[BCD_KPIEquations] a 
USING ##BCD_KPIEquations b
ON (a.[kpiID]=b.[kpiID]
and a.[paramOrder]=b.[paramOrder]
)
WHEN MATCHED AND (a.[paramType]<>b.[paramType]
OR a.[paramName]<>b.[paramName]
OR a.[paramValue]<>b.[paramValue]
OR a.[paramCorrection]<>b.[paramCorrection])
THEN 
UPDATE SET a.[paramType]=b.[paramType]
, a.[paramName]=b.[paramName]
, a.[paramValue]=b.[paramValue]
, a.[paramCorrection]=b.[paramCorrection]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([kpiID]
      ,[paramOrder]
      ,[paramType]
      ,[paramName]
      ,[paramValue]
      ,[paramCorrection]
	  ) 
VALUES (b.[kpiID]
      ,b.[paramOrder]
      ,b.[paramType]
      ,b.[paramName]
      ,b.[paramValue]
      ,b.[paramCorrection]
) OUTPUT
      $action, inserted.kpiID ''inserted'', deleted.kpiID ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec bcd.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update bcd.BCD_KALA_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec bcd.[SP_Merge_EndLog] @log_id, @logmessage

end
