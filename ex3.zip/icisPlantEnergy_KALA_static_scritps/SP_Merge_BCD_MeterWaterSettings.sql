USE [icisPlantEnergy_KALA]
GO
/****** Object:  StoredProcedure [bcd].[SP_Merge_BCD_MeterWaterSettings]    Script Date: 3/10/2020 11:09:35 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [bcd].SP_Merge_BCD_MeterWaterSettings 'dbo', 'icisPlantEnergy_KALA', 'bcd'

ALTER PROCEDURE [bcd].[SP_Merge_BCD_MeterWaterSettings]
(
@source_schema varchar(100) --= 'dbo'
, @db_name varchar(100) --= 'icisPlantEnergy_KALA'
, @target_schema varchar(100) --= 'bcd'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec bcd.[SP_Merge_StartLog] 'Merging data on [BCD_MeterWaterSettings]', @source_schema, @db_name, @target_schema, @log_id output

BEGIN TRY

--create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID uniqueidentifier, DeletedID uniqueidentifier)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##BCD_MeterWaterSettings'') drop table ##BCD_MeterWaterSettings
SELECT distinct * INTO ##BCD_MeterWaterSettings FROM '+ @source_schema + '.icisEMS_MeterWaterSettings'

--print @strsql

EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

set @strsql='
MERGE ' + @target_schema + '.[BCD_MeterWaterSettings] a 
USING ##BCD_MeterWaterSettings b
ON (a.[meterID]=b.[meterID]
)
WHEN MATCHED AND (a.[calcType]<>b.[calcType]
OR a.[ratedFlow]<>b.[ratedFlow]
OR a.[ratedCharType]<>b.[ratedCharType]
OR a.[ratedRangeability]<>b.[ratedRangeability]
OR a.[meterCorrection]<>b.[meterCorrection]
OR a.[pressureDrop]<>b.[pressureDrop]
OR a.[linearLow]<>b.[linearLow]
OR a.[linearHigh]<>b.[linearHigh]
OR a.[logLow]<>b.[logLow]
OR a.[logHigh]<>b.[logHigh])
THEN 
UPDATE SET a.[calcType]=b.[calcType]
, a.[ratedFlow]=b.[ratedFlow]
, a.[ratedCharType]=b.[ratedCharType]
, a.[ratedRangeability]=b.[ratedRangeability]
, a.[meterCorrection]=b.[meterCorrection]
, a.[pressureDrop]=b.[pressureDrop]
, a.[linearLow]=b.[linearLow]
, a.[linearHigh]=b.[linearHigh]
, a.[logLow]=b.[logLow]
, a.[logHigh]=b.[logHigh]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([meterID]
      ,[calcType]
      ,[ratedFlow]
      ,[ratedCharType]
      ,[ratedRangeability]
      ,[meterCorrection]
      ,[pressureDrop]
      ,[linearLow]
      ,[linearHigh]
      ,[logLow]
      ,[logHigh]
	  ) 
VALUES (b.[meterID]
      ,b.[calcType]
      ,b.[ratedFlow]
      ,b.[ratedCharType]
      ,b.[ratedRangeability]
      ,b.[meterCorrection]
      ,b.[pressureDrop]
      ,b.[linearLow]
      ,b.[linearHigh]
      ,b.[logLow]
      ,b.[logHigh]
) OUTPUT
      $action, inserted.meterID ''inserted'', deleted.meterID ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec bcd.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update bcd.BCD_KALA_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec bcd.[SP_Merge_EndLog] @log_id, @logmessage

end
