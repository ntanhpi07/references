USE [icisPlantEnergy_KALA]
GO
/****** Object:  StoredProcedure [bcd].[SP_Merge_BCD_BatchUnits]    Script Date: 3/18/2020 11:15:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [bcd].SP_Merge_BCD_BatchUnits 'dbo', 'icisPlantEnergy_KALA', 'bcd'

ALTER PROCEDURE [bcd].[SP_Merge_BCD_BatchUnits]
(
@source_schema varchar(100) --= 'dbo'
, @db_name varchar(100) --= 'icisPlantEnergy_KALA'
, @target_schema varchar(100) --= 'bcd'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec bcd.[SP_Merge_StartLog] 'Merging data on [BCD_BatchUnits]', @source_schema, @db_name, @target_schema, @log_id output

BEGIN TRY

--create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##BCD_BatchUnits'') drop table ##BCD_BatchUnits
SELECT distinct * INTO ##BCD_BatchUnits FROM '+ @source_schema + '.icisEMS_BatchUnits'

--print @strsql

EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

set @strsql='
MERGE ' + @target_schema + '.[BCD_BatchUnits] a 
USING ##BCD_BatchUnits b
ON (a.[unitID]=b.[unitID]
)
WHEN MATCHED AND (a.[unitName]<>b.[unitName]
OR a.[unitDescription]<>b.[unitDescription]
OR a.[unitBatchTag]<>b.[unitBatchTag]
OR a.[unitProductTag]<>b.[unitProductTag]
OR a.[unitRecipeTag]<>b.[unitRecipeTag]
OR a.[unitInfoTag1]<>b.[unitInfoTag1]
OR a.[unitInfoTag2]<>b.[unitInfoTag2]
OR a.[unitInfoTag3]<>b.[unitInfoTag3]
OR a.[unitInfoTag4]<>b.[unitInfoTag4]
OR a.[unitInfoTag5]<>b.[unitInfoTag5]
OR a.[unitInfoTag6]<>b.[unitInfoTag6]
OR a.[unitInfoTag7]<>b.[unitInfoTag7]
OR a.[unitInfoTag8]<>b.[unitInfoTag8])
THEN 
UPDATE SET a.[unitName]=b.[unitName]
, a.[unitDescription]=b.[unitDescription]
, a.[unitBatchTag]=b.[unitBatchTag]
, a.[unitProductTag]=b.[unitProductTag]
, a.[unitRecipeTag]=b.[unitRecipeTag]
, a.[unitInfoTag1]=b.[unitInfoTag1]
, a.[unitInfoTag2]=b.[unitInfoTag2]
, a.[unitInfoTag3]=b.[unitInfoTag3]
, a.[unitInfoTag4]=b.[unitInfoTag4]
, a.[unitInfoTag5]=b.[unitInfoTag5]
, a.[unitInfoTag6]=b.[unitInfoTag6]
, a.[unitInfoTag7]=b.[unitInfoTag7]
, a.[unitInfoTag8]=b.[unitInfoTag8]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([unitID]
      ,[unitName]
      ,[unitDescription]
      ,[unitBatchTag]
      ,[unitProductTag]
      ,[unitRecipeTag]
      ,[unitInfoTag1]
      ,[unitInfoTag2]
      ,[unitInfoTag3]
      ,[unitInfoTag4]
      ,[unitInfoTag5]
      ,[unitInfoTag6]
      ,[unitInfoTag7]
      ,[unitInfoTag8]
	  ) 
VALUES (b.[unitID]
      ,b.[unitName]
      ,b.[unitDescription]
      ,b.[unitBatchTag]
      ,b.[unitProductTag]
      ,b.[unitRecipeTag]
      ,b.[unitInfoTag1]
      ,b.[unitInfoTag2]
      ,b.[unitInfoTag3]
      ,b.[unitInfoTag4]
      ,b.[unitInfoTag5]
      ,b.[unitInfoTag6]
      ,b.[unitInfoTag7]
      ,b.[unitInfoTag8]
) OUTPUT
      $action, inserted.unitID ''inserted'', deleted.unitID ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec bcd.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update bcd.BCD_KALA_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec bcd.[SP_Merge_EndLog] @log_id, @logmessage

end
