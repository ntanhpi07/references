create table iot_energy_ecs_rng_test.alarms
as
select * from iot_energy_ecs_rng.alarms limit 10;

create table iot_energy_ecs_rng_test.audittrail
as
select * from iot_energy_ecs_rng.audittrail limit 10;

create table iot_energy_ecs_rng_test.mapevents
as
select * from iot_energy_ecs_rng.mapevents limit 10;

create table iot_energy_ecs_rng_test.mapstatus
as
select * from iot_energy_ecs_rng.mapstatus limit 10;

create table iot_energy_ecs_rng_test.memorystatus
as
select * from iot_energy_ecs_rng.memorystatus limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_1gba_b_c_d_1a_b801_mcc
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_1gba_b_c_d_1a_b801_mcc limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_1gba_b_c_d_2a801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_1gba_b_c_d_2a801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_1gba_b_c_d_3b801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_1gba_b_c_d_3b801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_1gba_b_c_d_4c_d801_mcc
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_1gba_b_c_d_4c_d801_mcc limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_1gba_b_c_d_5c801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_1gba_b_c_d_5c801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_1gba_b_c_d_6d801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_1gba_b_c_d_6d801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_1gba_b_c_d_7a_b_c_d_temps
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_1gba_b_c_d_7a_b_c_d_temps limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_2gbe_g_h_k_1e_g801_mcc
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_2gbe_g_h_k_1e_g801_mcc limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_2gbe_g_h_k_2e801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_2gbe_g_h_k_2e801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_2gbe_g_h_k_3g801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_2gbe_g_h_k_3g801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_2gbe_g_h_k_5h801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_2gbe_g_h_k_5h801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_2gbe_g_h_k_6k801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_2gbe_g_h_k_6k801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_2gbe_g_h_k_7e_g_h_k_temp_rh
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_2gbe_g_h_k_7e_g_h_k_temp_rh limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_1l_m801_mcc
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_1l_m801_mcc limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_2l801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_2l801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_3m801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_3m801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_4q_j801_mcc
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_4q_j801_mcc limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_5q801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_5q801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_6j801_remote
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_6j801_remote limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_7l_m_q_j_temp
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_7l_m_q_j_temp limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_3gbl_m_q_j_8l_m801_pressure
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_3gbl_m_q_j_8l_m801_pressure limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_4gbf_gb839_17_hydrog_ex_fans
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_4gbf_gb839_17_hydrog_ex_fans limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_4gbf_gb839_1f801_mcc
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_4gbf_gb839_1f801_mcc limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_4gbf_gb839_2b839_mcc
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_4gbf_gb839_2b839_mcc limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_4gbf_gb839_3b839_temp_control
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_4gbf_gb839_3b839_temp_control limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_4gbf_gb839_5c_d_g802
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_4gbf_gb839_5c_d_g802 limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_4gbf_gb839_6chiller
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_4gbf_gb839_6chiller limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_4gbf_gb839_8new_mcc_extract_system
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_4gbf_gb839_8new_mcc_extract_system limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_007_uc3224
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_007_uc3224 limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_008_uc3216
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_008_uc3216 limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_013_uc328
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_013_uc328 limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_0501
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_0501 limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_0502
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_0502 limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_0503
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_0503 limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_4extract
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_4extract limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_5downflow_booth
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_5downflow_booth limit 10;

create table iot_energy_ecs_rng_test.mtrend__n1_osp3_5annex_6gbn_801
as
select * from iot_energy_ecs_rng.mtrend__n1_osp3_5annex_6gbn_801 limit 10;
