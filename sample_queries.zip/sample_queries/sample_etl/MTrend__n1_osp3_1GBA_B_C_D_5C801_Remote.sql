USE [IOT_ETL_ENERGY_ECS]
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote;

CREATE PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote]
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @mysql_schema varchar(100) = 'iot_energy_ecs_rng'
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote') drop table ##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote
SELECT distinct *
INTO ##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote')

SET @loadedRow = @@ROWCOUNT

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec dbo.[SP_Merge_StartLog] 'Merging data on [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote]', @mysql_schema, @mssql_schema, @log_id output

BEGIN TRY

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and a.[TS_80103_Frost_Stat_GBC801]=b.[TS_80103_Frost_Stat_GBC801]
and a.[Glb_Outside_Frost]=b.[Glb_Outside_Frost]
and a.[TT80103A_S_Air_Mv_GBC801]=b.[TT80103A_S_Air_Mv_GBC801]
and a.[HV80103_Frost_Valve_Actuator_GBC801]=b.[HV80103_Frost_Valve_Actuator_GBC801]
and a.[TV80103_Heating_Vavle_Actuator_GBC801]=b.[TV80103_Heating_Vavle_Actuator_GBC801]
and a.[S_Air_Setpoint_GBC801]=b.[S_Air_Setpoint_GBC801]
and a.[Room_Setpoint_GBC801]=b.[Room_Setpoint_GBC801]
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[TS_80103_Frost_Stat_GBC801]=b.[TS_80103_Frost_Stat_GBC801]
, a.[Glb_Outside_Frost]=b.[Glb_Outside_Frost]
, a.[TT80103A_S_Air_Mv_GBC801]=b.[TT80103A_S_Air_Mv_GBC801]
, a.[HV80103_Frost_Valve_Actuator_GBC801]=b.[HV80103_Frost_Valve_Actuator_GBC801]
, a.[TV80103_Heating_Vavle_Actuator_GBC801]=b.[TV80103_Heating_Vavle_Actuator_GBC801]
, a.[S_Air_Setpoint_GBC801]=b.[S_Air_Setpoint_GBC801]
, a.[Room_Setpoint_GBC801]=b.[Room_Setpoint_GBC801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TS_80103_Frost_Stat_GBC801]
      ,[Glb_Outside_Frost]
      ,[TT80103A_S_Air_Mv_GBC801]
      ,[HV80103_Frost_Valve_Actuator_GBC801]
      ,[TV80103_Heating_Vavle_Actuator_GBC801]
      ,[S_Air_Setpoint_GBC801]
      ,[Room_Setpoint_GBC801]
) 
VALUES (b.[ReadingTime]
      ,b.[TS_80103_Frost_Stat_GBC801]
      ,b.[Glb_Outside_Frost]
      ,b.[TT80103A_S_Air_Mv_GBC801]
      ,b.[HV80103_Frost_Valve_Actuator_GBC801]
      ,b.[TV80103_Heating_Vavle_Actuator_GBC801]
      ,b.[S_Air_Setpoint_GBC801]
      ,b.[Room_Setpoint_GBC801] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging '+ @mssql_schema +'.[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote] failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec dbo.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging '+ @mssql_schema +'.[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote] completed.'

	update dbo.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec dbo.[SP_Merge_EndLog] @log_id, @logmessage

end
