USE [IOT_ETL_ENERGY_ECS]
GO

print 'INSERT INTO [energy_ecs_ahu].[Alarms]'

INSERT INTO [energy_ecs_ahu].[Alarms]
           ([alarmid]
           ,[applicationname]
           ,[alarmname]
           ,[occurrencedate]
           ,[description]
           ,[value]
           ,[priority]
           ,[status]
           ,[ackdate]
           ,[ackwho]
           ,[cleardate]
           ,[clearwho]
           ,[comment]
           ,[unitid]
           ,[channel]
           ,[exceptionclass]
           ,[causecode])
SELECT [alarmid]
           ,[applicationname]
           ,[alarmname]
           ,[occurrencedate]
           ,[description]
           ,[value]
           ,[priority]
           ,[status]
           ,[ackdate]
           ,[ackwho]
           ,[cleardate]
           ,[clearwho]
           ,[comment]
           ,[unitid]
           ,[channel]
           ,[exceptionclass]
           ,[causecode] 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.alarms')

GO

print 'INSERT INTO [energy_ecs_ahu].[AuditTrail]'

INSERT INTO [energy_ecs_ahu].[AuditTrail](
	[audittrailid] 
	, [occurrencedate] 
	, [username] 
	, [priority] 
	, [uiComponent]
	, [disposition]
	, [auditMessage]
	, [newvalue] 
	, [auditTrailManager]
	, [description]
	, [auditTrailManagerId] 
	, [origin] 
	, [previousValue]
)
SELECT 	[audittrailid] 
	, [occurrencedate] 
	, [username] 
	, [priority] 
	, [uiComponent]
	, [disposition]
	, [auditMessage]
	, [newvalue] 
	, [auditTrailManager]
	, [description]
	, [auditTrailManagerId] 
	, [origin] 
	, [previousValue]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.AuditTrail')

GO

print 'INSERT INTO [energy_ecs_ahu].[MapEvents]'

INSERT INTO [energy_ecs_ahu].[MapEvents]
           ([eventid]
           ,[occurrencedate]
           ,[eventtype]
           ,[priority]
           ,[source]
           ,[description]
           ,[origin])
SELECT [eventid]
           ,[occurrencedate]
           ,[eventtype]
           ,[priority]
           ,[source]
           ,[description]
           ,[origin]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MapEvents')

GO

print 'INSERT INTO [energy_ecs_ahu].[MapStatus]'

INSERT INTO [energy_ecs_ahu].[MapStatus](
	[ReadingTime]
	,[ElapsedSparklineSecs]
	,[ElapsedSummarySecs]
	,[ElapsedAlarmSecs]
	,[ElapsedTrendSecs])
SELECT [ReadingTime]
	,[ElapsedSparklineSecs]
	,[ElapsedSummarySecs]
	,[ElapsedAlarmSecs]
	,[ElapsedTrendSecs]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MapStatus')

GO

print 'INSERT INTO [energy_ecs_ahu].[MemoryStatus]'

INSERT INTO [energy_ecs_ahu].[MemoryStatus](
	[ReadingTime] 
	,[JvmTotal]
	,[CombinedFree] 
	,[SystemTotal]
	,[SystemFree]
	,[JvmFree]
	,[SwapFree]
	,[SwapTotal])
SELECT [ReadingTime] 
	,[JvmTotal]
	,[CombinedFree] 
	,[SystemTotal]
	,[SystemFree]
	,[JvmFree]
	,[SwapFree]
	,[SwapTotal]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MemoryStatus')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC](
	[ReadingTime]
	,[GBC801_Run_Signal_i])
SELECT	[ReadingTime]
	,[GBC801_Run_Signal_i]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC')



GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote](
	[ReadingTime]
	,[GBA_801_VSD_Speed_Actual_] 
	,[TT80101A_Supply_Air_Temperature_GBA801] 
	,[O_P_Glb_Outside_Frost] 
	,[TV80101_Heating_Vavle_Actuator_GBA801] 
	,[HV80101_Frost_Valve_Actuator_GBA801]
	,[TT801150_Outside_Air]
	,[TS_80101_Frost_Stat_GBA801]
	,[S_Air_Setpoint_GBA801] 
	,[Room_Setpoint_GBA801])
SELECT 	[ReadingTime]
	,[GBA_801_VSD_Speed_Actual_] 
	,[TT80101A_Supply_Air_Temperature_GBA801] 
	,[O_P_Glb_Outside_Frost] 
	,[TV80101_Heating_Vavle_Actuator_GBA801] 
	,[HV80101_Frost_Valve_Actuator_GBA801]
	,[TT801150_Outside_Air]
	,[TS_80101_Frost_Stat_GBA801]
	,[S_Air_Setpoint_GBA801] 
	,[Room_Setpoint_GBA801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote](
	[ReadingTime] 
	,[HV80102_Frost_Valve_Actuator_GBB801]
	,[TT80102A_Supply_Air_Temperature_GBB801_L5] 
	,[TV80102_Heating_Valve_Actuator_GBB801] 
	,[TT80102A_Supply_Air_Temperature_GBB801_L1] 
	,[GBB_801_VSD_Speed_Actual_]
	,[TS_80102_Frost_Stat_GBB801] 
	,[S_Air_Setpoint_GBB801] 
	,[Room_Setpoint_GBB801])
SELECT [ReadingTime] 
	,[HV80102_Frost_Valve_Actuator_GBB801]
	,[TT80102A_Supply_Air_Temperature_GBB801_L5] 
	,[TV80102_Heating_Valve_Actuator_GBB801] 
	,[TT80102A_Supply_Air_Temperature_GBB801_L1] 
	,[GBB_801_VSD_Speed_Actual_]
	,[TS_80102_Frost_Stat_GBB801] 
	,[S_Air_Setpoint_GBB801] 
	,[Room_Setpoint_GBB801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC](
	[ReadingTime] 
	,[GBD801_Auto_Mode] 
	,[GBD801_Start_Command]
	,[GBD801_Manual_Mode])
SELECT 	[ReadingTime] 
	,[GBD801_Auto_Mode] 
	,[GBD801_Start_Command]
	,[GBD801_Manual_Mode]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote](
	[ReadingTime] 
	,[TS_80103_Frost_Stat_GBC801]
	,[Glb_Outside_Frost]
	,[TT80103A_S_Air_Mv_GBC801]
	,[HV80103_Frost_Valve_Actuator_GBC801] 
	,[TV80103_Heating_Vavle_Actuator_GBC801]
	,[S_Air_Setpoint_GBC801] 
	,[Room_Setpoint_GBC801]
)
SELECT [ReadingTime] 
	,[TS_80103_Frost_Stat_GBC801]
	,[Glb_Outside_Frost]
	,[TT80103A_S_Air_Mv_GBC801]
	,[HV80103_Frost_Valve_Actuator_GBC801] 
	,[TV80103_Heating_Vavle_Actuator_GBC801]
	,[S_Air_Setpoint_GBC801] 
	,[Room_Setpoint_GBC801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote](
	[ReadingTime] 
	,[TV80104_Heating_Valve_Actuator_GBD801] 
	,[HV80104_Frost_Valve_Actuator_GBD801] 
	,[TS_80104_Frost_Stat_GBD801] 
	,[TT80104A_S_Air_Mv_GBD801]
	,[GlB_Outside_Frost]
	,[S_Air_Setpoint_GBD801]
	,[Room_Setpoint_GBD801]
)
SELECT [ReadingTime] 
	,[TV80104_Heating_Valve_Actuator_GBD801] 
	,[HV80104_Frost_Valve_Actuator_GBD801] 
	,[TS_80104_Frost_Stat_GBD801] 
	,[TT80104A_S_Air_Mv_GBD801]
	,[GlB_Outside_Frost]
	,[S_Air_Setpoint_GBD801]
	,[Room_Setpoint_GBD801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps](
	[ReadingTime]
	,[A2nd_Floor_Process_temp]
	,[Room_Temperature_GBD801] 
	,[Room_Temperature2_GBA801] 
	,[Room_Temperature1_GBA801] 
	,[Room_Temperature_GBC801]
	,[GBD801_Run_Signal]
	,[A1st_Floor_Process_Temp]
	,[GBC801_Run_Signal])
SELECT 	[ReadingTime]
	,[A2nd_Floor_Process_temp]
	,[Room_Temperature_GBD801] 
	,[Room_Temperature2_GBA801] 
	,[Room_Temperature1_GBA801] 
	,[Room_Temperature_GBC801]
	,[GBD801_Run_Signal]
	,[A1st_Floor_Process_Temp]
	,[GBC801_Run_Signal]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC](
	[ReadingTime] 
	,[GBG801_Run_Signal_i] 
	,[GBE801_Run_Signal_i] 
	,[GBH801_Run_Signal_i])
SELECT [ReadingTime] 
	,[GBG801_Run_Signal_i] 
	,[GBE801_Run_Signal_i] 
	,[GBH801_Run_Signal_i]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote](
	[ReadingTime] 
	,[TT80105A_S_Air_Mv_GBE801] 
	,[Glb_Outside_Frost]
	,[TV80105_Heating_Vavle_Actuator_GBE801] 
	,[HV80105_Frost_Valve_Actuator_GBE801] 
	,[TS_80105_Frost_Stat_GBE801]
	,[S_Air_Setpoint_GBE801]
	,[Room_Setpoint_GBE801]
)
SELECT 	[ReadingTime] 
	,[TT80105A_S_Air_Mv_GBE801] 
	,[Glb_Outside_Frost]
	,[TV80105_Heating_Vavle_Actuator_GBE801] 
	,[HV80105_Frost_Valve_Actuator_GBE801] 
	,[TS_80105_Frost_Stat_GBE801]
	,[S_Air_Setpoint_GBE801]
	,[Room_Setpoint_GBE801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote](
	[ReadingTime]
	,[TV80107_Heating_Valve_Actuator_GBG801] 
	,[Glb_Outside_Frost] 
	,[TS_80107_Frost_Stat_GBG801]
	,[TT80107A_S_Air_Mv_GBG801] 
	,[HV80107_Frost_Valve_Actuator_GBG801]
	,[S_Air_Setpoint_GBG801]
	,[Room_Setpoint_GBG801] 
)
SELECT 	[ReadingTime]
	,[TV80107_Heating_Valve_Actuator_GBG801] 
	,[Glb_Outside_Frost] 
	,[TS_80107_Frost_Stat_GBG801]
	,[TT80107A_S_Air_Mv_GBG801] 
	,[HV80107_Frost_Valve_Actuator_GBG801]
	,[S_Air_Setpoint_GBG801]
	,[Room_Setpoint_GBG801] 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote](
	[ReadingTime] 
	,[Output_to_recirc_damper]
	,[TV80113_Cooling_Valve_GBH801] 
	,[MT80101A_S_Air_Humidity_GBH801] 
	,[TS_80110_Frost_Stat_GBH801]
	,[TV80110_Heating_Valve_GBH801] 
	,[XV80110_Control_Dampers_GBH801] 
	,[TT80103A_S_air_Mv_GBH801] 
	,[Supply_Temp_Setpoint_GBH801]
	,[Room_Setpoint_GBH801]
)
SELECT 	[ReadingTime] 
	,[Output_to_recirc_damper]
	,[TV80113_Cooling_Valve_GBH801] 
	,[MT80101A_S_Air_Humidity_GBH801] 
	,[TS_80110_Frost_Stat_GBH801]
	,[TV80110_Heating_Valve_GBH801] 
	,[XV80110_Control_Dampers_GBH801] 
	,[TT80103A_S_air_Mv_GBH801] 
	,[Supply_Temp_Setpoint_GBH801]
	,[Room_Setpoint_GBH801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote](
	[ReadingTime] 
	,[TV80115_Cooling_Valve_GBK801]
	,[TT80115A_S_air_Temp_Mv_GBK801_]
	,[TV80112_Heating_Valve_GBK801]
	,[Output_to_Recirc_Dampers]
	,[GBK_HUMIDIFIER]
	,[MT80102A_S_Air_Humidity_GBH801]
	,[XV80112_Control_Dampers_GBK801]
	,[Supply_Temp_Min_Spt]
	,[Supply_Temp_Max_Spt]
	,[Room_S_Pt]
)
SELECT 	[ReadingTime] 
	,[TV80115_Cooling_Valve_GBK801]
	,[TT80115A_S_air_Temp_Mv_GBK801_]
	,[TV80112_Heating_Valve_GBK801]
	,[Output_to_Recirc_Dampers]
	,[GBK_HUMIDIFIER]
	,[MT80102A_S_Air_Humidity_GBH801]
	,[XV80112_Control_Dampers_GBK801]
	,[Supply_Temp_Min_Spt]
	,[Supply_Temp_Max_Spt]
	,[Room_S_Pt]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH](
	[ReadingTime]
	,[GBJ803_Run_Signal]
	,[GBX803_Run_Signal]
	,[TT80105_Room_Temperature_GBE801]
	,[TT80113_Room_Temperature_GBH801]
	,[TT80115_Room_Temperature_GBK801]
	,[GBH803_Run_Signal]
	,[MT80102_Room_Humidity_GBK801]
	,[MT80101_Room_Humidity_GBH801]
	,[TT80107_Room_Temperature_GBG801]
	,[GBK802_Run_Signal]
	,[GBG801_Run_Signal]
	,[GBE801_Run_Signal]
	,[GBH801_Run_Signal]
	,[GBA806A_Run_Signal]
	,[TT80113_Room_Temp_Mv_GBH801]
	,[GBK801_Run_Signal]
	,[TT80107_Room_Temp_Mv_GBG801]
	,[MT80101_Room_RH_Mv_GBH801]
	,[TT80105_Room_Temp_Mv_GBE801] 
	,[GBT803_Run_Signal]
	,[TT80115_Room_Temp_V_GBK]
	,[MT80102_RoomRh_V_GHK801]
)
SELECT [ReadingTime]
	,[GBJ803_Run_Signal]
	,[GBX803_Run_Signal]
	,[TT80105_Room_Temperature_GBE801]
	,[TT80113_Room_Temperature_GBH801]
	,[TT80115_Room_Temperature_GBK801]
	,[GBH803_Run_Signal]
	,[MT80102_Room_Humidity_GBK801]
	,[MT80101_Room_Humidity_GBH801]
	,[TT80107_Room_Temperature_GBG801]
	,[GBK802_Run_Signal]
	,[GBG801_Run_Signal]
	,[GBE801_Run_Signal]
	,[GBH801_Run_Signal]
	,[GBA806A_Run_Signal]
	,[TT80113_Room_Temp_Mv_GBH801]
	,[GBK801_Run_Signal]
	,[TT80107_Room_Temp_Mv_GBG801]
	,[MT80101_Room_RH_Mv_GBH801]
	,[TT80105_Room_Temp_Mv_GBE801] 
	,[GBT803_Run_Signal]
	,[TT80115_Room_Temp_V_GBK]
	,[MT80102_RoomRh_V_GHK801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC](
	[ReadingTime]
	,[GBV803_Run_Signal_i])
SELECT 	[ReadingTime]
	,[GBV803_Run_Signal_i]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote](
	[ReadingTime] 
	,[TS_80108_Frost_Stat_GBL801]
	,[HV80108_Frost_Valve_Actuator_GBL801]
	,[TV80108_Heating_Valve_Actuator_GBL801]
	,[TT80108A_S_Air_Mv_GBL801]
)
SELECT 	[ReadingTime] 
	,[TS_80108_Frost_Stat_GBL801]
	,[HV80108_Frost_Valve_Actuator_GBL801]
	,[TV80108_Heating_Valve_Actuator_GBL801]
	,[TT80108A_S_Air_Mv_GBL801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote](
	[ReadingTime] 
	,[HV80109_Frost_Valve_Actuator_GBM801]
	,[TT80109A_S_Air_Mv_GBM801]
	,[outside_frost_graphic_display]
	,[TS_80109_Frost_Stat_GBM801]
	,[TV80109_Heating_Valve_Actuator_GBM801]
	,[S_Air_Setpoint_GBM801] 
	,[Room_Setpoint_GBM801]
)
SELECT 	[ReadingTime] 
	,[HV80109_Frost_Valve_Actuator_GBM801]
	,[TT80109A_S_Air_Mv_GBM801]
	,[outside_frost_graphic_display]
	,[TS_80109_Frost_Stat_GBM801]
	,[TV80109_Heating_Valve_Actuator_GBM801]
	,[S_Air_Setpoint_GBM801] 
	,[Room_Setpoint_GBM801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC](
	[ReadingTime]
	,[GBJ801_Start_Command]
) 
SELECT 	[ReadingTime]
	,[GBJ801_Start_Command]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote](
	[ReadingTime] 
	,[TT80116A_S_Air_Mv_GBQ801] 
	,[TS_80115_Frost_Stat_GBQ801] 
	,[HV80110_Frost_Valve_Actuator_GBQ801]
	,[outside_Frost_Display_for_Graphic] 
	,[TV80116_Heating_Vavle_Actuator_GBQ801]
	,[Room_Setpoint_GBQ801] 
	,[S_Air_Setpoint_GBQ801] 
)
SELECT 	[ReadingTime] 
	,[TT80116A_S_Air_Mv_GBQ801] 
	,[TS_80115_Frost_Stat_GBQ801] 
	,[HV80110_Frost_Valve_Actuator_GBQ801]
	,[outside_Frost_Display_for_Graphic] 
	,[TV80116_Heating_Vavle_Actuator_GBQ801]
	,[Room_Setpoint_GBQ801] 
	,[S_Air_Setpoint_GBQ801] 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote](
	[ReadingTime] 
	,[XV80111Dampers_GBJ801] 
	,[TS_80111_Frost_Stat_GBJ801]
	,[TV80111_Heating_Valve_GBJ801]
	,[Room_Setpoint_GBJ801_Graphic_]
	,[TT80114A_S_Air_Mv_GBJ801]
	,[TV80114_Cooling_Valve_GBJ801]
	,[GBJ_output_to_recirc_damper]
	,[Room_Setpoint_GBJ801]
	,[S_Air_Setpoint_GBJ801]
)
SELECT 	[ReadingTime] 
	,[XV80111Dampers_GBJ801] 
	,[TS_80111_Frost_Stat_GBJ801]
	,[TV80111_Heating_Valve_GBJ801]
	,[Room_Setpoint_GBJ801_Graphic_]
	,[TT80114A_S_Air_Mv_GBJ801]
	,[TV80114_Cooling_Valve_GBJ801]
	,[GBJ_output_to_recirc_damper]
	,[Room_Setpoint_GBJ801]
	,[S_Air_Setpoint_GBJ801]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp](
	[ReadingTime]
	,[TT80108_Room_Temperature_GBL801] 
	,[GBQ801_Run_Signal]
	,[TT80116_Room_Temperature_GBQ801] 
	,[GBM801A_Run_Signal] 
	,[GBJ801_Run_Signal]
	,[TT80109_Room_Tempertature_GBM801] 
	,[GBL801A_Run_Signal] 
	,[TT80114_Room_Temperature_GBJ801]
	,created_date
)
SELECT 	[ReadingTime]
	,[TT80108_Room_Temperature_GBL801] 
	,[GBQ801_Run_Signal]
	,[TT80116_Room_Temperature_GBQ801] 
	,[GBM801A_Run_Signal] 
	,[GBJ801_Run_Signal]
	,[TT80109_Room_Tempertature_GBM801] 
	,[GBL801A_Run_Signal] 
	,[TT80114_Room_Temperature_GBJ801]
	,getdate()
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure](
	[ReadingTime] 
	,[GBV803_Run_Signal] 
)
SELECT 	[ReadingTime] 
	,[GBV803_Run_Signal] 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans](
	[ReadingTime] 
	,[GB_809]
)
SELECT 	[ReadingTime] 
	,[GB_809]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_1F801_MCC]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_1F801_MCC](
	[ReadingTime]
	,[TT80106_Room_Temperature_GBF801] 
	,[TT80106a_Supply_Air_Temperature_GBF801]
	,[TV80106_Heating_Valve_GBF801]
	,[GB839_Run_Signal_i]
) 
SELECT 	[ReadingTime]
	,[TT80106_Room_Temperature_GBF801] 
	,[TT80106a_Supply_Air_Temperature_GBF801]
	,[TV80106_Heating_Valve_GBF801]
	,[GB839_Run_Signal_i]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_1F801_MCC')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_2B839_MCC]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_2B839_MCC](
	[ReadingTime] 
	,[LTHW_Valve]
	,[Max_Valve_Position] 
	,[TT80205_Room_Temperature] 
)
SELECT 	[ReadingTime] 
	,[LTHW_Valve]
	,[Max_Valve_Position] 
	,[TT80205_Room_Temperature] 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_2B839_MCC')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control](
	[ReadingTime]
	,[TT83901A_S_Air_Mv_GB839] 
	,[TT83901B_Room_Temperature_GB839]
	,[TT83901A_Room_Temperature_GB839]
	,[TV83901_Heating_Valve_Actuator_GB839]
	,[HV83901_Frost_Valve_Actuator_GB839]
	,[Room_Setpoint_GB839]
	,[S_Air_Setpoint_GB839]
	,[GB839_Run_Signal]
)
SELECT 	[ReadingTime]
	,[TT83901A_S_Air_Mv_GB839] 
	,[TT83901B_Room_Temperature_GB839]
	,[TT83901A_Room_Temperature_GB839]
	,[TV83901_Heating_Valve_Actuator_GB839]
	,[HV83901_Frost_Valve_Actuator_GB839]
	,[Room_Setpoint_GB839]
	,[S_Air_Setpoint_GB839]
	,[GB839_Run_Signal]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_5C_D_G802]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_5C_D_G802](
	[ReadingTime]
	,[TT80202_Room_Temperature]
	,[LTHW_Temp_Mv]
	,[LTHW_Supply_Mv]
	,[TT80207_Room_Temperature]
) 
SELECT 	[ReadingTime]
	,[TT80202_Room_Temperature]
	,[LTHW_Temp_Mv]
	,[LTHW_Supply_Mv]
	,[TT80207_Room_Temperature]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_5C_D_G802')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_6Chiller]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_6Chiller](
	[ReadingTime] 
	,[Chiller_GB835_Start] 
)
SELECT 	[ReadingTime] 
	,[Chiller_GB835_Start] 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_6Chiller')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System](
	[ReadingTime] 
	,[MCCExtract_Fan_GB_809_enable]
	,[MCC_Room_Temperature]
)
SELECT	[ReadingTime] 
	,[MCCExtract_Fan_GB_809_enable]
	,[MCC_Room_Temperature]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_007_UC3224]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_007_UC3224](
	[ReadingTime] 
	,[Drum_Warmer_Room_Temp_TT_72905] 
	,[AHU_Sup_Fan_Speed_SC_72901] 
	,[AHU_Inlet_Temp_TT_72901] 
	,[AHU_Ext_Fan_Speed_SC_72902] 
	,[AHU_Supply_Temp_TT_72903]
	,[GBY_806_Enabled]
)
SELECT 	[ReadingTime] 
	,[Drum_Warmer_Room_Temp_TT_72905] 
	,[AHU_Sup_Fan_Speed_SC_72901] 
	,[AHU_Inlet_Temp_TT_72901] 
	,[AHU_Ext_Fan_Speed_SC_72902] 
	,[AHU_Supply_Temp_TT_72903]
	,[GBY_806_Enabled]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_007_UC3224')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_008_UC3216]';

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_008_UC3216](
	[ReadingTime]
	,[AHU_3_Port_Heating_Valve_TV_72904]
) 
SELECT 	[ReadingTime]
	,[AHU_3_Port_Heating_Valve_TV_72904]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_008_UC3216')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_013_UC328]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_013_UC328](
	[ReadingTime]
	,[Ext_Fan_GBY_803_Motor_Ready]
	,[ST_80305_GBY_803_Ext_Fan_Speed_Feedback] 
	,[GBY_803_Speed_SP]
	,[SC_80305_GBY_803_Ext_Fan_Speed_Control]
	,[HLR_80305_Ext_Fan_GBY_803_Run]
)

SELECT 	[ReadingTime]
	,[Ext_Fan_GBY_803_Motor_Ready]
	,[ST_80305_GBY_803_Ext_Fan_Speed_Feedback] 
	,[GBY_803_Speed_SP]
	,[SC_80305_GBY_803_Ext_Fan_Speed_Control]
	,[HLR_80305_Ext_Fan_GBY_803_Run]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_013_UC328')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0501]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0501](
	[ReadingTime]
	,[A81_ACTUAL_VOLUME_L_S]
	,[A12_GBA_805_REHEAT_O_P] 
	,[A38_Average_Extract_Temp]
	,[D80_GBA_805_FROST_STAT_ACTIVATED]
	,[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP]
	,[A11_GBA_805_PREHEAT_O_P]
	,[A51_R_S_GBA_805_S_A_T_] 
	,[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP]
	,[OFF_COIL_TEMP] 
	,[A25_FROST_COIL_S_P] 
	,[Supply_Temp_Min_Spt] 
	,[Supply_Temp_Max_Spt]
	,[A28_AHU_CONTROL_S_P]
)
SELECT 	[ReadingTime]
	,[A81_ACTUAL_VOLUME_L_S]
	,[A12_GBA_805_REHEAT_O_P] 
	,[A38_Average_Extract_Temp]
	,[D80_GBA_805_FROST_STAT_ACTIVATED]
	,[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP]
	,[A11_GBA_805_PREHEAT_O_P]
	,[A51_R_S_GBA_805_S_A_T_] 
	,[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP]
	,[OFF_COIL_TEMP] 
	,[A25_FROST_COIL_S_P] 
	,[Supply_Temp_Min_Spt] 
	,[Supply_Temp_Max_Spt]
	,[A28_AHU_CONTROL_S_P]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0501')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0502]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0502](
	[ReadingTime]
	,[A82_CAL_INVERTOR_HZ_]
	,[A16_GBC_805_EXTRACT_FAN_VSD_O_P]
	,[A08_R351_353_NUSCHE_D_P]
	,[A15_GBA_805_VSD_O_P]
	,[A07_R356_SCHENK_FILTER_D_P]
	,[A05_R357_B_FILTER_D_P]
	,[A03_R552_CONT_IBC_D_P]
	,[A01_R553_PERSONNEL_A_L_D_P]
	,[A04_R551_GA_785_ROOM_D_P]
	,[A06_R355_PERSONNEL_A_L_D_P] 
	,[A02_R544_MATERIALS_A_L_D_P]
)
SELECT 	[ReadingTime]
	,[A82_CAL_INVERTOR_HZ_]
	,[A16_GBC_805_EXTRACT_FAN_VSD_O_P]
	,[A08_R351_353_NUSCHE_D_P]
	,[A15_GBA_805_VSD_O_P]
	,[A07_R356_SCHENK_FILTER_D_P]
	,[A05_R357_B_FILTER_D_P]
	,[A03_R552_CONT_IBC_D_P]
	,[A01_R553_PERSONNEL_A_L_D_P]
	,[A04_R551_GA_785_ROOM_D_P]
	,[A06_R355_PERSONNEL_A_L_D_P] 
	,[A02_R544_MATERIALS_A_L_D_P]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0502')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0503]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0503](
	[ReadingTime]
	,[A04_R251_254_CONT_DRYER_D_P]
	,[A03_R253_PERSONNEL_A_L_D_P]
	,[A08_R153_TANK_ROOM_D_P]
	,[A06_R154_PERSONNEL_A_L_D_P]
	,[A02_R451_DC_725_AREA_D_P]
	,[A07_R152_CONT_PRODUCT_D_P]
	,[A41_R453_PERSONNEL_A_L_D_P] 
	,[A45_R155_PRODUCT_A_L_D_P]
) 

SELECT 	[ReadingTime]
	,[A04_R251_254_CONT_DRYER_D_P]
	,[A03_R253_PERSONNEL_A_L_D_P]
	,[A08_R153_TANK_ROOM_D_P]
	,[A06_R154_PERSONNEL_A_L_D_P]
	,[A02_R451_DC_725_AREA_D_P]
	,[A07_R152_CONT_PRODUCT_D_P]
	,[A41_R453_PERSONNEL_A_L_D_P] 
	,[A45_R155_PRODUCT_A_L_D_P]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0503')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_4Extract]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_4Extract](
	[ReadingTime] 
	,[Rm_Press_No_2] 
	,[Rm_Press_No_1]
	,[VSD_No_1_Speed_Control_] 
	,[VSD_Speed_Control_Output]
	,[Actual_Duct_Press_No_2] 
	,[Actual_Duct_Press_No_1] 
	,[Actual_volume] 
	,[VSD_No_2_Speed_Control] 
)
SELECT 	[ReadingTime] 
	,[Rm_Press_No_2] 
	,[Rm_Press_No_1]
	,[VSD_No_1_Speed_Control_] 
	,[VSD_Speed_Control_Output]
	,[Actual_Duct_Press_No_2] 
	,[Actual_Duct_Press_No_1] 
	,[Actual_volume] 
	,[VSD_No_2_Speed_Control] 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_4Extract')

GO

print 'INSERT INTO  [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_5Downflow_booth]'

INSERT INTO  [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_5Downflow_booth](
	[ReadingTime] 
	,[A759_TE_34_R] 
	,[A725_TE_34_R]
	,[TE_76034]
	,[A751_TE_34_R]
	,[A750_TE_34_R]
	,[A726_TE_34]
) 
SELECT 	[ReadingTime] 
	,[A759_TE_34_R] 
	,[A725_TE_34_R]
	,[TE_76034]
	,[A751_TE_34_R]
	,[A750_TE_34_R]
	,[A726_TE_34]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_5Downflow_booth')

GO

print 'INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_6GBN_801]'

INSERT INTO [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_6GBN_801](
	[ReadingTime] 
	,[GBN_801_Airflow]
	,[GBN_802_Run_Signal]
	,[GBM_802_Run_Signal] 
	,[GBN_801_Fan_Enable] 
	,[Fan_Enable]
)
SELECT 	[ReadingTime] 
	,[GBN_801_Airflow]
	,[GBN_802_Run_Signal]
	,[GBM_802_Run_Signal] 
	,[GBN_801_Fan_Enable] 
	,[Fan_Enable]
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_6GBN_801')

GO
;



