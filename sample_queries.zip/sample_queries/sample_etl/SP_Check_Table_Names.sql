USE [IOT_ETL_ENERGY_ECS]
GO

ALTER PROCEDURE [energy_ecs_ahu].[SP_Check_Table_Names](@flag INT OUTPUT)
AS
BEGIN

declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @row_count as int
set @flag=0

	exec energy_ecs_ahu.[SP_Merge_StartLog] 'Checking table name','iot_energy_ecs_rng', 'energy_ecs_ahu', @log_id output

	BEGIN TRY
		
		-- declare @row_count as int
		SELECT @row_count=count(table_name)
		FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT table_name FROM information_schema.tables WHERE table_schema=''iot_energy_ecs_rng''') a
		WHERE NOT EXISTS (SELECT TABLE_NAME FROM information_schema.tables b WHERE TABLE_CATALOG='IOT_ETL_ENERGY_ECS' and TABLE_SCHEMA='energy_ecs_ahu' and b.TABLE_NAME=a.table_name);
		-- select @row_count
	END TRY  
	BEGIN CATCH  
		set @errMsg = error_message()
		set @errNo = error_number()
	END CATCH;

	if isnull(@errNo,0) <> 0 and @row_count <> 0
	begin 

		-- close the log 
		set @message = 'Checking table name failed or different table name.'
		set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
		exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage

		set @flag=1
	end

	if isnull(@errNo,0) = 0 and @row_count = 0 -- closing merge
	begin 
		set @logmessage = 'Checking table name completed: '
		/*
		+ cast(isnull(@insertedRow,0) as varchar) + ' rows inserted. '
		+ cast(isnull(@updatedRow,0) as varchar) + ' rows updated.'

		update energy_ecs_ahu.IMEX_Logs
		set inserted=isnull(@insertedRow,0)
		,updated=isnull(@updatedRow,0)
		where ID = @log_id;
		*/

		exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

		set @flag=0

	end
END;

