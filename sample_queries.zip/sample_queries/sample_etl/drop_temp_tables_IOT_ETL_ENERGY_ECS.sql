CREATE PROCEDURE SP_Drop_Temp_Tables
AS

DECLARE @STRSQL NVARCHAR(MAX);

DECLARE @TABLE NVARCHAR(128);

DECLARE @SCHEMA VARCHAR(100)

SET @SCHEMA = 'iot_energy_ecs_rng'

DECLARE @SCHEMA_NAME VARCHAR(100)

SET @SCHEMA_NAME = 'energy_ecs_ahu'

SET @STRSQL = '';

DECLARE @C1 CURSOR

SET @C1 = CURSOR FOR

select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME like '##%'

OPEN @C1

FETCH NEXT

FROM @C1 INTO @TABLE

WHILE @@FETCH_STATUS = 0

BEGIN

--PRINT @TABLE

SET @STRSQL = @STRSQL + 'IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''' + @TABLE + '''' + ') DROP TABLE ' + @TABLE + ';';

--PRINT @STRSQL

EXEC sp_executesql @STRSQL;

SET @STRSQL = '';

FETCH NEXT

FROM @C1 INTO @TABLE

END

CLOSE @C1

DEALLOCATE @C1

