USE [IOT_ENERGY_ECS]

GO

SET IDENTITY_INSERT [IOT_ENERGY_ECS].[ahu].[IOT_BUILDING] ON

INSERT INTO [IOT_ENERGY_ECS].[ahu].[IOT_BUILDING]
           ([building_id]
		   ,[building_name]
           ,[createdby]
           ,[createdat]
           ,[modifiedby]
           ,[modifiedat])
SELECT [building_id]
	  ,[building_name]
      ,[createdby]
      ,[createdat]
      ,[modifiedby]
      ,[modifiedat]
FROM [IOT_ENERGY_AHU].[dbo].[IOT_BUILDING]

SET IDENTITY_INSERT [IOT_ENERGY_ECS].[ahu].[IOT_BUILDING] OFF

GO

INSERT INTO [IOT_ENERGY_ECS].[ahu].[IOT_AHU]
           ([AHU_id]
           ,[AHU_Name]
           ,[building_id]
           ,[Air_Flowrate_at_High_Speed]
           ,[Air_Flowrate_at_Low_Speed]
           ,[Fan_Motor_Rating_kW]
           ,[VSD_Flag]
           ,[Fan_Elec_load_at_Full_Speed_kW]
           ,[Fan_Elec_Load_at_low_Speed_kW]
           ,[Optimum_Space_Air_SP_16_C]
           ,[Optimum_Space_Air_SP_18_C]
           ,[createdby]
           ,[createdat]
           ,[modifiedby]
           ,[modifiedat])
SELECT [AHU_id]
      ,[AHU_Name]
      ,[building_id]
      ,[Air_Flowrate_at_High_Speed]
      ,[Air_Flowrate_at_Low_Speed]
      ,[Fan_Motor_Rating_kW]
      ,[VSD_Flag]
      ,[Fan_Elec_load_at_Full_Speed_kW]
      ,[Fan_Elec_Load_at_low_Speed_kW]
      ,[Optimum_Space_Air_SP_16_C]
      ,[Optimum_Space_Air_SP_18_C]
      ,[createdby]
      ,[createdat]
      ,[modifiedby]
      ,[modifiedat]
  FROM [IOT_ENERGY_AHU].[dbo].[IOT_AHU]

GO

INSERT INTO [IOT_ENERGY_ECS].[ahu].[IOT_EnergyCostSettings]
           ([energy_type]
           ,[energy_type_value]
           ,[energy_unit]
           ,[system_name]
           ,[createdby]
           ,[createdat]
           ,[modifiedby]
           ,[modifiedat])
SELECT [energy_type]
      ,[energy_type_value]
      ,[energy_unit]
      ,[system_name]
      ,[createdby]
      ,[createdat]
      ,[modifiedby]
      ,[modifiedat]
  FROM [IOT_ENERGY_AHU].[dbo].[IOT_EnergyCostSettings]

GO

INSERT INTO [IOT_ENERGY_ECS].[ahu].[IOT_CONSTANT_VALUES]
           ([constant_name]
           ,[constant_value]
           ,[constant_value_unit]
           ,[createdby]
           ,[createdat]
           ,[modifiedby]
           ,[modifiedat]
           ,[constant_value_unit_symbol])
SELECT [constant_name]
      ,[constant_value]
      ,[constant_value_unit]
      ,[createdby]
      ,[createdat]
      ,[modifiedby]
      ,[modifiedat]
      ,[constant_value_unit_symbol]
  FROM [IOT_ENERGY_AHU].[dbo].[IOT_CONSTANT_VALUES]

GO

SET IDENTITY_INSERT [IOT_ENERGY_ECS].[ahu].[IOT_Alert_Rule_Details] ON

INSERT INTO [IOT_ENERGY_ECS].[ahu].[IOT_Alert_Rule_Details]
           ([Alert_Rule_Details_id]
		   ,[rule_id]
           ,[rule_category]
           ,[rule_description]
           ,[rule_criteria]
           ,[rule_criteria_Unit]
           ,[rule_criteria_op]
           ,[rule_criteria_value]
           ,[rule_duration]
           ,[rule_duration_op]
           ,[rule_duration_unit]
           ,[rule_enable_yn]
           ,[rule_priority]
           ,[rule_frequency]
           ,[rule_key]
           ,[created_by]
           ,[create_date]
           ,[modified_by]
           ,[modified_date])
SELECT [Alert_Rule_Details_id]
      ,[rule_id]
      ,[rule_category]
      ,[rule_description]
      ,[rule_criteria]
      ,[rule_criteria_Unit]
      ,[rule_criteria_op]
      ,[rule_criteria_value]
      ,[rule_duration]
      ,[rule_duration_op]
      ,[rule_duration_unit]
      ,[rule_enable_yn]
      ,[rule_priority]
      ,[rule_frequency]
      ,[rule_key]
      ,[created_by]
      ,[create_date]
      ,[modified_by]
      ,[modified_date]
  FROM [IOT_ENERGY_AHU].[dbo].[IOT_Alert_Rule_Details]

SET IDENTITY_INSERT [IOT_ENERGY_ECS].[ahu].[IOT_Alert_Rule_Details] OFF

GO

SET IDENTITY_INSERT [IOT_ENERGY_ECS].[ahu].[IOT_Alert_Rule_AHU_Mapping] ON

INSERT INTO [IOT_ENERGY_ECS].[ahu].[IOT_Alert_Rule_AHU_Mapping]
           ([Alert_Rule_Mapping_id]
		   ,[AHU_ID]
           ,[rule_enable_yn]
           ,[created_by]
           ,[create_date]
           ,[modified_by]
           ,[modified_date])
SELECT  [Alert_Rule_Mapping_id]
      ,[AHU_ID]
      ,[rule_enable_yn]
      ,[created_by]
      ,[create_date]
      ,[modified_by]
      ,[modified_date]
  FROM [IOT_ENERGY_AHU].[dbo].[IOT_Alert_Rule_AHU_Mapping]

SET IDENTITY_INSERT [IOT_ENERGY_ECS].[ahu].[IOT_Alert_Rule_AHU_Mapping] OFF

GO

INSERT INTO [IOT_ENERGY_ECS].[ahu].[EUSP_EquipmentCategory]
           ([SystemType]
           ,[EquipmentType]
           ,[CreatedBy]
           ,[CreatedAt]
           ,[ModifiedBy]
           ,[ModifiedAt]
           ,[equipment_name])
SELECT [SystemType]
      ,[EquipmentType]
      ,[CreatedBy]
      ,[CreatedAt]
      ,[ModifiedBy]
      ,[ModifiedAt]
      ,[equipment_name]
  FROM [IOT_ENERGY_AHU].[dbo].[EUSP_EquipmentCategory]

