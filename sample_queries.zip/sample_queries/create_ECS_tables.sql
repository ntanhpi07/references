USE [IOT_ETL_ENERGY_ECS]
GO
/*
CREATE TABLE [energy_ecs_ahu].[DB_ETL_ERRORS](
	[ErrorID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](100) NULL,
	[Table_Name] [varchar](100) NULL,
	[ErrorNumber] [int] NULL,
	[ErrorState] [int] NULL,
	[ErrorSeverity] [int] NULL,
	[ErrorLine] [int] NULL,
	[ErrorProcedure] [varchar](max) NULL,
	[ErrorMessage] [varchar](max) NULL,
	[ErrorDateTime] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

CREATE TABLE [energy_ecs_ahu].[DB_ETL_LOGS](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](100) NULL,
	[ProcessName] [varchar](100) NULL,
	[Table_Name] [varchar](100) NULL,
	[Rows_Affected] [int] NULL,
	[LoadDateTime] [datetime] NULL
) ON [PRIMARY]

GO

CREATE TABLE [energy_ecs_ahu].[IIOT_ETL_TABLES](
	[TBL_NAME] [nvarchar](1000) NULL
) ON [PRIMARY]

GO
*/

CREATE TABLE [energy_ecs_ahu].[Alarms](
	[alarmid] [bigint] NOT NULL,
	[applicationname] [varchar](255) NULL,
	[alarmname] [varchar](125) NULL,
	[occurrencedate] [datetime2](7) NULL,
	[description] [varchar](255) NULL,
	[value] [varchar](255) NULL,
	[priority] [int] NULL,
	[status] [varchar](255) NULL,
	[ackdate] [datetime2](7) NULL,
	[ackwho] [varchar](255) NULL,
	[cleardate] [datetime2](7) NULL,
	[clearwho] [varchar](255) NULL,
	[comment] [varchar](255) NULL,
	[unitid] [int] NULL,
	[channel] [varchar](4) NULL,
	[exceptionclass] [int] NULL,
	[causecode] [int] NULL,
 CONSTRAINT [PK_Alarms] PRIMARY KEY CLUSTERED 
(
	[alarmid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[AuditTrail]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[AuditTrail](
	[audittrailid] [bigint] NOT NULL,
	[occurrencedate] [datetime2](7) NULL,
	[username] [varchar](125) NULL,
	[priority] [int] NULL,
	[uiComponent] [varchar](255) NULL,
	[disposition] [varchar](255) NULL,
	[auditMessage] [varchar](255) NULL,
	[newvalue] [varchar](125) NULL,
	[auditTrailManager] [varchar](255) NULL,
	[description] [varchar](255) NULL,
	[auditTrailManagerId] [varchar](255) NULL,
	[origin] [varchar](255) NULL,
	[previousValue] [varchar](255) NULL,
 CONSTRAINT [PK_AuditTrail] PRIMARY KEY CLUSTERED 
(
	[audittrailid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MapEvents]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MapEvents](
	[eventid] [bigint] NOT NULL,
	[occurrencedate] [datetime2](7) NULL,
	[eventtype] [varchar](125) NULL,
	[priority] [int] NULL,
	[source] [varchar](255) NULL,
	[description] [varchar](255) NULL,
	[origin] [varchar](255) NULL,
 CONSTRAINT [PK_MapEvents] PRIMARY KEY CLUSTERED 
(
	[eventid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [energy_ecs_ahu].[MapStatus]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MapStatus](
	[ReadingTime] [datetime2](7) NULL,
	[ElapsedSparklineSecs] [float] NULL,
	[ElapsedSummarySecs] [float] NULL,
	[ElapsedAlarmSecs] [float] NULL,
	[ElapsedTrendSecs] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MemoryStatus]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MemoryStatus](
	[ReadingTime] [datetime2](7) NULL,
	[JvmTotal] [float] NULL,
	[CombinedFree] [float] NULL,
	[SystemTotal] [float] NULL,
	[SystemFree] [float] NULL,
	[JvmFree] [float] NULL,
	[SwapFree] [float] NULL,
	[SwapTotal] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC](
	[ReadingTime] [datetime2](7) NULL,
	[GBC801_Run_Signal_i] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[GBA_801_VSD_Speed_Actual_] [float] NULL,
	[TT80101A_Supply_Air_Temperature_GBA801] [float] NULL,
	[O_P_Glb_Outside_Frost] [int] NULL,
	[TV80101_Heating_Vavle_Actuator_GBA801] [float] NULL,
	[HV80101_Frost_Valve_Actuator_GBA801] [float] NULL,
	[TT801150_Outside_Air] [float] NULL,
	[TS_80101_Frost_Stat_GBA801] [int] NULL,
	[S_Air_Setpoint_GBA801] [float] NULL,
	[Room_Setpoint_GBA801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[HV80102_Frost_Valve_Actuator_GBB801] [float] NULL,
	[TT80102A_Supply_Air_Temperature_GBB801_L5] [float] NULL,
	[TV80102_Heating_Valve_Actuator_GBB801] [float] NULL,
	[TT80102A_Supply_Air_Temperature_GBB801_L1] [float] NULL,
	[GBB_801_VSD_Speed_Actual_] [float] NULL,
	[TS_80102_Frost_Stat_GBB801] [int] NULL,
	[S_Air_Setpoint_GBB801] [float] NULL,
	[Room_Setpoint_GBB801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC](
	[ReadingTime] [datetime2](7) NULL,
	[GBD801_Auto_Mode] [int] NULL,
	[GBD801_Start_Command] [int] NULL,
	[GBD801_Manual_Mode] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[TS_80103_Frost_Stat_GBC801] [int] NULL,
	[Glb_Outside_Frost] [int] NULL,
	[TT80103A_S_Air_Mv_GBC801] [float] NULL,
	[HV80103_Frost_Valve_Actuator_GBC801] [int] NULL,
	[TV80103_Heating_Vavle_Actuator_GBC801] [float] NULL,
	[S_Air_Setpoint_GBC801] [float] NULL,
	[Room_Setpoint_GBC801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[TV80104_Heating_Valve_Actuator_GBD801] [float] NULL,
	[HV80104_Frost_Valve_Actuator_GBD801] [int] NULL,
	[TS_80104_Frost_Stat_GBD801] [int] NULL,
	[TT80104A_S_Air_Mv_GBD801] [float] NULL,
	[GlB_Outside_Frost] [int] NULL,
	[S_Air_Setpoint_GBD801] [float] NULL,
	[Room_Setpoint_GBD801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps](
	[ReadingTime] [datetime2](7) NULL,
	[A2nd_Floor_Process_temp] [float] NULL,
	[Room_Temperature_GBD801] [float] NULL,
	[Room_Temperature2_GBA801] [float] NULL,
	[Room_Temperature1_GBA801] [float] NULL,
	[Room_Temperature_GBC801] [float] NULL,
	[GBD801_Run_Signal] [int] NULL,
	[A1st_Floor_Process_Temp] [float] NULL,
	[GBC801_Run_Signal] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC](
	[ReadingTime] [datetime2](7) NULL,
	[GBG801_Run_Signal_i] [int] NULL,
	[GBE801_Run_Signal_i] [int] NULL,
	[GBH801_Run_Signal_i] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[TT80105A_S_Air_Mv_GBE801] [float] NULL,
	[Glb_Outside_Frost] [int] NULL,
	[TV80105_Heating_Vavle_Actuator_GBE801] [float] NULL,
	[HV80105_Frost_Valve_Actuator_GBE801] [int] NULL,
	[TS_80105_Frost_Stat_GBE801] [int] NULL,
	[S_Air_Setpoint_GBE801] [float] NULL,
	[Room_Setpoint_GBE801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[TV80107_Heating_Valve_Actuator_GBG801] [float] NULL,
	[Glb_Outside_Frost] [int] NULL,
	[TS_80107_Frost_Stat_GBG801] [int] NULL,
	[TT80107A_S_Air_Mv_GBG801] [float] NULL,
	[HV80107_Frost_Valve_Actuator_GBG801] [int] NULL,
	[S_Air_Setpoint_GBG801] [float] NULL,
	[Room_Setpoint_GBG801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[Output_to_recirc_damper] [float] NULL,
	[TV80113_Cooling_Valve_GBH801] [float] NULL,
	[MT80101A_S_Air_Humidity_GBH801] [float] NULL,
	[TS_80110_Frost_Stat_GBH801] [int] NULL,
	[TV80110_Heating_Valve_GBH801] [float] NULL,
	[XV80110_Control_Dampers_GBH801] [float] NULL,
	[TT80103A_S_air_Mv_GBH801] [float] NULL,
	[Supply_Temp_Setpoint_GBH801] [float] NULL,
	[Room_Setpoint_GBH801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[TV80115_Cooling_Valve_GBK801] [float] NULL,
	[TT80115A_S_air_Temp_Mv_GBK801_] [float] NULL,
	[TV80112_Heating_Valve_GBK801] [float] NULL,
	[Output_to_Recirc_Dampers] [float] NULL,
	[GBK_HUMIDIFIER] [float] NULL,
	[MT80102A_S_Air_Humidity_GBH801] [float] NULL,
	[XV80112_Control_Dampers_GBK801] [float] NULL,
	[Supply_Temp_Min_Spt] [float] NULL,
	[Supply_Temp_Max_Spt] [float] NULL,
	[Room_S_Pt] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH](
	[ReadingTime] [datetime2](7) NULL,
	[GBJ803_Run_Signal] [int] NULL,
	[GBX803_Run_Signal] [int] NULL,
	[TT80105_Room_Temperature_GBE801] [float] NULL,
	[TT80113_Room_Temperature_GBH801] [float] NULL,
	[TT80115_Room_Temperature_GBK801] [float] NULL,
	[GBH803_Run_Signal] [int] NULL,
	[MT80102_Room_Humidity_GBK801] [float] NULL,
	[MT80101_Room_Humidity_GBH801] [float] NULL,
	[TT80107_Room_Temperature_GBG801] [float] NULL,
	[GBK802_Run_Signal] [int] NULL,
	[GBG801_Run_Signal] [int] NULL,
	[GBE801_Run_Signal] [int] NULL,
	[GBH801_Run_Signal] [int] NULL,
	[GBA806A_Run_Signal] [int] NULL,
	[TT80113_Room_Temp_Mv_GBH801] [float] NULL,
	[GBK801_Run_Signal] [int] NULL,
	[TT80107_Room_Temp_Mv_GBG801] [float] NULL,
	[MT80101_Room_RH_Mv_GBH801] [float] NULL,
	[TT80105_Room_Temp_Mv_GBE801] [float] NULL,
	[GBT803_Run_Signal] [int] NULL,
	[TT80115_Room_Temp_V_GBK] [float] NULL,
	[MT80102_RoomRh_V_GHK801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC](
	[ReadingTime] [datetime2](7) NULL,
	[GBV803_Run_Signal_i] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[TS_80108_Frost_Stat_GBL801] [int] NULL,
	[HV80108_Frost_Valve_Actuator_GBL801] [int] NULL,
	[TV80108_Heating_Valve_Actuator_GBL801] [float] NULL,
	[TT80108A_S_Air_Mv_GBL801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[HV80109_Frost_Valve_Actuator_GBM801] [int] NULL,
	[TT80109A_S_Air_Mv_GBM801] [float] NULL,
	[outside_frost_graphic_display] [int] NULL,
	[TS_80109_Frost_Stat_GBM801] [int] NULL,
	[TV80109_Heating_Valve_Actuator_GBM801] [float] NULL,
	[S_Air_Setpoint_GBM801] [float] NULL,
	[Room_Setpoint_GBM801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC](
	[ReadingTime] [datetime2](7) NULL,
	[GBJ801_Start_Command] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[TT80116A_S_Air_Mv_GBQ801] [float] NULL,
	[TS_80115_Frost_Stat_GBQ801] [int] NULL,
	[HV80110_Frost_Valve_Actuator_GBQ801] [int] NULL,
	[outside_Frost_Display_for_Graphic] [int] NULL,
	[TV80116_Heating_Vavle_Actuator_GBQ801] [float] NULL,
	[Room_Setpoint_GBQ801] [float] NULL,
	[S_Air_Setpoint_GBQ801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote](
	[ReadingTime] [datetime2](7) NULL,
	[XV80111Dampers_GBJ801] [float] NULL,
	[TS_80111_Frost_Stat_GBJ801] [int] NULL,
	[TV80111_Heating_Valve_GBJ801] [float] NULL,
	[Room_Setpoint_GBJ801_Graphic_] [float] NULL,
	[TT80114A_S_Air_Mv_GBJ801] [float] NULL,
	[TV80114_Cooling_Valve_GBJ801] [float] NULL,
	[GBJ_output_to_recirc_damper] [float] NULL,
	[Room_Setpoint_GBJ801] [float] NULL,
	[S_Air_Setpoint_GBJ801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp](
	[ReadingTime] [datetime2](7) NULL,
	[TT80108_Room_Temperature_GBL801] [float] NULL,
	[GBQ801_Run_Signal] [int] NULL,
	[TT80116_Room_Temperature_GBQ801] [float] NULL,
	[GBM801A_Run_Signal] [int] NULL,
	[GBJ801_Run_Signal] [int] NULL,
	[TT80109_Room_Tempertature_GBM801] [float] NULL,
	[GBL801A_Run_Signal] [int] NULL,
	[TT80114_Room_Temperature_GBJ801] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure](
	[ReadingTime] [datetime2](7) NULL,
	[GBV803_Run_Signal] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans](
	[ReadingTime] [datetime2](7) NULL,
	[GB_809] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_1F801_MCC]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_1F801_MCC](
	[ReadingTime] [datetime2](7) NULL,
	[TT80106_Room_Temperature_GBF801] [float] NULL,
	[TT80106a_Supply_Air_Temperature_GBF801] [float] NULL,
	[TV80106_Heating_Valve_GBF801] [float] NULL,
	[GB839_Run_Signal_i] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_2B839_MCC]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_2B839_MCC](
	[ReadingTime] [datetime2](7) NULL,
	[LTHW_Valve] [float] NULL,
	[Max_Valve_Position] [float] NULL,
	[TT80205_Room_Temperature] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control](
	[ReadingTime] [datetime2](7) NULL,
	[TT83901A_S_Air_Mv_GB839] [float] NULL,
	[TT83901B_Room_Temperature_GB839] [float] NULL,
	[TT83901A_Room_Temperature_GB839] [float] NULL,
	[TV83901_Heating_Valve_Actuator_GB839] [float] NULL,
	[HV83901_Frost_Valve_Actuator_GB839] [int] NULL,
	[Room_Setpoint_GB839] [float] NULL,
	[S_Air_Setpoint_GB839] [float] NULL,
	[GB839_Run_Signal] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_5C_D_G802]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_5C_D_G802](
	[ReadingTime] [datetime2](7) NULL,
	[TT80202_Room_Temperature] [float] NULL,
	[LTHW_Temp_Mv] [float] NULL,
	[LTHW_Supply_Mv] [float] NULL,
	[TT80207_Room_Temperature] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_6Chiller]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_6Chiller](
	[ReadingTime] [datetime2](7) NULL,
	[Chiller_GB835_Start] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System](
	[ReadingTime] [datetime2](7) NULL,
	[MCCExtract_Fan_GB_809_enable] [int] NULL,
	[MCC_Room_Temperature] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_007_UC3224]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_007_UC3224](
	[ReadingTime] [datetime2](7) NULL,
	[Drum_Warmer_Room_Temp_TT_72905] [float] NULL,
	[AHU_Sup_Fan_Speed_SC_72901] [float] NULL,
	[AHU_Inlet_Temp_TT_72901] [float] NULL,
	[AHU_Ext_Fan_Speed_SC_72902] [float] NULL,
	[AHU_Supply_Temp_TT_72903] [float] NULL,
	[GBY_806_Enabled] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_008_UC3216]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_008_UC3216](
	[ReadingTime] [datetime2](7) NULL,
	[AHU_3_Port_Heating_Valve_TV_72904] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_013_UC328]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_013_UC328](
	[ReadingTime] [datetime2](7) NULL,
	[Ext_Fan_GBY_803_Motor_Ready] [int] NULL,
	[ST_80305_GBY_803_Ext_Fan_Speed_Feedback] [float] NULL,
	[GBY_803_Speed_SP] [float] NULL,
	[SC_80305_GBY_803_Ext_Fan_Speed_Control] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0501]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0501](
	[ReadingTime] [datetime2](7) NULL,
	[A81_ACTUAL_VOLUME_L_S] [float] NULL,
	[A12_GBA_805_REHEAT_O_P] [float] NULL,
	[A38_Average_Extract_Temp] [float] NULL,
	[D80_GBA_805_FROST_STAT_ACTIVATED] [int] NULL,
	[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP] [float] NULL,
	[A11_GBA_805_PREHEAT_O_P] [float] NULL,
	[A51_R_S_GBA_805_S_A_T_] [float] NULL,
	[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP] [float] NULL,
	[OFF_COIL_TEMP] [float] NULL,
	[A25_FROST_COIL_S_P] [float] NULL,
	[Supply_Temp_Min_Spt] [float] NULL,
	[Supply_Temp_Max_Spt] [float] NULL,
	[A28_AHU_CONTROL_S_P] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0502]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0502](
	[ReadingTime] [datetime2](7) NULL,
	[A82_CAL_INVERTOR_HZ_] [float] NULL,
	[A16_GBC_805_EXTRACT_FAN_VSD_O_P] [float] NULL,
	[A08_R351_353_NUSCHE_D_P] [float] NULL,
	[A15_GBA_805_VSD_O_P] [float] NULL,
	[A07_R356_SCHENK_FILTER_D_P] [float] NULL,
	[A05_R357_B_FILTER_D_P] [float] NULL,
	[A03_R552_CONT_IBC_D_P] [float] NULL,
	[A01_R553_PERSONNEL_A_L_D_P] [float] NULL,
	[A04_R551_GA_785_ROOM_D_P] [float] NULL,
	[A06_R355_PERSONNEL_A_L_D_P] [float] NULL,
	[A02_R544_MATERIALS_A_L_D_P] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0503]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_0503](
	[ReadingTime] [datetime2](7) NULL,
	[A04_R251_254_CONT_DRYER_D_P] [float] NULL,
	[A03_R253_PERSONNEL_A_L_D_P] [float] NULL,
	[A08_R153_TANK_ROOM_D_P] [float] NULL,
	[A06_R154_PERSONNEL_A_L_D_P] [float] NULL,
	[A02_R451_DC_725_AREA_D_P] [float] NULL,
	[A07_R152_CONT_PRODUCT_D_P] [float] NULL,
	[A41_R453_PERSONNEL_A_L_D_P] [float] NULL,
	[A45_R155_PRODUCT_A_L_D_P] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_4Extract]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_4Extract](
	[ReadingTime] [datetime2](7) NULL,
	[Rm_Press_No_2] [float] NULL,
	[Rm_Press_No_1] [float] NULL,
	[VSD_No_1_Speed_Control_] [float] NULL,
	[VSD_Speed_Control_Output] [float] NULL,
	[Actual_Duct_Press_No_2] [float] NULL,
	[Actual_Duct_Press_No_1] [float] NULL,
	[Actual_volume] [float] NULL,
	[VSD_No_2_Speed_Control] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_5Downflow_booth]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_5Downflow_booth](
	[ReadingTime] [datetime2](7) NULL,
	[A759_TE_34_R] [float] NULL,
	[A725_TE_34_R] [float] NULL,
	[TE_76034] [float] NULL,
	[A751_TE_34_R] [float] NULL,
	[A750_TE_34_R] [float] NULL,
	[A726_TE_34] [float] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_6GBN_801]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [energy_ecs_ahu].[MTrend__n1_osp3_5Annex_6GBN_801](
	[ReadingTime] [datetime2](7) NULL,
	[GBN_801_Airflow] [int] NULL,
	[GBN_802_Run_Signal] [int] NULL,
	[GBM_802_Run_Signal] [int] NULL,
	[GBN_801_Fan_Enable] [int] NULL,
	[Fan_Enable] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[PRC_LOAD_ALL_ETL_TABLES]    Script Date: 2/25/2020 9:47:29 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


