EXEC [bcd].[SP_Merge_iCIS_BCD_Main] 'icisPlantEnergy_KALA', 'dbo', 'icisPlantEnergy_KALA', 'bcd'
