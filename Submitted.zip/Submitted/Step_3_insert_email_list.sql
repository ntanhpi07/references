USE [icisPlantEnergy_KALA]
GO
INSERT INTO [bcd].[BCD_Email_List]([First_Name],[Last_Name],[Email],[Active_Flag])
VALUES
      ('Tuan', 'Nguyen', 'anh.nguyen3@pfizer.com', 'Y');
GO


