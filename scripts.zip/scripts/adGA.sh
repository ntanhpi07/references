for f in *GroupsAssignments.txt.cln; do
sed '1,1d' $f > $f.1
cat ga.txt $f.1 > $f.txt
done
