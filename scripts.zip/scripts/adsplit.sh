split -l 360000 CORPADGroupsAssignments1.txt.cln C1
sed '1,1d' C1aa > C1a1
cat ga.txt C1a1 > C1a.txt
cat ga.txt C1ab > C1b.txt

split -l 390000 CORPADGroupsAssignments2.txt.cln C2
sed '1,1d' C2aa > C2a1
cat ga.txt C2a1 > C2a.txt
cat ga.txt C2ab > C2b.txt

split -l 390000 CORPADGroupsAssignments3.txt.cln C3
sed '1,1d' C3aa > C3a1
cat ga.txt C3a1 > C3a.txt
cat ga.txt C3ab > C3b.txt

split -l 360000 CORPADGroupsAssignments4.txt.cln C4
sed '1,1d' C4aa > C4a1
cat ga.txt C4a1 > C4a.txt
cat ga.txt C4ab > C4b.txt

