for f in *Accounts.txt.cln; do
sed '1,1d' $f > $f.1
cat a.txt $f.1 > $f.txt
done
