#!/bin/bash
for f in *GroupsAssignments*.txt; do
grep -v CNF: $f >$f.cln
done
for f in *Groups.txt; do
grep -v CNF: $f >$f.cln
done
for f in *Accounts.txt; do
grep -v CNF: $f >$f.cln
done
