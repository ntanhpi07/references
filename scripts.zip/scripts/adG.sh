for f in *Groups.txt.cln; do
sed '1,1d' $f > $f.1
cat g.txt $f.1 > $f.txt
done
