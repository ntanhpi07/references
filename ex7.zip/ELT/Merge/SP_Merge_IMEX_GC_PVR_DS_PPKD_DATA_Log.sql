-- select * from dbo.IMEX_logs
-- exec SP_Merge_IMEX_GC_PVR_DS_PPKD_DATA_Log
-- delete from dbo.IMEX_logs;

CREATE PROCEDURE SP_Merge_IMEX_GC_PVR_DS_PPKD_DATA_Log
AS
BEGIN

declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar (max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

	exec dbo.[SP_Merge_StartLog] 'Merging IMEX_GC_PVR_DS_PPKD_DATA','IIOT_ETL_DEV', @log_id output

	BEGIN TRY
						
		EXECUTE SP_Merge_IMEX_GC_PVR_DS_PPKD_DATA @insertedRow output, @updatedRow output;  

	END TRY  
	BEGIN CATCH  
		set @errMsg = error_message()
		set @errNo = error_number()
	END CATCH;

	if isnull(@errNo,0) <> 0
	begin 

		-- close the log 
		set @message = 'Merging failed.'
		set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
		exec dbo.[SP_Merge_EndLog] @log_id, @message, @logmessage

	end

	if isnull(@errNo,0) = 0 -- closing merge
	begin 
		set @logmessage = 'Merging completed: '
						+ cast(isnull(@insertedRow,0) as varchar) + ' rows inserted. '
						+ cast(isnull(@updatedRow,0) as varchar) + ' rows updated.'

		update dbo.IMEX_Logs
		set inserted=isnull(@insertedRow,0)
		,updated=isnull(@updatedRow,0)
		where ID = @log_id;

		exec dbo.[SP_Merge_EndLog] @log_id, @logmessage

	end
END;