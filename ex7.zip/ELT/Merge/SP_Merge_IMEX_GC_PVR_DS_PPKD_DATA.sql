/*

declare @insertedRow int, @updatedRow int;
execute dbo.SP_Merge_IMEX_GC_PVR_DS_PPKD_DATA @insertedRow output, @updatedRow output;

*/

ALTER PROCEDURE dbo.SP_Merge_IMEX_GC_PVR_DS_PPKD_DATA(@insertedRow INT OUTPUT, @updatedRow INT OUTPUT)
AS
BEGIN
DECLARE @tableVar TABLE (MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

SELECT [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Failure Rate]
,[Distribution]
,Display
,[Ppk Category]
,[Defect Rate]
,[Predicted Batch Loss]
,[Number of Batches]
,[Ppk Shift]
,Link
INTO #IMEX_GC_PVR_DS_PPKD_DATA
FROM OPENQUERY(ORA_DBLINK_MIPRANS_T,'SELECT "Product Name"
,"Sub Product Name"
,"Sub Process"
,"Parameter Field Name"
,"Parameter _w_Units_ Field Name"
,"Ppk Value"
,"PPM"
,"Failure Rate"
,"Distribution"
,"Display"
,"Ppk Category"
,"Defect Rate"
,"Predicted Batch Loss"
,"Number of Batches"
,"Ppk Shift"
,"Link"
FROM MIPRANS_OWNER.IMEX_GC_PVR_DS_PPKD_DATA'
);

-- select * from #IMEX_GC_PVR_DS_PPKD_DATA;

-- select * from [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PPKD_DATA;

MERGE [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PPKD_DATA a 
USING #IMEX_GC_PVR_DS_PPKD_DATA b
ON (a.[Product Name]=b.[Product Name]
and a.[Sub Product Name]=b.[Sub Product Name]
and a.[Sub Process]=b.[Sub Process]
and a.[Ppk Value]=b.[Ppk Value]
)
WHEN MATCHED THEN 
UPDATE SET a.[Parameter Field Name]=b.[Parameter Field Name]
,a.[Parameter _w_Units_ Field Name]=b.[Parameter _w_Units_ Field Name]
,a.PPM=b.PPM
,a.[Failure Rate]=b.[Failure Rate]
,a.[Distribution]=b.[Distribution]
,a.Display=b.Display
,a.[Ppk Category]=b.[Ppk Category]
,a.[Defect Rate]=b.[Defect Rate]
,a.[Predicted Batch Loss]=b.[Predicted Batch Loss]
,a.[Number of Batches]=b.[Number of Batches]
,a.[Ppk Shift]=b.[Ppk Shift]
,a.Link=b.Link
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Failure Rate]
,[Distribution]
,Display
,[Ppk Category]
,[Defect Rate]
,[Predicted Batch Loss]
,[Number of Batches]
,[Ppk Shift]
,Link) 
VALUES (b.[Product Name]
,b.[Sub Product Name]
,b.[Sub Process]
,b.[Parameter Field Name]
,b.[Parameter _w_Units_ Field Name]
,b.[Ppk Value]
,b.PPM
,b.[Failure Rate]
,b.[Distribution]
,b.Display
,b.[Ppk Category]
,b.[Defect Rate]
,b.[Predicted Batch Loss]
,b.[Number of Batches]
,b.[Ppk Shift]
,b.Link
)
--WHEN NOT MATCHED BY SOURCE 
--    THEN DELETE
OUTPUT
      $action, inserted.ID 'inserted', deleted.ID 'deleted' INTO @tableVar
;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

DROP TABLE #IMEX_GC_PVR_DS_PPKD_DATA;

END;

