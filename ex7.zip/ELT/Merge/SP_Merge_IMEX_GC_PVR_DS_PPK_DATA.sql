/*

declare @insertedRow int, @updatedRow int;
execute dbo.SP_Merge_IMEX_GC_PVR_DS_PPK_DATA @insertedRow output, @updatedRow output;

*/

ALTER PROCEDURE dbo.SP_Merge_IMEX_GC_PVR_DS_PPK_DATA(@insertedRow INT OUTPUT, @updatedRow INT OUTPUT)
AS
BEGIN
DECLARE @tableVar TABLE (MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

SELECT [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Failure Rate]
,[Number of POR Batches]
,[Number of Ppk Batches]
,[X_Axis Steps in Current View]
,[X_Axis Step]
,[Distribution]
,Display
,[Flag Current]
,[Ppk Category]
,[X_Axis Tick Label]
,[X_Axis Value]
,[Number of Batches]
,Link
INTO #IMEX_GC_PVR_DS_PPK_DATA
FROM OPENQUERY(ORA_DBLINK_MIPRANS_T,'SELECT "Product Name"
,"Sub Product Name"
,"Sub Process"
,"Parameter Field Name"
,"Parameter _w_Units_ Field Name"
,"Ppk Value"
,"PPM"
,"Failure Rate"
,"Number of POR Batches"
,"Number of Ppk Batches"
,"X_Axis Steps in Current View"
,"X_Axis Step"
,"Distribution"
,"Display"
,"Flag Current"
,"Ppk Category"
,"X_Axis Tick Label"
,"X_Axis Value"
,"Number of Batches"
,"Link"
FROM MIPRANS_OWNER.IMEX_GC_PVR_DS_PPK_DATA'
);

-- select count(*) from #IMEX_GC_PVR_DS_PPK_DATA;

-- select count(*) from [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PPK_DATA;

MERGE [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PPK_DATA a 
USING #IMEX_GC_PVR_DS_PPK_DATA b
ON (a.[Product Name]=b.[Product Name]
and a.[Sub Product Name]=b.[Sub Product Name]
and a.[Sub Process]=b.[Sub Process]
and a.[Parameter Field Name]=b.[Parameter Field Name]
and a.[Parameter _w_Units_ Field Name]=b.[Parameter _w_Units_ Field Name]
and a.[Ppk Value]=b.[Ppk Value]
and a.PPM=b.PPM
and a.[Flag Current]=b.[Flag Current]
and a.[Ppk Category]=b.[Ppk Category]
and a.[X_Axis Tick Label]=b.[X_Axis Tick Label]
and a.[X_Axis Value]=b.[X_Axis Value])
WHEN MATCHED THEN 
UPDATE SET a.[Failure Rate]=b.[Failure Rate]
,a.[Number of POR Batches]=b.[Number of POR Batches]
,a.[Number of Ppk Batches]=b.[Number of Ppk Batches]
,a.[X_Axis Steps in Current View]=b.[X_Axis Steps in Current View]
,a.[X_Axis Step]=b.[X_Axis Step]
,a.[Distribution]=b.[Distribution]
,a.Display=b.Display
,a.[Number of Batches]=b.[Number of Batches]
,a.Link=b.Link
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Failure Rate]
,[Number of POR Batches]
,[Number of Ppk Batches]
,[X_Axis Steps in Current View]
,[X_Axis Step]
,[Distribution]
,Display
,[Flag Current]
,[Ppk Category]
,[X_Axis Tick Label]
,[X_Axis Value]
,[Number of Batches]
,Link) 
VALUES (b.[Product Name]
,b.[Sub Product Name]
,b.[Sub Process]
,b.[Parameter Field Name]
,b.[Parameter _w_Units_ Field Name]
,b.[Ppk Value]
,b.PPM
,b.[Failure Rate]
,b.[Number of POR Batches]
,b.[Number of Ppk Batches]
,b.[X_Axis Steps in Current View]
,b.[X_Axis Step]
,b.[Distribution]
,b.Display
,b.[Flag Current]
,b.[Ppk Category]
,b.[X_Axis Tick Label]
,b.[X_Axis Value]
,b.[Number of Batches]
,b.Link
)
--WHEN NOT MATCHED BY SOURCE 
--    THEN DELETE
OUTPUT
      $action, inserted.ID 'inserted', deleted.ID 'deleted' INTO @tableVar
;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

DROP TABLE #IMEX_GC_PVR_DS_PPK_DATA;

END;

