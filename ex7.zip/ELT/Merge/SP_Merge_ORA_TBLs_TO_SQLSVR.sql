-- use IIOT_ETL_DEV;

GO

ALTER PROCEDURE [SP_Merge_StartLog] (@process AS VARCHAR(100), @db AS VARCHAR(100), @id INT OUTPUT)
AS
BEGIN
	DECLARE @dte AS DATETIME
	SET @dte = GETDATE()
	INSERT INTO [IIOT_ETL_DEV].dbo.IMEX_Logs (StartTime, Process, DBname)
	VALUES (@dte, @process, @db)
	SET @id = @@identity
END;

GO --------------------------------------------------------------------------------------------------------------------

ALTER PROCEDURE [SP_Merge_EndLog] (@id AS INT = 1, @msg AS VARCHAR(200) ='', @errMsg AS nvarchar(max) = '')
AS
BEGIN
	UPDATE [IIOT_ETL_DEV].dbo.IMEX_Logs
	SET EndTime = GETDATE(), Msg=@msg, ErrMsg=@errMsg
	WHERE ID=@id
END;

GO --------------------------------------------------------------------------------------------------------------------

-- select * from dbo.IMEX_logs
-- exec SP_Merge_IMEX_GC_PVR_DS_PPK_DATA_Log_Sendmail
-- delete from dbo.IMEX_logs;

ALTER PROCEDURE SP_Merge_IMEX_GC_PVR_DS_PPK_DATA_Log_Sendmail
AS
BEGIN

declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar (max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

	exec dbo.[SP_Merge_StartLog] 'Merging IMEX_GC_PVR_DS_PPK_DATA','IIOT_ETL_DEV', @log_id output

	BEGIN TRY
						
		EXECUTE SP_Merge_IMEX_GC_PVR_DS_PPK_DATA @insertedRow output, @updatedRow output;

	END TRY  
	BEGIN CATCH  
		set @errMsg = error_message()
		set @errNo = error_number()
	END CATCH;

	if isnull(@errNo,0) <> 0
	begin 

		-- close the log 
		set @message = 'Merging failed.'
		set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
		exec dbo.[SP_Merge_EndLog] @log_id, @message, @logmessage

		--email to notice failure
		set @subjectContent = 'Merging IMEX_GC_PVR_DS_PPK_DATA Error'
		set @message = 'Merging failed, ERROR MESSAGE: ' + @logmessage
		exec msdb.dbo.sp_send_dbmail	
										@subject = @subjectContent,
										@body = @message,
										@body_format = 'TEXT',
										@recipients = 'anh.nguyen3@pfizer.com';

	end

	if isnull(@errNo,0) = 0 -- closing merge
	begin 
		set @logmessage = 'Merging completed: '
						+ cast(@insertedRow as varchar) + ' rows inserted. '
						+ cast(@updatedRow as varchar) + ' rows updated.'

		update dbo.IMEX_Logs
		set inserted=@insertedRow
		,updated=@updatedRow
		where ID = @log_id;

		exec dbo.[SP_Merge_EndLog] @log_id, @logmessage

		--email to notice success
		set @subjectContent = 'Merging IMEX_GC_PVR_DS_PPK_DATA success'
		set @message = @logmessage
		exec msdb.dbo.sp_send_dbmail	
										@subject = @subjectContent,
										@body = @message,
										@body_format = 'TEXT',
										@recipients = 'anh.nguyen3@pfizer.com';
	end
END;