/*

declare @insertedRow int, @updatedRow int;
execute dbo.SP_Merge_IMEX_GC_PVR_DS_CPV_UNL_DATA @insertedRow output, @updatedRow output;

*/

ALTER PROCEDURE dbo.SP_Merge_IMEX_GC_PVR_DS_CPV_UNL_DATA(@insertedRow INT OUTPUT, @updatedRow INT OUTPUT)
AS
BEGIN

DECLARE @tableVar TABLE (MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

SELECT Site
, Product
, [Sub Product]
, [Alarm Log ID]
, Parameter
, [Batch Number]
, Type
, [Alarm Details]
, [Date Alarm Logged]
INTO #IMEX_GC_PVR_DS_CPV_UNL_DATA
FROM OPENQUERY(ORA_DBLINK_MIPRANS_T,'SELECT "Site"
, "Product"
, "Sub Product"
, "Alarm Log ID"
, "Parameter"
, "Batch Number"
, "Type"
, "Alarm Details"
, "Date Alarm Logged"
FROM MIPRANS_OWNER.IMEX_GC_PVR_DS_CPV_UNL_DATA'
);

-- select * from #IMEX_GC_PVR_DS_CPV_UNL_DATA;

-- select * from [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_CPV_UNL_DATA;

MERGE [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_CPV_UNL_DATA a 
USING #IMEX_GC_PVR_DS_CPV_UNL_DATA b
ON (a.Site=b.Site 
and a.Product=b.Product 
and a.[Sub Product]=b.[Sub Product] 
and a.[Alarm Log ID]=b.[Alarm Log ID])
WHEN MATCHED THEN 
UPDATE SET a.Parameter=b.Parameter
, a.[Batch Number] = b.[Batch Number]
, a.Type=b.Type
, a.[Alarm Details]=b.[Alarm Details]
, a.[Date Alarm Logged]=b.[Date Alarm Logged]
WHEN NOT MATCHED BY TARGET THEN 
INSERT (Site
, Product
, [Sub Product]
, [Alarm Log ID]
, Parameter
, [Batch Number]
, Type
, [Alarm Details]
, [Date Alarm Logged]) 
VALUES (b.Site
, b.Product
, b.[Sub Product]
, b.[Alarm Log ID]
, b.Parameter
, b.[Batch Number]
, b.Type
, b.[Alarm Details]
, b.[Date Alarm Logged]
)
--WHEN NOT MATCHED BY SOURCE 
--    THEN DELETE
OUTPUT
      $action, inserted.ID 'inserted', deleted.ID 'deleted' INTO @tableVar
;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

DROP TABLE #IMEX_GC_PVR_DS_CPV_UNL_DATA;

END;

