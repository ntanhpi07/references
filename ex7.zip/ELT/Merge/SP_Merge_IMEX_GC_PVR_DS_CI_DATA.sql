/*

declare @insertedRow int, @updatedRow int;
execute dbo.SP_Merge_IMEX_GC_PVR_DS_CI_DATA @insertedRow output, @updatedRow output;

*/
ALTER PROCEDURE dbo.SP_Merge_IMEX_GC_PVR_DS_CI_DATA(@insertedRow INT OUTPUT, @updatedRow INT OUTPUT)
AS
BEGIN
DECLARE @tableVar TABLE (MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

SELECT Site
,Product
,[Sub Product]
,[Unit Operation]
,Parameter
,Type
,[Acceptance Criteria]
,[CPV Risk Score]
,[Date Raised]
,[Target Completion Date]
,[Problem Statement]
,[Periodic Update]
,Status
,Link
,[CI New Sample Link]
,[CI Update Entry Link]
INTO #IMEX_GC_PVR_DS_CI_DATA
FROM OPENQUERY(ORA_DBLINK_MIPRANS_T,'SELECT "Site"
,"Product"
,"Sub Product"
,"Unit Operation"
,"Parameter"
,"Type"
,"Acceptance Criteria"
,"CPV Risk Score"
,"Date Raised"
,"Target Completion Date"
,"Problem Statement"
,"Periodic Update"
,"Status"
,"Link"
,"CI New Sample Link"
,"CI Update Entry Link"
FROM MIPRANS_OWNER.IMEX_GC_PVR_DS_CI_DATA'
);

-- select * from #IMEX_GC_PVR_DS_CI_DATA;

-- select * from [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_CI_DATA;

MERGE [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_CI_DATA a 
USING #IMEX_GC_PVR_DS_CI_DATA b
ON (a.Site=b.Site 
and a.Product=b.Product 
and a.[Sub Product]=b.[Sub Product] 
and a.Parameter=b.Parameter 
and a.[CPV Risk Score]=b.[CPV Risk Score])
WHEN MATCHED THEN 
UPDATE SET a.[Unit Operation]=b.[Unit Operation]
, a.Type=b.Type
, a.[Acceptance Criteria]=b.[Acceptance Criteria]
, a.[Date Raised]=b.[Date Raised]
, a.[Target Completion Date]=b.[Target Completion Date]
, a.[Problem Statement]=b.[Problem Statement]
, a.[Periodic Update]=b.[Periodic Update]
, a.Status=b.Status
, a.Link=b.Link
, a.[CI New Sample Link]=b.[CI New Sample Link]
, a.[CI Update Entry Link]=b.[CI Update Entry Link]
WHEN NOT MATCHED BY TARGET THEN 
INSERT (Site
,Product
,[Sub Product]
,[Unit Operation]
,Parameter
,Type
,[Acceptance Criteria]
,[CPV Risk Score]
,[Date Raised]
,[Target Completion Date]
,[Problem Statement]
,[Periodic Update]
,Status
,Link
,[CI New Sample Link]
,[CI Update Entry Link]) 
VALUES (b.Site
,b.Product
,b.[Sub Product]
,b.[Unit Operation]
,b.Parameter
,b.Type
,b.[Acceptance Criteria]
,b.[CPV Risk Score]
,b.[Date Raised]
,b.[Target Completion Date]
,b.[Problem Statement]
,b.[Periodic Update]
,b.Status
,b.Link
,b.[CI New Sample Link]
,b.[CI Update Entry Link]
)
--WHEN NOT MATCHED BY SOURCE 
--    THEN DELETE
OUTPUT
      $action, inserted.ID 'inserted', deleted.ID 'deleted' INTO @tableVar
;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

DROP TABLE #IMEX_GC_PVR_DS_CI_DATA;

END;

