/*

declare @insertedRow int, @updatedRow int;
execute dbo.SP_Merge_IMEX_GC_PVR_DS_PFS_DATA @insertedRow output, @updatedRow output;

*/

ALTER PROCEDURE dbo.SP_Merge_IMEX_GC_PVR_DS_PFS_DATA(@insertedRow INT OUTPUT, @updatedRow INT OUTPUT)
AS
BEGIN

DECLARE @tableVar TABLE (MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

SELECT Site
,Product
,[Sub Product]
,[X_Axis Value]
,[X_Axis Step]
,[X_Axis Steps in Current View]
,[Flag Current]
,[Process Control Score]
,[Acceptance Criteria]
,[X_Axis Tick Label]
INTO #IMEX_GC_PVR_DS_PFS_DATA
FROM OPENQUERY(ORA_DBLINK_MIPRANS_T,'SELECT "Site"
,"Product"
,"Sub Product"
,"X_Axis Value"
,"X_Axis Step"
,"X_Axis Steps in Current View"
,"Flag Current"
,"Process Control Score"
,"Acceptance Criteria"
,"X_Axis Tick Label"
FROM MIPRANS_OWNER.IMEX_GC_PVR_DS_PFS_DATA'
);

-- select * from #IMEX_GC_PVR_DS_PFS_DATA;

-- select * from [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PFS_DATA;

MERGE [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PFS_DATA a 
USING #IMEX_GC_PVR_DS_PFS_DATA b
ON (a.Site=b.Site
and a.Product=b.Product
and a.[Sub Product]=b.[Sub Product]
and a.[X_Axis Value]=b.[X_Axis Value])
WHEN MATCHED THEN 
UPDATE SET a.[X_Axis Step]=b.[X_Axis Step]
,a.[X_Axis Steps in Current View]=b.[X_Axis Steps in Current View]
,a.[Flag Current]=b.[Flag Current]
,a.[Process Control Score]=b.[Process Control Score]
,a.[Acceptance Criteria]=b.[Acceptance Criteria]
,a.[X_Axis Tick Label]=b.[X_Axis Tick Label]
WHEN NOT MATCHED BY TARGET THEN 
INSERT (Site
,Product
,[Sub Product]
,[X_Axis Value]
,[X_Axis Step]
,[X_Axis Steps in Current View]
,[Flag Current]
,[Process Control Score]
,[Acceptance Criteria]
,[X_Axis Tick Label]) 
VALUES (b.Site
,b.Product
,b.[Sub Product]
,b.[X_Axis Value]
,b.[X_Axis Step]
,b.[X_Axis Steps in Current View]
,b.[Flag Current]
,b.[Process Control Score]
,b.[Acceptance Criteria]
,b.[X_Axis Tick Label]
)
--WHEN NOT MATCHED BY SOURCE 
--    THEN DELETE
OUTPUT
      $action, inserted.ID 'inserted', deleted.ID 'deleted' INTO @tableVar
;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM @tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

DROP TABLE #IMEX_GC_PVR_DS_PFS_DATA;

END;

