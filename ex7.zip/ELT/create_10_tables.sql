USE [IIOT_ETL_DEV]
GO

DROP TABLE [dbo].IMEX_GC_PVR_DS_CI_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_CIG_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_CPV_UNL_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_CPVG_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_PF_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_PFS_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_PPK_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_PPKD_DATA;
DROP TABLE [dbo].IMEX_GC_PVR_DS_PSS_DATA;


CREATE TABLE [dbo].[IMEX_GC_PVR_DS_CI_DATA](
	ID int identity(1,1) primary key,
	[Site] [nvarchar](50) NULL,
	[Product] [nvarchar](50) NULL,
	[Sub Product] [nvarchar](100) NULL,
	[Unit Operation] [nvarchar](50) NULL,
	[Parameter] [nvarchar](200) NULL,
	[Type] [nvarchar](50) NULL,
	[Acceptance Criteria] [float] NULL,
	[CPV Risk Score] [float] NULL,
	[Date Raised] [datetime2](7) NULL,
	[Target Completion Date] [datetime2](7) NULL,
	[Problem Statement] [nvarchar](500) NULL,
	[Periodic Update] [nvarchar](50) NULL,
	[Status] [nvarchar](50) NULL,
	[Link] [nvarchar](200) NULL,
	[CI New Sample Link] [nvarchar](200) NULL,
	[CI Update Entry Link] [nvarchar](200) NULL,
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_CI_DATA 
ON dbo.IMEX_GC_PVR_DS_CI_DATA(
Site
,Product
,[Sub Product]
,[Unit Operation]
,Parameter
,Type
,[Acceptance Criteria]
,[CPV Risk Score]);

GO--------------------------------------------------------------------------

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_CIG_DATA](
	ID int identity(1,1) primary key,
	[Site] [nvarchar](50) NULL,
	[Product] [nvarchar](50) NULL,
	[Sub Product] [nvarchar](50) NULL,
	[X_Axis Value] [datetime2](7) NULL,
	[X_Axis Step] [nvarchar](50) NULL,
	[X_Axis Steps in Current View] [float] NULL,
	[Flag Current] [float] NULL,
	[Total Risk Score] [float] NULL,
	[Acceptance Criteria] [nvarchar](50) NULL,
	[X_Axis Tick Label] [nvarchar](50) NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_CIG_DATA 
ON dbo.IMEX_GC_PVR_DS_CIG_DATA(
Site
,Product
,[Sub Product]
,[X_Axis Value]);

GO--------------------------------------------------------------------------

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_CPV_UNL_DATA](
	ID int identity(1,1) primary key,
	[Site] [nvarchar](50) NULL,
	[Product] [nvarchar](50) NULL,
	[Sub Product] [nvarchar](50) NULL,
	[Alarm Log ID] [float] NULL,
	[Parameter] [nvarchar](200) NULL,
	[Batch Number] [nvarchar](50) NULL,
	[Type] [nvarchar](50) NULL,
	[Alarm Details] [nvarchar](200) NULL,
	[Date Alarm Logged] [datetime2](7) NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_CPV_UNL_DATA 
ON dbo.IMEX_GC_PVR_DS_CPV_UNL_DATA(
Site
,Product
,[Sub Product]
,[Alarm Log ID]);

GO--------------------------------------------------------------------------

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_CPVG_DATA](
	ID int identity(1,1) primary key,
	[Site] [nvarchar](50) NULL,
	[Product] [nvarchar](50) NULL,
	[Sub Product] [nvarchar](50) NULL,
	[X_Axis Value] [datetime2](7) NULL,
	[X_Axis Step] [nvarchar](50) NULL,
	[X_Axis Tick Label] [nvarchar](50) NULL,
	[Number of New Unlogged Flags] [float] NULL,
	[Number of New Flags] [float] NULL,
	[Number of Closed Flags] [float] NULL,
	[Open Actions] [float] NULL,
	[Flag Current] [float] NULL,
	[Risk Ranking _ 0] [float] NULL,
	[Risk Ranking _ 1] [float] NULL,
	[Risk Ranking _ 2] [float] NULL,
	[Risk Ranking _ 3] [float] NULL,
	[Duration Count __30min] [float] NULL,
	[Duration Count 31_60min] [float] NULL,
	[Duration Count 61_90min] [float] NULL,
	[Duration Count _90min] [float] NULL,
	[OOC Count] [float] NULL,
	[Shift Rule Count] [float] NULL,
	[Trend Rule Count] [float] NULL,
	[OOW Count] [float] NULL,
	[OOS Count] [float] NULL,
	[Total Nr Unlogged Flags] [float] NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_CPVG_DATA
ON dbo.IMEX_GC_PVR_DS_CPVG_DATA(
Site
,Product
,[Sub Product]
,[X_Axis Value]);

GO--------------------------------------------------------------------------

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_PF_DATA](
	ID int identity(1,1) primary key,
	[Site] [nvarchar](50) NULL,
	[Product] [nvarchar](50) NULL,
	[Sub Product] [nvarchar](50) NULL,
	[Unit Operation] [nvarchar](50) NULL,
	[Control Status] [float] NULL,
	[Title] [nvarchar](100) NULL,
	[Description] [nvarchar](500) NULL,
	[Root Cause] [nvarchar](17) NULL,
	[Actions] [nvarchar](44) NULL,
	[Param _w_Units_ Field Name 1] [nvarchar](100) NULL,
	[Param _w_Units_ Field Name 2] [nvarchar](100) NULL,
	[Date Action Updated] [datetime2](7) NULL,
	[Update Action] [nvarchar](200) NULL,
	[Parameter 1 Graph Link] [nvarchar](200) NULL,
	[Parameter 2 Graph Link] [nvarchar](200) NULL,
	[Supporting Visual Link 1] [nvarchar](50) NULL,
	[Supporting Visual Link 2] [nvarchar](50) NULL,
	[Create NewEntry] [nvarchar](200) NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_PF_DATA
ON dbo.IMEX_GC_PVR_DS_PF_DATA(
 Site
,Product
,[Sub Product]
,[Unit Operation]
,[Control Status]
,Title
,[Param _w_Units_ Field Name 1]
,[Param _w_Units_ Field Name 2]
,[Date Action Updated]);

GO--------------------------------------------------------------------------
use IIO_ETL_DEV;

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_PFS_DATA](
	ID int identity(1,1) primary key,
	[Site] [nvarchar](50) NULL,
	[Product] [nvarchar](50) NULL,
	[Sub Product] [nvarchar](50) NULL,
	[X_Axis Value] [datetime2](7) NULL,
	[X_Axis Step] [nvarchar](50) NULL,
	[X_Axis Steps in Current View] [float] NULL,
	[Flag Current] [float] NULL,
	[Process Control Score] [nvarchar](50) NULL,
	[Acceptance Criteria] [nvarchar](50) NULL,
	[X_Axis Tick Label] [nvarchar](50) NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_PFS_DATA
ON dbo.IMEX_GC_PVR_DS_PFS_DATA(
 Site
,Product
,[Sub Product]
,[X_Axis Value]);

GO--------------------------------------------------------------------------

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_PPK_DATA](
	ID int identity(1,1) primary key,
	[Product Name] [nvarchar](50) NULL,
	[Sub Product Name] [nvarchar](50) NULL,
	[Sub Process] [nvarchar](50) NULL,
	[Parameter Field Name] [nvarchar](200) NULL,
	[Parameter _w_Units_ Field Name] [nvarchar](200) NULL,
	[Ppk Value] [nvarchar](50) NULL,
	[PPM] [float] NULL,
	[Failure Rate] [nvarchar](50) NULL,
	[Number of POR Batches] [float] NULL,
	[Number of Ppk Batches] [float] NULL,
	[X_Axis Steps in Current View] [float] NULL,
	[X_Axis Step] [nvarchar](50) NULL,
	[Distribution] [nvarchar](50) NULL,
	[Display] [nvarchar](50) NULL,
	[Flag Current] [float] NULL,
	[Ppk Category] [float] NULL,
	[X_Axis Tick Label] [nvarchar](50) NULL,
	[X_Axis Value] [datetime2](7) NULL,
	[Number of Batches] [float] NULL,
	[Link] [nvarchar](200) NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_PPK_DATA
ON dbo.IMEX_GC_PVR_DS_PPK_DATA(
 [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Flag Current]
,[Ppk Category]
,[X_Axis Tick Label]
,[X_Axis Value]);

GO--------------------------------------------------------------------------

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_PPKD_DATA](
	ID int identity(1,1) primary key,
	[Product Name] [nvarchar](50) NULL,
	[Sub Product Name] [nvarchar](50) NULL,
	[Sub Process] [nvarchar](50) NULL,
	[Parameter Field Name] [nvarchar](200) NULL,
	[Parameter _w_Units_ Field Name] [nvarchar](200) NULL,
	[Ppk Value] [nvarchar](50) NULL,
	[PPM] [float] NULL,
	[Failure Rate] [nvarchar](50) NULL,
	[Distribution] [nvarchar](50) NULL,
	[Display] [nvarchar](50) NULL,
	[Ppk Category] [float] NULL,
	[Defect Rate] [nvarchar](50) NULL,
	[Predicted Batch Loss] [float] NULL,
	[Number of Batches] [float] NULL,
	[Ppk Shift] [float] NULL,
	[Link] [nvarchar](200) NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_PPKD_DATA
ON dbo.IMEX_GC_PVR_DS_PPKD_DATA(
[Product Name]
,[Sub Product Name]
,[Sub Process]
,[Ppk Value]);

GO--------------------------------------------------------------------------

CREATE TABLE [dbo].[IMEX_GC_PVR_DS_PSS_DATA](
	ID int identity(1,1) primary key,
	[Product Name] [nvarchar](50) NULL,
	[Sub Product Name] [nvarchar](50) NULL,
	[Sub Process] [nvarchar](50) NULL,
	[Display] [nvarchar](50) NULL,
	[X_Axis Value] [datetime2](7) NULL,
	[X_Axis Tick Label] [nvarchar](50) NULL,
	[X_Axis Step] [nvarchar](50) NULL,
	[X_Axis Steps in Current View] [float] NULL,
	[Ppk Roll Up] [float] NULL,
	[Process Performance Score] [float] NULL,
	[Defect Rate] [nvarchar](50) NULL,
	[Predicted Batch Loss] [float] NULL,
	[Predicted Batch Loss Status] [float] NULL,
	[Flag Current] [float] NULL,
	[Flag Most Current] [float] NULL,
	[Flag Most Recent] [float] NULL,
	[Ppk Shift] [float] NULL,
	[Pct Ppk Cat 1] [float] NULL,
	[Pct Ppk Cat 2] [float] NULL,
	[Pct Ppk Cat 3] [float] NULL,
	[Count Ppk Cat 1] [float] NULL,
	[Count Ppk Cat 2] [float] NULL,
	[Count Ppk Cat 3] [float] NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX IX_IMEX_GC_PVR_DS_PSS_DATA
ON dbo.IMEX_GC_PVR_DS_PSS_DATA(
[Product Name]
,[Sub Product Name]
,[Sub Process]
,[X_Axis Value]);

GO--------------------------------------------------------------------------