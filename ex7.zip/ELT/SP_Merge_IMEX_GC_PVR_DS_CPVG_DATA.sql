-- execute dbo.SP_Merge_IMEX_GC_PVR_DS_CPVG_DATA;

CREATE PROCEDURE dbo.SP_Merge_IMEX_GC_PVR_DS_CPVG_DATA
AS
BEGIN
SELECT Site
,Product
,[Sub Product]
,[X_Axis Value]
,[X_Axis Step]
,[X_Axis Tick Label]
,[Number of New Unlogged Flags]
,[Number of New Flags]
,[Number of Closed Flags]
,[Open Actions]
,[Flag Current]
,[Risk Ranking _ 0]
,[Risk Ranking _ 1]
,[Risk Ranking _ 2]
,[Risk Ranking _ 3]
,[Duration Count __30min]
,[Duration Count 31_60min]
,[Duration Count 61_90min]
,[Duration Count _90min]
,[OOC Count]
,[Shift Rule Count]
,[Trend Rule Count]
,[OOW Count]
,[OOS Count]
,[Total Nr Unlogged Flags]
INTO #IMEX_GC_PVR_DS_CPVG_DATA
FROM OPENQUERY(ORA_DBLINK_MIPRANS_T,'SELECT "Site"
,"Product"
,"Sub Product"
,"X_Axis Value"
,"X_Axis Step"
,"X_Axis Tick Label"
,"Number of New Unlogged Flags"
,"Number of New Flags"
,"Number of Closed Flags"
,"Open Actions"
,"Flag Current"
,"Risk Ranking _ 0"
,"Risk Ranking _ 1"
,"Risk Ranking _ 2"
,"Risk Ranking _ 3"
,"Duration Count __30min"
,"Duration Count 31_60min"
,"Duration Count 61_90min"
,"Duration Count _90min"
,"OOC Count"
,"Shift Rule Count"
,"Trend Rule Count"
,"OOW Count"
,"OOS Count"
,"Total Nr Unlogged Flags"
FROM MIPRANS_OWNER.IMEX_GC_PVR_DS_CPVG_DATA'
);

-- select * from #IMEX_GC_PVR_DS_CPVG_DATA;

-- select * from [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_CPVG_DATA;

MERGE [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_CPVG_DATA a 
USING #IMEX_GC_PVR_DS_CPVG_DATA b
ON (a.Site=b.Site 
and a.Product=b.Product 
and a.[Sub Product]=b.[Sub Product] 
and a.[X_Axis Value]=b.[X_Axis Value])
WHEN MATCHED THEN 
UPDATE SET a.[X_Axis Step]=b.[X_Axis Step]
,a.[X_Axis Tick Label]=b.[X_Axis Tick Label]
,a.[Number of New Unlogged Flags]=b.[Number of New Unlogged Flags]
,a.[Number of New Flags]=b.[Number of New Flags]
,a.[Number of Closed Flags]=b.[Number of Closed Flags]
,a.[Open Actions]=b.[Open Actions]
,a.[Flag Current]=b.[Flag Current]
,a.[Risk Ranking _ 0]=b.[Risk Ranking _ 0]
,a.[Risk Ranking _ 1]=b.[Risk Ranking _ 1]
,a.[Risk Ranking _ 2]=b.[Risk Ranking _ 2]
,a.[Risk Ranking _ 3]=b.[Risk Ranking _ 3]
,a.[Duration Count __30min]=b.[Duration Count __30min]
,a.[Duration Count 31_60min]=b.[Duration Count 31_60min]
,a.[Duration Count 61_90min]=b.[Duration Count 61_90min]
,a.[Duration Count _90min]=b.[Duration Count _90min]
,a.[OOC Count]=b.[OOC Count]
,a.[Shift Rule Count]=b.[Shift Rule Count]
,a.[Trend Rule Count]=b.[Trend Rule Count]
,a.[OOW Count]=b.[OOW Count]
,a.[OOS Count]=b.[OOS Count]
,a.[Total Nr Unlogged Flags]=b.[Total Nr Unlogged Flags]
WHEN NOT MATCHED BY TARGET THEN 
INSERT (Site
,Product
,[Sub Product]
,[X_Axis Value]
,[X_Axis Step]
,[X_Axis Tick Label]
,[Number of New Unlogged Flags]
,[Number of New Flags]
,[Number of Closed Flags]
,[Open Actions]
,[Flag Current]
,[Risk Ranking _ 0]
,[Risk Ranking _ 1]
,[Risk Ranking _ 2]
,[Risk Ranking _ 3]
,[Duration Count __30min]
,[Duration Count 31_60min]
,[Duration Count 61_90min]
,[Duration Count _90min]
,[OOC Count]
,[Shift Rule Count]
,[Trend Rule Count]
,[OOW Count]
,[OOS Count]
,[Total Nr Unlogged Flags]) 
VALUES (b.Site
,b.Product
,b.[Sub Product]
,b.[X_Axis Value]
,b.[X_Axis Step]
,b.[X_Axis Tick Label]
,b.[Number of New Unlogged Flags]
,b.[Number of New Flags]
,b.[Number of Closed Flags]
,b.[Open Actions]
,b.[Flag Current]
,b.[Risk Ranking _ 0]
,b.[Risk Ranking _ 1]
,b.[Risk Ranking _ 2]
,b.[Risk Ranking _ 3]
,b.[Duration Count __30min]
,b.[Duration Count 31_60min]
,b.[Duration Count 61_90min]
,b.[Duration Count _90min]
,b.[OOC Count]
,b.[Shift Rule Count]
,b.[Trend Rule Count]
,b.[OOW Count]
,b.[OOS Count]
,b.[Total Nr Unlogged Flags]
)
WHEN NOT MATCHED BY SOURCE 
    THEN DELETE;

DROP TABLE #IMEX_GC_PVR_DS_CPVG_DATA;

END;

