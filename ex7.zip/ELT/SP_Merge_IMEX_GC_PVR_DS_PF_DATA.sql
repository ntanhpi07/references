-- execute dbo.SP_Merge_IMEX_GC_PVR_DS_PF_DATA;

CREATE PROCEDURE dbo.SP_Merge_IMEX_GC_PVR_DS_PF_DATA
AS
BEGIN
SELECT Site
,Product
,[Sub Product]
,[Unit Operation]
,[Control Status]
,Title
,Description
,[Root Cause]
,Actions
,[Param _w_Units_ Field Name 1]
,[Param _w_Units_ Field Name 2]
,[Date Action Updated]
,[Update Action]
,[Parameter 1 Graph Link]
,[Parameter 2 Graph Link]
,[Supporting Visual Link 1]
,[Supporting Visual Link 2]
,[Create NewEntry]
INTO #IMEX_GC_PVR_DS_PF_DATA
FROM OPENQUERY(ORA_DBLINK_MIPRANS_T,'SELECT "Site"
,"Product"
,"Sub Product"
,"Unit Operation"
,"Control Status"
,"Title"
,"Description"
,"Root Cause"
,"Actions"
,"Param _w_Units_ Field Name 1"
,"Param _w_Units_ Field Name 2"
,"Date Action Updated"
,"Update Action"
,"Parameter 1 Graph Link"
,"Parameter 2 Graph Link"
,"Supporting Visual Link 1"
,"Supporting Visual Link 2"
,"Create NewEntry"
FROM MIPRANS_OWNER.IMEX_GC_PVR_DS_PF_DATA'
);

-- select * from #IMEX_GC_PVR_DS_PF_DATA;

-- select * from [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PF_DATA;

MERGE [IIOT_ETL_DEV].[dbo].IMEX_GC_PVR_DS_PF_DATA a 
USING #IMEX_GC_PVR_DS_PF_DATA b
ON (a.Site=b.Site
and a.Product=b.Product
and a.[Sub Product]=b.[Sub Product]
and a.[Unit Operation]=b.[Unit Operation]
and a.[Control Status]=b.[Control Status]
and a.Title=b.Title
and a.[Param _w_Units_ Field Name 1]=b.[Param _w_Units_ Field Name 1]
and a.[Param _w_Units_ Field Name 2]=b.[Param _w_Units_ Field Name 2]
and a.[Date Action Updated]=b.[Date Action Updated])
WHEN MATCHED THEN 
UPDATE SET a.Description=b.Description
,a.[Root Cause]=b.[Root Cause]
,a.Actions=b.Actions
,a.[Update Action]=b.[Update Action]
,a.[Parameter 1 Graph Link]=b.[Parameter 1 Graph Link]
,a.[Parameter 2 Graph Link]=b.[Parameter 2 Graph Link]
,a.[Supporting Visual Link 1]=b.[Supporting Visual Link 1]
,a.[Supporting Visual Link 2]=b.[Supporting Visual Link 2]
,a.[Create NewEntry]=b.[Create NewEntry]
WHEN NOT MATCHED BY TARGET THEN 
INSERT (Site
,Product
,[Sub Product]
,[Unit Operation]
,[Control Status]
,Title
,Description
,[Root Cause]
,Actions
,[Param _w_Units_ Field Name 1]
,[Param _w_Units_ Field Name 2]
,[Date Action Updated]
,[Update Action]
,[Parameter 1 Graph Link]
,[Parameter 2 Graph Link]
,[Supporting Visual Link 1]
,[Supporting Visual Link 2]
,[Create NewEntry]) 
VALUES (b.Site
,b.Product
,b.[Sub Product]
,b.[Unit Operation]
,b.[Control Status]
,b.Title
,b.Description
,b.[Root Cause]
,b.Actions
,b.[Param _w_Units_ Field Name 1]
,b.[Param _w_Units_ Field Name 2]
,b.[Date Action Updated]
,b.[Update Action]
,b.[Parameter 1 Graph Link]
,b.[Parameter 2 Graph Link]
,b.[Supporting Visual Link 1]
,b.[Supporting Visual Link 2]
,b.[Create NewEntry]
)
WHEN NOT MATCHED BY SOURCE 
    THEN DELETE;

DROP TABLE #IMEX_GC_PVR_DS_PF_DATA;

END;

