CREATE PROCEDURE [ALOG].[USP_ENDLOG] (@id AS INT = 1, @comments AS VARCHAR(200) ='', @id_error AS INT = 0)
AS
UPDATE alog.Tbl_ProcessLog
SET dtmActivityLog_EndTime = GETDATE(), strActivityLog_Comments=@comments, intActivityLog_Error=@id_error
WHERE intActivityLog_identity_ID=@id



GO
/****** Object:  StoredProcedure [ALOG].[USP_STARTLOG]    Script Date: 9/15/16 3:54:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [ALOG].[USP_STARTLOG] (@process AS VARCHAR(100), @db AS VARCHAR(100), @id INT OUTPUT)
AS

DECLARE @dte AS DATETIME

SET @dte = GETDATE()

INSERT INTO [AGENT_SUITE_DATA].ALOG.Tbl_ProcessLog (dtmActivityLog_StartTime, strActivityLog_Process, strActivityLog_DataBase)

VALUES (@dte, @process, @db)

SET @id = @@identity



GO
/****** Object:  StoredProcedure [dbo].[USP_AS_IMPORT_ADHERENCE]    Script Date: 9/15/16 3:54:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/**************************************************************************************************
History Changes:
Date:	2016-06-20
Purpose:  Made changes to the code to pick up data for Aliant and restructure to remove dynamic query.
By: Montosh Chowdhury
---------------------------
-- Author:		Hao Chen
-- Create date: 2015-03-23
-- Description:	IMPORT ACUT DATA FROM BREPP2
--**Changes done by Samuel Desrochers to add the view_AGENT_SUITE_ACUT_TICKETS_SOURCE to the ACUT tables 2015-04-02
**************************************************************************************************/
create procedure [dbo].[USP_AS_IMPORT_ADHERENCE] 
(
@Start_Date as varchar(11) = null, 
@End_date as varchar(11) = null,
@Override_warnings int = 0,
@LOB as varchar(10) = 'BELL'
)

as
begin
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
declare @main_log_id as int
declare @log_id as int
declare @logmessage varchar (max)
declare @error_comments as varchar(200)
declare @error_id as int
declare @rowcount as int
declare @current_day as datetime
declare @message varchar(max)
declare @validation_output int
declare @subjectContent varchar(150)

/***************************************************************************************************
STARTING UP THE LOG AND STORING THE ID in @LOG_ID
****************************************************************************************************/

exec ALOG.USP_STARTLOG 'AGENT SUITE MAIN IMPORT Adherence','AGENT_SUITE_DATA', @main_log_id output

/***************************************************************************************************
SELECTION OF THE DATE RANGE FOR THE EXTRACTION FOR AUTOMATED USES
MANUAL RECAST WILL POPULATE START AND END DATE AND WILL IGNORE THIS SELECTION
DEFAULT STRATEGY IS TO PULL A MONTH DAILY UP TO THE 10TH OF THE FOLLOWING MONTH
****************************************************************************************************/

if @Start_Date is null
	set @Start_Date = convert(varchar(10),
					case
					when datepart(DD,getdate()) < 10  -- START at 1st day of previous month
					then dateadd(month,datediff(month,0,dateadd(mm,-1,getdate())),0)
					else --START at 1st day of current month
					dateadd(month,datediff(month,0,getdate()),0)
					end,120)					

					
-- default end_date is day-1 but in some sources we will want 2 or 3 days back if the data is not solid at day-1 					
if @End_date is null
	set @End_date = convert(varchar(10),getdate()-1,120)

/****************************************************************************************************
History Changes:
Date:	2016-06-20
Purpose:  Made changes to the code to pick up data for Aliant when relevant parameter is passed in. 
The Data is now picked up from [BellAliant_SS_nsccom6].[WFM].[dbo].[eWFM_AP_New]
By: Montosh Chowdhury
-----------------------------------------------------------------------------------------------------
INSERT THE ADHERENCE DATA INTO THE STAGING TABLE FOR THE SELECTED DATES 
*****************************************************************************************************/

exec ALOG.USP_STARTLOG 'AGENT SUITE STAGING IMPORT ADHERENCE','AGENT_SUITE_DATA', @log_id output

begin try
	delete from STG.TBL_AS_SOURCE_ADHERENCE  where LOB = @LOB
	
	if @LOB = 'ALIANT'
	begin
		insert into STG.TBL_AS_SOURCE_ADHERENCE
		select	STAT_DATE
			,empNo
			,cast(Case	When metric_name = 'Adherence_Time' then 75
						When metric_name = 'Scheduled_Time' then 76
					end as varchar(20)) as Metric_id
			,value
			,'ALIANT' as LOB
			FROM
			(
				SELECT	STAT_DATE,
						LAN_ID,
						Adherence_time,
						scheduled_time 
				FROM [BellAliant_SS_nsccom6].[WFM].[dbo].[eWFM_AP_New]
				WHERE  Adherence_time IS NOT NULL AND scheduled_time IS NOT NULL
			) a INNER JOIN 	[BREPP1.BELL.CORP.BCE.CA].Source_Agents.dbo.TBL_EMPIDS b	
			ON a.lan_id = b.idValue AND a.STAT_DATE BETWEEN b.dtFrom AND b.dtTo AND b.systid = 15
			unpivot	(
						value for [metric_name] in ([Adherence_Time], [Scheduled_Time])
					) as UnPvt
			where STAT_DATE between @Start_Date and @End_date

	end
    else
	begin
		insert into STG.TBL_AS_SOURCE_ADHERENCE
			SELECT Rpt_date
				  ,[EMP_NO] 
				  ,cast(Case
					When metric_name = 'NUMERATOR' then 75
					when metric_name = 'DENOMINATOR' then 76

					end as varchar(20)) as Metric_id
				  ,value
				  ,'BELL' as LOB
			  FROM [BREPP2.BELL.CORP.BCE.CA].[Shrinkage_Metrics].dbo.VIEW_AGENT_SUITE_ADHERENCE test
					unpivot	(
							value for [metric_name] in ([NUMERATOR], [DENOMINATOR])
						) as UnPvt
					where RPT_DATE between @Start_Date and @End_date
					and value <> 0.00
   end

	set @rowcount = @@rowcount
end try

/****************************************************************************************************
ERROR CATCHING FOR IMPORT DATA TO STAGING
*****************************************************************************************************/

begin catch
	set @error_comments = error_message()
	set @error_id = error_number()
end catch

/****************************************************************************************************
PROCESS FOR ERRORS FOR IMPORT DATA TO STAGING
*****************************************************************************************************/

if isnull(@error_id,0) <> 0
begin 
	-- close the sub log for import into staging
	set @logmessage = 'import to staging failed: '+ @error_comments
	exec ALOG.USP_ENDLOG  @log_id, @logmessage

	-- close the main log since no more steps will be taken
	set @logmessage = 'aborted as per import to staging failed'
	exec ALOG.USP_ENDLOG  @main_log_id, @logmessage

	--email dba to report failure
	set @subjectContent = 'AGENT SUITE Adherence IMPORT FAILED FOR ' + @LOB
	set @message = 'IMPORTATION INTO STAGING FAILED, ERROR MESSAGE: ' + @error_comments
	exec msdb.dbo.sp_send_dbmail	
									@subject = @subjectContent,
									@body = @message,
									@body_format = 'TEXT',
									@recipients = 'CCBI.DBA@bell.ca';
									
end


if isnull(@error_id,0) = 0 -- closing 'import into staging' log since no errors were reported
begin 
	/****************************************************************************************************
	PROCESS LOG FOR SUCCESS OF IMPORT DATA TO STAGING
	*****************************************************************************************************/
	set @logmessage = 'Completed from '+ @Start_Date + ' to '+@End_date+ ' ' + cast(@rowcount as varchar) + ' Records were imported into staging'
	exec ALOG.USP_ENDLOG  @log_id, @logmessage

	/****************************************************************************************************
	VALIDATION AND IMPORTATION OF DAILY RESULTS INTO MAIN TABLE FROM STAGING ---Validation is now commented out in the validation stored procedure for future review
	*****************************************************************************************************/

	-- CREATION OF A LOOP FOR EACH DAY WITHIN IMPORT DATE RANGE

	set @current_day = cast(@Start_Date as datetime)

	while @current_day <= cast(@End_date as datetime)
	begin

		set @logmessage = 'AGENT SUITE DAILY IMPORT Adherence ' + cast(@current_day as varchar(11))
		exec ALOG.USP_STARTLOG @logmessage,'AGENT_SUITE_DATA', @log_id output

		--run validation procedure for the day and pickup output
		exec VAL.USP_AS_IMPORT_Adherence @current_day, @validation_output output
		-- output will be 0 if valid and 1 if invalid
		-- override will be 0 if default (no override) and 1 if override (need to be added manually as a parameter)

		if (@validation_output = 1 and @Override_warnings=0)
		-- do not process, close daily import log
		begin
			set @logmessage =  'No action taken as per validation results and no override'
			exec ALOG.USP_ENDLOG  @log_id, @logmessage
		end

		if (@validation_output = 0 or @Override_warnings=1)
		begin --of delete and insert new day of data

            delete  dsa
            from    dbo.TBL_AS_SOURCE_ADHERENCE dsa
                    inner join STG.TBL_AS_SOURCE_ADHERENCE ssa on ssa.EMP_NO = dsa.EMP_NO and ssa.METRIC_ID = dsa.METRIC_ID 
            where   dsa.RPT_DATE = @current_day
                    and ssa.LOB = @LOB;


			begin try
                insert  into dbo.TBL_AS_SOURCE_Adherence
                        ( RPT_DATE ,
                          EMP_NO ,
                          METRIC_ID ,
                          VALUE
						)
                        select  rpt_date ,
                                emp_no ,
                                metric_id ,
                                value
                        from    STG.TBL_AS_SOURCE_Adherence
                        where   RPT_DATE = @current_day
                                and VALUE <> '0' and LOB = @LOB;

				set @rowcount = @@rowcount
			end try

			begin catch
				set @error_comments = error_message()
				set @error_id = error_number()
			end catch

			if isnull(@error_id,0) = 0
			begin 
				set @logmessage = 'Daily insert completed, ' + cast(@rowcount as varchar) + ' rows added'
				exec ALOG.USP_ENDLOG  @log_id, @logmessage
			end -- of error management on daily insert

			if isnull(@error_id,0) <> 0
			begin 
				set @logmessage = 'Daily insert failed,reason ' + @error_comments
				exec ALOG.USP_ENDLOG  @log_id, @logmessage

				set @subjectContent = 'AGENT SUITE Adherence DAILY INSERTION FAILED FOR ' + @LOB
				set @message = 'INSERTION OF VALID DATA FOR ' + cast(@current_day as varchar) + ' failed, reason: ' + @error_comments
				exec msdb.dbo.sp_send_dbmail	@subject = @subjectContent,
												@body = @message,
												@body_format = 'TEXT',
												@recipients = 'CCBI.DBA@bell.ca';
												
			end -- of error management on daily insert

		end -- of delete and insert new day of data

		-- increment to next day for next pass
		set @current_day = dateadd(dd,1,@current_day)
	end -- of the while loop to validate and insert per day

	/****************************************************************************************************
	CLOSING MAIN LOG
	*****************************************************************************************************/

	if isnull(@error_id,0) = 0 
	begin 
		set @logmessage = 'Completed from '+ @Start_Date + ' to '+ @End_date 
		exec ALOG.USP_ENDLOG  @main_log_id, @logmessage
	end

	exec USP_REFRESH_STATIC_TABLE
end

end


GO
/****** Object:  StoredProcedure [dbo].[USP_REFRESH_STATIC_TABLE]    Script Date: 9/15/16 3:54:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_REFRESH_STATIC_TABLE]

AS
BEGIN
-- PLACE HOLDER PROCEDURE THAT WILL READ LOG TO DETERMINE WHICH STATIC TABLES NEED TO BE REFRESHED SINCE THE LAST RUN
PRINT ' Refreshing static tables'

END