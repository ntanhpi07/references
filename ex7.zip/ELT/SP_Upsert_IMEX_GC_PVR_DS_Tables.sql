--IMEX_GC_PVR_DS_CI_DATA
--use IIOT_ETL_DEV;
select Site
,Product
,[Sub Product]
,[Unit Operation]
,Parameter
,Type
,[Acceptance Criteria]
,[CPV Risk Score]
,[Date Raised]
,[Target Completion Date]
,[Problem Statement]
,[Periodic Update]
,Status
,Link
,[CI New Sample Link]
,[CI Update Entry Link]
from IMEX_GC_PVR_DS_CI_DATA;

--select count(*) from IMEX_GC_PVR_DS_CI_DATA;

--primary key: 54 rows
select Site
,Product
,[Sub Product]
,Parameter
,[CPV Risk Score]
from IMEX_GC_PVR_DS_CI_DATA
group by Site
,Product
,[Sub Product]
,Parameter
,[CPV Risk Score]
;

--------------------------------------------------------------------------------done

select Site
,Product
,[Sub Product]
,[X_Axis Value]
,[X_Axis Step]
,[X_Axis Steps in Current View]
,[Flag Current]
,[Total Risk Score]
,[Acceptance Criteria]
,[X_Axis Tick Label]
from IMEX_GC_PVR_DS_CIG_DATA

select count(*) from IMEX_GC_PVR_DS_CIG_DATA;

-- PK: 240 rows

select Site
,Product
,[Sub Product]
,[X_Axis Value]
from IMEX_GC_PVR_DS_CIG_DATA
group by Site
,Product
,[Sub Product]
,[X_Axis Value]
;

--------------------------------------------------------------------------------done

select Site
, Product
, [Sub Product]
,[Alarm Log ID]
,Parameter
,[Batch Number]
,Type
, [Alarm Details]
,[Date Alarm Logged]
from IMEX_GC_PVR_DS_CPV_UNL_DATA;

select count(*) from IMEX_GC_PVR_DS_CPV_UNL_DATA;

--pk: 12 rows

select Site
, Product
, [Sub Product]
,[Alarm Log ID]
from IMEX_GC_PVR_DS_CPV_UNL_DATA
group by Site
, Product
, [Sub Product]
,[Alarm Log ID]
;

---------------------------------

select Site
,Product
,[Sub Product]
,[X_Axis Value]
,[X_Axis Step]
,[X_Axis Tick Label]
,[Number of New Unlogged Flags]
,[Number of New Flags]
,[Number of Closed Flags]
,[Open Actions]
,[Flag Current]
,[Risk Ranking _ 0]
,[Risk Ranking _ 1]
,[Risk Ranking _ 2]
,[Risk Ranking _ 3]
,[Duration Count __30min]
,[Duration Count 31_60min]
,[Duration Count 61_90min]
,[Duration Count _90min]
,[OOC Count]
,[Shift Rule Count]
,[Trend Rule Count]
,[OOW Count]
,[OOS Count]
,[Total Nr Unlogged Flags]
from IMEX_GC_PVR_DS_CPVG_DATA;

--select count(*)  from IMEX_GC_PVR_DS_CPVG_DATA;

--pk --240 rows

select Site
,Product
,[Sub Product]
,[X_Axis Value]
from IMEX_GC_PVR_DS_CPVG_DATA
group by Site
,Product
,[Sub Product]
,[X_Axis Value]
;

---------------------------------

select Site
,Product
,[Sub Product]
,[Unit Operation]
,[Control Status]
,Title
,Description
,[Root Cause]
,Actions
,[Param _w_Units_ Field Name 1]
,[Param _w_Units_ Field Name 2]
,[Date Action Updated]
,[Update Action]
,[Parameter 1 Graph Link]
,[Parameter 2 Graph Link]
,[Supporting Visual Link 1]
,[Supporting Visual Link 2]
,[Create NewEntry]
from IMEX_GC_PVR_DS_PF_DATA;

select count(*) from IMEX_GC_PVR_DS_PF_DATA;

--pk: 5 rows

select Site
,Product
,[Sub Product]
,[Unit Operation]
,[Control Status]
,Title
,[Param _w_Units_ Field Name 1]
,[Param _w_Units_ Field Name 2]
,[Date Action Updated]
from IMEX_GC_PVR_DS_PF_DATA
group by Site
,Product
,[Sub Product]
,[Unit Operation]
,[Control Status]
,Title
,[Param _w_Units_ Field Name 1]
,[Param _w_Units_ Field Name 2]
,[Date Action Updated]
;

---------------------------------

select Site
,Product
,[Sub Product]
,[X_Axis Value]
,[X_Axis Step]
,[X_Axis Steps in Current View]
,[Flag Current]
,[Process Control Score]
,[Acceptance Criteria]
,[X_Axis Tick Label]
from IMEX_GC_PVR_DS_PFS_DATA;

-- select count(*) from IMEX_GC_PVR_DS_PFS_DATA;

--pk -- 125 rows

select Site
,Product
,[Sub Product]
,[X_Axis Value]

from IMEX_GC_PVR_DS_PFS_DATA
group by Site
,Product
,[Sub Product]
,[X_Axis Value]
;

---------------------------------

select [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Failure Rate]
,[Number of POR Batches]
,[Number of Ppk Batches]
,[X_Axis Steps in Current View]
,[X_Axis Step]
,[Distribution]
,Display
,[Flag Current]
,[Ppk Category]
,[X_Axis Tick Label]
,[X_Axis Value]
,[Number of Batches]
,Link
from IMEX_GC_PVR_DS_PPK_DATA;

select count(*) from IMEX_GC_PVR_DS_PPK_DATA;

--pk-- 9016 rows

select [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Flag Current]
,[Ppk Category]
,[X_Axis Tick Label]
,[X_Axis Value]
from IMEX_GC_PVR_DS_PPK_DATA WITH (NOLOCK)
group by [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Flag Current]
,[Ppk Category]
,[X_Axis Tick Label]
,[X_Axis Value]
;


---------------------------------

select [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Parameter Field Name]
,[Parameter _w_Units_ Field Name]
,[Ppk Value]
,PPM
,[Failure Rate]
,[Distribution]
,Display
,[Ppk Category]
,[Defect Rate]
,[Predicted Batch Loss]
,[Number of Batches]
,[Ppk Shift]
,Link
from IMEX_GC_PVR_DS_PPKD_DATA;

select count(*) from IMEX_GC_PVR_DS_PPKD_DATA;

--pk--162 rows

select [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Ppk Value]

from IMEX_GC_PVR_DS_PPKD_DATA
group by [Product Name]
,[Sub Product Name]
,[Sub Process]
,[Ppk Value]
;

---------------------------------

select [Product Name]
,[Sub Product Name]
,[Sub Process]
,Display
,[X_Axis Value]
,[X_Axis Tick Label]
,[X_Axis Step]
,[X_Axis Steps in Current View]
,[Ppk Roll Up]
,[Process Performance Score]
,[Defect Rate]
,[Predicted Batch Loss]
,[Predicted Batch Loss Status]
,[Flag Current]
,[Flag Most Current]
,[Flag Most Recent]
,[Ppk Shift]
,[Pct Ppk Cat 1]
,[Pct Ppk Cat 2]
,[Pct Ppk Cat 3]
,[Count Ppk Cat 1]
,[Count Ppk Cat 2]
,[Count Ppk Cat 3]
from IMEX_GC_PVR_DS_PSS_DATA
;

select count(*) from IMEX_GC_PVR_DS_PSS_DATA;

--pk

select [Product Name]
,[Sub Product Name]
,[Sub Process]
,[X_Axis Value]
from IMEX_GC_PVR_DS_PSS_DATA
group by [Product Name]
,[Sub Product Name]
,[Sub Process]
,[X_Axis Value]
;


---------------------------------