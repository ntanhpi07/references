﻿Select * /* Update A Set Value = '
Select A.Item_Nbr, A.Old_Nbr, A.Dept_Nbr, B.VNPK_COST_AMT as Vnpk_Cost_Amt, B.VNPK_QTY as Vnpk_Qty,            
		Cast((B.VNPK_COST_AMT / B.VNPK_QTY) as numeric(9,2)) As Item_Unit_Cost,     A.Cost, B.ITEM_CREATE_DT as Start_Date, B.ITEM_EXPIRE_DATE as End_Date, 
		B.Item_Status_Code, A.Vendor_ID, C.Vendor_Seq_Nbr, IsNull(C.OI_Percent,0.00) OI_Percent,            
		((Cast((B.VNPK_COST_AMT / B.VNPK_QTY) as numeric(9,2))) * (IsNull(C.OI_Percent,0)/100) ) as Item_UnitCost_OI        
From Pricing_Data.dbo.Item_Hierarchy A Inner Join DW_Canada.dbo.Item B On A.Item_Nbr = B.Item_Nbr And A.Old_Nbr = B.Old_Nbr                   
		Left Outer Join StagingDBName.dbo.[DnpTeraData_Staging] C On A.Item_Nbr = C.Item_Nbr And A.Vendor_ID = C.Vendor_Nbr And A.Dept_Nbr = C.Dept_Nbr        
Order By A.Old_Nbr, A.Item_Nbr, A.Vendor_ID, A.Dept_Nbr   
' --*/	
From [dbo].[Config_Parameters] A
where KeyName --= 'CIAA_Item_Cost'
			  like 'CIAA%' 
order by 1
/*-- Insert Into [Config_Parameters]
Select 152, 'CIAA_Teradata','
SELECT DISTINCT t1.item_nbr, Cast(t3.vendor_nbr as int) VendorNbr, Cast(t3.vendor_nbr_dept as int) DeptNbr, Cast(t3.vendor_nbr_fineline as int) Seq 
FROM CA_WM_VM.item_REPLEN_method t1 INNER JOIN CA_WM_VM.vendor_replen_method t2 ON t1.vendor_nbr = t2.vendor_nbr AND t1.type_cd = t2.type_cd
						INNER JOIN CA_WM_VM.item_desc t3 ON t1.item_nbr = t3.item_nbr 
WHERE t3.status_code IN (''a'') AND t2.vndr_status_cd IN (''a'') 
ORDER BY 2, 3, 4, 1
', getdate()
*/

