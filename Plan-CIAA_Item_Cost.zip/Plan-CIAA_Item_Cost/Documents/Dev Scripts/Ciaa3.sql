﻿Select loadtimestamp, count(*) from [ITEM_COST_Hist]
group by loadtimestamp order by 1

Select loadtimestamp, count(*) from [ITEM_COST]
group by loadtimestamp order by 1

Select loadtimestamp, count(*) 
-- Update A Set LoadTimeStamp = '2017-11-27 11:33:02.191'
from [ITEM_COST_Staging] A
group by loadtimestamp order by 1


/*
Select A.*
From Pricing_Data.dbo.Item_Hierarchy A Inner Join DW_Canada.dbo.Item B On A.Item_Nbr = B.Item_Nbr And A.Old_Nbr = B.Old_Nbr               
		--Left Outer Join StagingDBName.dbo.[DnpTeraData_Staging] C On A.Item_Nbr = C.Item_Nbr And A.Vendor_ID = C.Vendor_Nbr And A.Dept_Nbr = C.Dept_Nbr      
Where --A.Item_Nbr = 55804283
	A.Old_Nbr = 30051300
--Order By A.Old_Nbr, A.Item_Nbr, A.Vendor_ID, A.Dept_Nbr 

Select * From DW_Canada.dbo.Item
Where Item_Nbr = 55804283
*/