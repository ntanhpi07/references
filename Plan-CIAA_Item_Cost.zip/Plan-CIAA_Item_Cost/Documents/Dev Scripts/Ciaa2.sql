﻿Select top 3 * From Item_Cost			--	1059608
Select top 3 * From Item_Cost_Staging	--	1060888

-- Missing
Select Count(*) Missing
From dbo.ITEM_COST A Left Outer Join dbo.ITEM_COST_Staging B ON A.Item_Nbr = B.Item_Nbr
Where B.Item_Nbr IS NULL

-- New
Select Count(*) New
From dbo.ITEM_COST_Staging A Left Outer Join dbo.ITEM_COST B ON A.Item_Nbr = B.Item_Nbr
Where B.Item_Nbr IS NULL

-- Same Cnt
Select Count(*) SameCnt
From dbo.ITEM_COST_Staging A Inner Join dbo.ITEM_COST B ON A.Item_Nbr = B.Item_Nbr

-- Same UpdateCnt
Select Count(*) SameUpdateCnt
From dbo.ITEM_COST_Staging A Inner Join dbo.ITEM_COST B ON A.Item_Nbr = B.Item_Nbr
Where (A.Dept_Nbr <> B.Dept_Nbr Or A.VNPK_COST_AMT <> B.VNPK_COST_AMT Or A.VNPK_QTY <> B.VNPK_QTY Or 
  A.COST <> B.COST Or 
  A.ITEM_CREATE_DT <> B.ITEM_CREATE_DT Or A.ITEM_EXPIRE_DATE	<> B.ITEM_EXPIRE_DATE	
  Or A.ITEM_STATUS_CODE	<> B.ITEM_STATUS_CODE Or A.VENDOR_NBR <> B.VENDOR_NBR 
  Or IsNull(A.VENDOR_SEQ_NBR,'') <> IsNull(B.VENDOR_SEQ_NBR,'') Or A.OI_Percent <> B.OI_Percent)
--And A.Item_Nbr = 56451552
