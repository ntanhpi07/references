﻿declare @FromEmail varchar(2000), @ToEmailISDOnly varchar(2000), @ToEmailISDAndBusiness varchar(2000), @SQLCmd varchar(max), @DNPSql varchar(max), @WMGSql varchar(max), @DnpTdStage varchar(max), @StagingDbName varchar(max)

SET @FromEmail= (select Value from [dbo].[Config_Parameters] where KeyName = 'FromEmail')

SET @ToEmailISDOnly= (select Value from [dbo].[Config_Parameters] where KeyName = 'CIAA_ToEmailISDOnly')

SET @ToEmailISDAndBusiness= (select Value from [dbo].[Config_Parameters] where KeyName = 'CIAA_ToEmailISDAndBusiness')

SET @SQLCmd = (Select Value From [dbo].[Config_Parameters] where KeyName = 'CIAA_Item_Cost')

SET @DNPSql = (Select Value From [dbo].[Config_Parameters] where KeyName = 'CIAA_DNP_OiCm_Pct')

SET @WMGSql = (Select Value From [dbo].[Config_Parameters] where KeyName = 'CIAA_Teradata')

SET @DnpTdStage = (Select Value From [dbo].[Config_Parameters] where KeyName = 'CIAA_DnpTdStaging')

SET @StagingDbName = (Select Value From [dbo].[Config_Parameters] where KeyName = 'CIAA_StagingDBName')

Select @FromEmail v1, @ToEmailISDOnly v2, @ToEmailISDAndBusiness v3, @SQLCmd  v4, @DNPSql v5, @WMGSql v6, @DnpTdStage v7, @StagingDbName v8, GetDate() v9


