﻿Select Count(*) From [ITEM_COST_Hist]	--1059608	1087585
Select Count(*) From [ITEM_COST]		--1059608	1060888
Select Count(*) From Item_Cost_Staging  --1060888	1060888

Select Count(*) From [ITEM_COST_Hist_BKUP]
Select Count(*) From [ITEM_COST_BKUP]
Select Count(*) From ITEM_COST_Staging_BkUp

-- TRUNCATE TABLE [ITEM_COST_Hist] 
-- TRUNCATE TABLE [ITEM_COST]
-- INSERT INTO [ITEM_COST_Hist] SELECT * FROM [ITEM_COST_Hist_BKUP]
-- INSERT INTO [ITEM_COST] SELECT * FROM [ITEM_COST_BKUP]
-- INSERT INTO [ITEM_COST_Staging_BkUp] SELECT * FROM Item_Cost_Staging
