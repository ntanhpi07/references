﻿Use Pricing_Data
--	Insert into [ITEM_COST] select * from td_dev.dbo.[ITEM_COST]
--	Insert into [ITEM_COST_Hist] select * from td_dev.dbo.[ITEM_COST_Hist]
