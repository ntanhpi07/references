CREATE TABLE [dbo].[ITEM_COST] (
    [ITEM_NBR] bigint NULL, 
    [OLD_NBR] bigint NULL, 
    [DEPT_NBR] int NULL, 
    [VNPK_COST_AMT] decimal(18, 4) NULL, 
    [VNPK_QTY] int NULL, 
    [ITEM_UNIT_COST] decimal(18, 4) NULL, 
    [COST] decimal(7, 2) NULL, 
    [ITEM_CREATE_DT] date NULL, 
    [ITEM_EXPIRE_DATE] date NULL, 
    [ITEM_STATUS_CODE] char(2) COLLATE Latin1_General_100_CI_AS_KS_WS NULL, 
    [VENDOR_NBR] int NULL, 
    [VENDOR_SEQ_NBR] int NULL, 
    [OI_Percent] decimal(5, 2) NULL, 
    [ITEM_UNITCOST_OI] decimal(18, 4) NULL, 
    [LOADTIMESTAMP] datetime2(3) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([ITEM_NBR]));

CREATE TABLE [dbo].[ITEM_COST_Hist] (
    [ITEM_NBR] bigint NULL, 
    [OLD_NBR] bigint NULL, 
    [DEPT_NBR] int NULL, 
    [VNPK_COST_AMT] decimal(18, 4) NULL, 
    [VNPK_QTY] int NULL, 
    [ITEM_UNIT_COST] decimal(18, 4) NULL, 
    [COST] decimal(7, 2) NULL, 
    [ITEM_CREATE_DT] date NULL, 
    [ITEM_EXPIRE_DATE] date NULL, 
    [ITEM_STATUS_CODE] char(2) COLLATE Latin1_General_100_CI_AS_KS_WS NULL, 
    [VENDOR_NBR] int NULL, 
    [VENDOR_SEQ_NBR] int NULL, 
    [OI_Percent] decimal(5, 2) NULL, 
    [ITEM_UNITCOST_OI] decimal(18, 4) NULL, 
    [LOADTIMESTAMP] datetime2(3) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([ITEM_NBR]));


CREATE TABLE [dbo].[ITEM_COST_Staging] (
    [ITEM_NBR] bigint NULL, 
    [OLD_NBR] bigint NULL, 
    [DEPT_NBR] int NULL, 
    [VNPK_COST_AMT] decimal(18, 4) NULL, 
    [VNPK_QTY] int NULL, 
    [ITEM_UNIT_COST] decimal(18, 4) NULL, 
    [COST] decimal(7, 2) NULL, 
    [ITEM_CREATE_DT] date NULL, 
    [ITEM_EXPIRE_DATE] date NULL, 
    [ITEM_STATUS_CODE] char(2) COLLATE Latin1_General_100_CI_AS_KS_WS NULL, 
    [VENDOR_NBR] int NULL, 
    [VENDOR_SEQ_NBR] int NULL, 
    [OI_Percent] decimal(5, 2) NULL, 
    [ITEM_UNITCOST_OI] decimal(18, 4) NULL, 
    [LOADTIMESTAMP] datetime2(3) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([ITEM_NBR]));
