﻿CREATE VIEW View_On_Hand_Inventory
AS
SELECT x.DEPT_NBR, x.DEPT_DESC, x.ITEM_NBR, x.OLD_NBR, x.ITEM_DESCRIPTION, x.ITEM_STATUS_CODE, x.CHANNEL,
SUM(x.ON_ORDER_QTY) as ON_ORDER_QTY,
SUM(x.IN_TRANSIT_QTY) as IN_TRANSIT_QTY,
SUM(x.IN_STORE_QTY) as IN_STORE_QTY,
SUM(x.ON_LINE_QTY) as ON_LINE_QTY
FROM
(SELECT top 10 a.DEPT_NBR,
a.DEPT_DESC,
a.ITEM_NBR,
a.OLD_NBR,
a.ITEM_DESCRIPTION,
a.ITEM_STATUS_CODE,
c.productDomain as 'CHANNEL',
'' as 'ON_ORDER_QTY',
'' as 'IN_TRANSIT_QTY',
'' as 'IN_STORE_QTY',
COUNT(b.OH_STATUS) as 'ON_LINE_QTY'
FROM Pricing_Data.dbo.Item_Hierarchy a left join Pricing_Data.dbo.PCA_Ora_Oh b on a.old_nbr = b.old_nbr 
and cast(b.oh_dt AS DATE) = dateadd(day,-1, cast(getdate() AS DATE))
left join Pricing_DM.dbo.CIA_ENDECA c on a.old_nbr=c.itemNbr
GROUP BY a.DEPT_NBR,a.DEPT_DESC,a.Item_Nbr,a.old_nbr, a.item_description, a.item_status_code, c.productDomain
UNION
SELECT a.DEPT_NBR,
a.DEPT_DESC,
a.ITEM_NBR,
a.OLD_NBR,
a.ITEM_DESCRIPTION,
a.ITEM_STATUS_CODE,
c.productDomain as 'CHANNEL',
SUM( b.ON_ORDER_QTY ) as 'ON_ORDER_QTY',
SUM( b.IN_TRANSIT_QTY ) as 'IN_TRANSIT_QTY',
SUM( b.ON_HAND_QTY ) as 'IN_STORE_QTY',
'' as 'ON_LINE_QTY'
FROM Pricing_Data.dbo.Item_Hierarchy a LEFT JOIN TD_DEV.dbo.STOCK_KEEPING_UNIT b ON b.item_nbr = a.old_nbr
LEFT JOIN Pricing_DM.dbo.CIA_ENDECA c on a.old_nbr=c.itemNbr
WHERE c.productDomain in ('STORE', 'SHARED')
GROUP BY a.DEPT_NBR,a.DEPT_DESC,a.ITEM_NBR,a.OLD_NBR, a.ITEM_DESCRIPTION, a.ITEM_STATUS_CODE, c.productDomain
) x
GROUP BY x.DEPT_NBR, x.DEPT_DESC, x.ITEM_NBR, x.OLD_NBR, x.ITEM_DESCRIPTION, x.ITEM_STATUS_CODE, x.CHANNEL
