USE [IOT_ETL_ENERGY_ECS]
GO
--create all temp table in tempdb

SELECT * INTO ##Alarms
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.alarms')

GO

SELECT * INTO ##AuditTrail
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.AuditTrail')

GO

SELECT * INTO ##MapEvents
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MapEvents')

GO

SELECT * INTO ##MapStatus
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MapStatus')

GO

SELECT * INTO ##MemoryStatus
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MemoryStatus')

GO

SELECT * INTO ##MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC')

GO

SELECT * INTO ##MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC](
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC')

GO

SELECT * INTO ##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps')

GO

SELECT * INTO ##MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC')

GO

SELECT * INTO ##MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote](
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp')

GO

SELECT * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure')

GO
SELECT * INTO ##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans')

GO

SELECT * INTO ##MTrend__n1_osp3_4GBF_GB839_1F801_MCC
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_1F801_MCC')

GO

SELECT * INTO ##MTrend__n1_osp3_4GBF_GB839_2B839_MCC
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_2B839_MCC')

GO

SELECT * INTO ##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control')

GO

SELECT * INTO ##MTrend__n1_osp3_4GBF_GB839_5C_D_G802
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_5C_D_G802')

GO

SELECT * INTO ##MTrend__n1_osp3_4GBF_GB839_6Chiller
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_6Chiller')

GO

SELECT * INTO ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_007_UC3224
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_007_UC3224')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_008_UC3216
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_008_UC3216')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_013_UC328
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_013_UC328')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_0501
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0501')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_0502
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0502')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_0503
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0503')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_4Extract
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_4Extract')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_5Downflow_booth
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_5Downflow_booth')

GO

SELECT * INTO ##MTrend__n1_osp3_5Annex_6GBN_801
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_6GBN_801')

GO
;



