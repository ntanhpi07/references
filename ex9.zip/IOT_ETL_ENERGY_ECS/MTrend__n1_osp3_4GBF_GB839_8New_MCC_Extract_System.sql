USE [IOT_ETL_ENERGY_ECS]
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System;

alter PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System]
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @mysql_schema varchar(100) = 'iot_energy_ecs_rng'
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System') drop table ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System')

SET @loadedRow = @@ROWCOUNT

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec dbo.[SP_Merge_StartLog] 'Merging data on [energy_ecs_ahu].[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System]', @mysql_schema, @mssql_schema, @log_id output

BEGIN TRY

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System') drop table ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System] a 
USING ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[MCCExtract_Fan_GB_809_enable],0)=isnull(b.[MCCExtract_Fan_GB_809_enable],0)
and isnull(a.[MCC_Room_Temperature],0)=isnull(b.[MCC_Room_Temperature],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[MCCExtract_Fan_GB_809_enable]=b.[MCCExtract_Fan_GB_809_enable]
      ,a.[MCC_Room_Temperature]=b.[MCC_Room_Temperature]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[MCCExtract_Fan_GB_809_enable]
      ,[MCC_Room_Temperature]
) 
VALUES (b.[ReadingTime]
      ,b.[MCCExtract_Fan_GB_809_enable]
      ,b.[MCC_Room_Temperature]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging '+ @mssql_schema +'.[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System] failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec dbo.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging '+ @mssql_schema +'.[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System] completed.'

	update dbo.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec dbo.[SP_Merge_EndLog] @log_id, @logmessage

end
