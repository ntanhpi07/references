/*
For references:

				SET @vquery = 'SELECT CONCAT('+ @column_names +') FROM '  + @TEMPTABLE + ';'

				SET @vsql = 'SET @cursor = cursor for ' + @vquery + ' OPEN @cursor;'

				print '@vsql: ' + @vsql

				EXEC sp_executesql @vsql, N'@cursor cursor output', @C2 output

				FETCH NEXT

				FROM @C2 INTO @str_concat

				WHILE @@FETCH_STATUS = 0

				BEGIN

				--PRINT @str_concat

				SET @STRSQL2 = @STRSQL2 + @str_concat 
				
				PRINT '@STRSQL2: ' + @STRSQL2


				FETCH NEXT

				FROM @C2 INTO @str_concat

				END

				CLOSE @C2

				DEALLOCATE @C2
				--print '@str_concat: ' + @str_concat
			
*/

ALTER PROCEDURE SP_Create_Temp_Tables(@flag INT OUTPUT)
AS
DECLARE @STRSQL NVARCHAR(MAX);
DECLARE @vsql NVARCHAR(MAX);
DECLARE @vquery NVARCHAR(MAX);

DECLARE @TABLE NVARCHAR(128);

DECLARE @SCHEMA VARCHAR(100)

DECLARE @SCHEMA_NAME VARCHAR(100)

set @flag=0

SET @SCHEMA = 'iot_energy_ecs_rng'

SET @STRSQL = '';

DECLARE @C1 as CURSOR

SET @vquery = 'SELECT table_name 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT table_name FROM information_schema.tables WHERE table_schema=''''' + @SCHEMA + ''''''')'

SET @vsql = 'SET @cursor = cursor for ' + @vquery + ' OPEN @cursor;'

--PRINT @vquery

EXEC sp_executesql @vsql, N'@cursor cursor output', @C1 output

FETCH NEXT

FROM @C1 INTO @TABLE

WHILE @@FETCH_STATUS = 0

BEGIN

SET @STRSQL = ''

--PRINT @TABLE

SET @STRSQL = 'SELECT * INTO ' + '##' + @TABLE + ' FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @SCHEMA + '.' + @TABLE + ''')' + ';'

--PRINT @STRSQL

EXEC sp_executesql @STRSQL;

SET @STRSQL = ''

FETCH NEXT

FROM @C1 INTO @TABLE

END

CLOSE @C1

DEALLOCATE @C1

