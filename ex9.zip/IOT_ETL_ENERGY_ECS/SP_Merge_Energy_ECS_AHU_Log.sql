USE [IOT_ETL_ENERGY_ECS]
GO

-- select * from dbo.IOT_ETL_Energy_ECS_Logs
-- exec SP_Merge_Energy_ECS_AHU_Log
-- delete from dbo.IOT_ETL_Energy_ECS_Logs;

ALTER PROCEDURE [dbo].[SP_Merge_Energy_ECS_AHU_Log]
AS
BEGIN

declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

	exec dbo.[SP_Merge_StartLog] 'Merging Energy_ECS_AHU','IIOT_ETL_DEV', @log_id output

	BEGIN TRY
						
		EXECUTE SP_Merge_Energy_ECS_AHU 

	END TRY  
	BEGIN CATCH  
		set @errMsg = error_message()
		set @errNo = error_number()
	END CATCH;

	if isnull(@errNo,0) <> 0
	begin 

		-- close the log 
		set @message = 'Merging failed.'
		set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
		exec dbo.[SP_Merge_EndLog] @log_id, @message, @logmessage

		-- send email notice here
	end

	if isnull(@errNo,0) = 0 -- closing merge
	begin 
		set @logmessage = 'Merging Energy_ECS_AHU completed: '

		exec dbo.[SP_Merge_EndLog] @log_id, @logmessage

		--send email notice here

	end
END;