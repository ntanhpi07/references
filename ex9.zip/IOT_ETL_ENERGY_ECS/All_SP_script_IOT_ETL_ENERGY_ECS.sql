USE [IOT_ETL_ENERGY_ECS]
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_EndLog]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_EndLog] (@id AS INT = 1, @msg AS VARCHAR(200) ='', @errMsg AS nvarchar(max) = '')
AS
BEGIN
	UPDATE [IOT_ETL_ENERGY_ECS].energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	SET EndTime = GETDATE(), Msg=@msg, ErrMsg=@errMsg
	WHERE ID=@id
END;
GO

/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_StartLog]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_StartLog] (@process AS VARCHAR(100), @mysql varchar(100), @db AS VARCHAR(100), @schema AS VARCHAR(100), @id INT OUTPUT)
AS
BEGIN
	DECLARE @dte AS DATETIME
	SET @dte = GETDATE()
	INSERT INTO [IOT_ETL_ENERGY_ECS].energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs (StartTime, Process, DBSource, DBTarget, [Schema])
	VALUES (@dte, @process, @mysql, @db, @schema)
	SET @id = @@identity
END;
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_Alarms]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_Alarms 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_Alarms]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [Alarms]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

--create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##Alarms'') drop table ##Alarms
SELECT distinct * INTO ##Alarms FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.Alarms'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

set @strsql='
MERGE ' + @mssql_schema + '.[Alarms] a 
USING ##Alarms b
ON (a.[alarmid]=b.[alarmid] 
)
WHEN MATCHED THEN 
UPDATE SET a.[applicationname]=b.[applicationname]
           ,a.[alarmname]=b.[alarmname]
           ,a.[occurrencedate]=b.[occurrencedate]
           ,a.[description]=b.[description]
           ,a.[value]=b.[value]
           ,a.[priority]=b.[priority]
           ,a.[status]=b.[status]
           ,a.[ackdate]=b.[ackdate]
           ,a.[ackwho]=b.[ackwho]
           ,a.[cleardate]=b.[cleardate]
           ,a.[clearwho]=b.[clearwho]
           ,a.[comment]=b.[comment]
           ,a.[unitid]=b.[unitid]
           ,a.[channel]=b.[channel]
           ,a.[exceptionclass]=b.[exceptionclass]
           ,a.[causecode]=b.[causecode] 
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([alarmid]
           ,[applicationname]
           ,[alarmname]
           ,[occurrencedate]
           ,[description]
           ,[value]
           ,[priority]
           ,[status]
           ,[ackdate]
           ,[ackwho]
           ,[cleardate]
           ,[clearwho]
           ,[comment]
           ,[unitid]
           ,[channel]
           ,[exceptionclass]
           ,[causecode] ) 
VALUES (b.[alarmid]
           ,b.[applicationname]
           ,b.[alarmname]
           ,b.[occurrencedate]
           ,b.[description]
           ,b.[value]
           ,b.[priority]
           ,b.[status]
           ,b.[ackdate]
           ,b.[ackwho]
           ,b.[cleardate]
           ,b.[clearwho]
           ,b.[comment]
           ,b.[unitid]
           ,b.[channel]
           ,b.[exceptionclass]
           ,b.[causecode] 
) OUTPUT
      $action, inserted.alarmid ''inserted'', deleted.alarmid ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_AuditTrail]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].[SP_Merge_ahu_AuditTrail] 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_AuditTrail]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS
declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [AuditTrail]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##AuditTrail'') drop table ##AuditTrail
SELECT distinct * INTO ##AuditTrail FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.AuditTrail'')'
--print @strsql
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/
set @strsql='
MERGE ' + @mssql_schema + '.[AuditTrail] a 
USING ##AuditTrail b
ON (a.[audittrailid]=b.[audittrailid] 
)
WHEN MATCHED THEN 
UPDATE SET a.[occurrencedate]=b.[occurrencedate]
      ,a.[username]=b.[username]
      ,a.[priority]=b.[priority]
      ,a.[uiComponent]=b.[uiComponent]
      ,a.[disposition]=b.[disposition]
      ,a.[auditMessage]=b.[auditMessage]
      ,a.[newvalue]=b.[newvalue]
      ,a.[auditTrailManager]=b.[auditTrailManager]
      ,a.[description]=b.[description]
      ,a.[auditTrailManagerId]=b.[auditTrailManagerId]
      ,a.[origin]=b.[origin]
      ,a.[previousValue]=b.[previousValue]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([audittrailid]
      ,[occurrencedate]
      ,[username]
      ,[priority]
      ,[uiComponent]
      ,[disposition]
      ,[auditMessage]
      ,[newvalue]
      ,[auditTrailManager]
      ,[description]
      ,[auditTrailManagerId]
      ,[origin]
      ,[previousValue]) 
VALUES (b.[audittrailid]
      ,b.[occurrencedate]
      ,b.[username]
      ,b.[priority]
      ,b.[uiComponent]
      ,b.[disposition]
      ,b.[auditMessage]
      ,b.[newvalue]
      ,b.[auditTrailManager]
      ,b.[description]
      ,b.[auditTrailManagerId]
      ,b.[origin]
      ,b.[previousValue] 
) OUTPUT
      $action, inserted.audittrailid ''inserted'', deleted.audittrailid ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end

-----------------------------------------------------------------------------------------------------------------------
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MapEvents]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
exec SP_Create_Temp_Tables 0

exec SP_Drop_Temp_Tables
select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME like '##%'
select * from ##MapEvents;
*/
-- exec [energy_ecs_ahu].SP_Merge_ahu_MapEvents 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MapEvents]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS
declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MapEvents]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID INT, DeletedID INT)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MapEvents'') drop table ##MapEvents
SELECT distinct * INTO ##MapEvents FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MapEvents'')'

EXEC sp_executesql @strsql;
SET @loadedRow = @@ROWCOUNT
set @strsql=''
/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MapEvents] a 
USING ##MapEvents b
ON (a.[eventid]=b.[eventid] 
)
WHEN MATCHED THEN 
UPDATE SET a.[eventid]=b.[eventid]
,[occurrencedate]=b.[occurrencedate]
      ,[eventtype]=b.[eventtype]
      ,[priority]=b.[priority]
      ,[source]=b.[source]
      ,[description]=b.[description]
      ,[origin]=b.[origin]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([eventid]
      ,[occurrencedate]
      ,[eventtype]
      ,[priority]
      ,[source]
      ,[description]
      ,[origin] ) 
VALUES (b.[eventid]
      ,b.[occurrencedate]
      ,b.[eventtype]
      ,b.[priority]
      ,b.[source]
      ,b.[description]
      ,b.[origin] 
) OUTPUT
      $action, inserted.eventid ''inserted'', deleted.eventid ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MapStatus]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- exec [energy_ecs_ahu].SP_Merge_ahu_MapStatus 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MapStatus]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS
declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

-----------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MapStatus]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MapStatus'') drop table ##MapStatus
SELECT distinct * INTO ##MapStatus FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MapStatus'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MapStatus] a 
USING ##MapStatus b
ON ( a.[ReadingTime]=b.[ReadingTime]
and a.[ElapsedSparklineSecs]=b.[ElapsedSparklineSecs]
and a.[ElapsedSummarySecs]=b.[ElapsedSummarySecs]
and a.[ElapsedAlarmSecs]=b.[ElapsedAlarmSecs]
and a.[ElapsedTrendSecs]=b.[ElapsedTrendSecs]
)
WHEN MATCHED THEN 
UPDATE SET [ReadingTime]=b.[ReadingTime]
	  ,[ElapsedSparklineSecs]=b.[ElapsedSparklineSecs]
      ,[ElapsedSummarySecs]=b.[ElapsedSummarySecs]
      ,[ElapsedAlarmSecs]=b.[ElapsedAlarmSecs]
      ,[ElapsedTrendSecs]=b.[ElapsedTrendSecs]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[ElapsedSparklineSecs]
      ,[ElapsedSummarySecs]
      ,[ElapsedAlarmSecs]
      ,[ElapsedTrendSecs]) 
VALUES (b.[ReadingTime]
      ,b.[ElapsedSparklineSecs]
      ,b.[ElapsedSummarySecs]
      ,b.[ElapsedAlarmSecs]
      ,b.[ElapsedTrendSecs] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MemoryStatus]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MemoryStatus 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MemoryStatus]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MemoryStatus]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MemoryStatus'') drop table ##MemoryStatus
SELECT distinct * INTO ##MemoryStatus FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MemoryStatus'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MemoryStatus] a 
USING ##MemoryStatus b
ON ( a.[ReadingTime]=b.[ReadingTime]
and a.[JvmTotal]=b.[JvmTotal]
and a.[CombinedFree]=b.[CombinedFree]
and a.[SystemTotal]=b.[SystemTotal]
and a.[SystemFree]=b.[SystemFree]
and a.[JvmFree]=b.[JvmFree]
and a.[SwapFree]=b.[SwapFree]
and a.[SwapTotal]=b.[SwapTotal]
)
WHEN MATCHED THEN 
UPDATE SET [ReadingTime]=b.[ReadingTime]
	  ,[JvmTotal]=b.[JvmTotal]
      ,[CombinedFree]=b.[CombinedFree]
      ,[SystemTotal]=b.[SystemTotal]
      ,[SystemFree]=b.[SystemFree]
      ,[JvmFree]=b.[JvmFree]
      ,[SwapFree]=b.[SwapFree]
      ,[SwapTotal]=b.[SwapTotal]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[JvmTotal]
      ,[CombinedFree]
      ,[SystemTotal]
      ,[SystemFree]
      ,[JvmFree]
      ,[SwapFree]
      ,[SwapTotal]) 
VALUES (b.[ReadingTime]
      ,b.[JvmTotal]
      ,b.[CombinedFree]
      ,b.[SystemTotal]
      ,b.[SystemFree]
      ,b.[JvmFree]
      ,b.[SwapFree]
      ,b.[SwapTotal] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC'') drop table ##MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC
SELECT distinct * INTO ##MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBC801_Run_Signal_i],0)=isnull(b.[GBC801_Run_Signal_i],0)
)
WHEN MATCHED THEN 
UPDATE SET [ReadingTime]=b.[ReadingTime]
	,[GBC801_Run_Signal_i]=b.[GBC801_Run_Signal_i]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBC801_Run_Signal_i]) 
VALUES (b.[ReadingTime]
      ,b.[GBC801_Run_Signal_i] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote'') drop table ##MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBA_801_VSD_Speed_Actual_],0)=isnull(b.[GBA_801_VSD_Speed_Actual_],0)
and isnull(a.[TT80101A_Supply_Air_Temperature_GBA801],0)=isnull(b.[TT80101A_Supply_Air_Temperature_GBA801],0)
and isnull(a.[O_P_Glb_Outside_Frost],0)=isnull(b.[O_P_Glb_Outside_Frost],0)
and isnull(a.[TV80101_Heating_Vavle_Actuator_GBA801],0)=isnull(b.[TV80101_Heating_Vavle_Actuator_GBA801],0)
and isnull(a.[HV80101_Frost_Valve_Actuator_GBA801],0)=isnull(b.[HV80101_Frost_Valve_Actuator_GBA801],0)
and isnull(a.[TT801150_Outside_Air],0)=isnull(b.[TT801150_Outside_Air],0)
and isnull(a.[TS_80101_Frost_Stat_GBA801],0)=isnull(b.[TS_80101_Frost_Stat_GBA801],0)
and isnull(a.[S_Air_Setpoint_GBA801],0)=isnull(b.[S_Air_Setpoint_GBA801],0)
and isnull(a.[Room_Setpoint_GBA801],0)=isnull(b.[Room_Setpoint_GBA801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
	  ,[GBA_801_VSD_Speed_Actual_]=b.[GBA_801_VSD_Speed_Actual_]
      ,[TT80101A_Supply_Air_Temperature_GBA801]=b.[TT80101A_Supply_Air_Temperature_GBA801]
      ,[O_P_Glb_Outside_Frost]=b.[O_P_Glb_Outside_Frost]
      ,[TV80101_Heating_Vavle_Actuator_GBA801]=b.[TV80101_Heating_Vavle_Actuator_GBA801]
      ,[HV80101_Frost_Valve_Actuator_GBA801]=b.[HV80101_Frost_Valve_Actuator_GBA801]
      ,[TT801150_Outside_Air]=b.[TT801150_Outside_Air]
      ,[TS_80101_Frost_Stat_GBA801]=b.[TS_80101_Frost_Stat_GBA801]
      ,[S_Air_Setpoint_GBA801]=b.[S_Air_Setpoint_GBA801]
      ,[Room_Setpoint_GBA801]=b.[Room_Setpoint_GBA801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBA_801_VSD_Speed_Actual_]
      ,[TT80101A_Supply_Air_Temperature_GBA801]
      ,[O_P_Glb_Outside_Frost]
      ,[TV80101_Heating_Vavle_Actuator_GBA801]
      ,[HV80101_Frost_Valve_Actuator_GBA801]
      ,[TT801150_Outside_Air]
      ,[TS_80101_Frost_Stat_GBA801]
      ,[S_Air_Setpoint_GBA801]
      ,[Room_Setpoint_GBA801]) 
VALUES (b.[ReadingTime]
      ,b.[GBA_801_VSD_Speed_Actual_]
      ,b.[TT80101A_Supply_Air_Temperature_GBA801]
      ,b.[O_P_Glb_Outside_Frost]
      ,b.[TV80101_Heating_Vavle_Actuator_GBA801]
      ,b.[HV80101_Frost_Valve_Actuator_GBA801]
      ,b.[TT801150_Outside_Air]
      ,b.[TS_80101_Frost_Stat_GBA801]
      ,b.[S_Air_Setpoint_GBA801]
      ,b.[Room_Setpoint_GBA801] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote]', @mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote'') drop table ##MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[HV80102_Frost_Valve_Actuator_GBB801],0)=isnull(b.[HV80102_Frost_Valve_Actuator_GBB801],0)
and isnull(a.[TT80102A_Supply_Air_Temperature_GBB801_L5],0)=isnull(b.[TT80102A_Supply_Air_Temperature_GBB801_L5],0)
and isnull(a.[TV80102_Heating_Valve_Actuator_GBB801],0)=isnull(b.[TV80102_Heating_Valve_Actuator_GBB801],0)
and isnull(a.[TT80102A_Supply_Air_Temperature_GBB801_L1],0)=isnull(b.[TT80102A_Supply_Air_Temperature_GBB801_L1],0)
and isnull(a.[GBB_801_VSD_Speed_Actual_],0)=isnull(b.[GBB_801_VSD_Speed_Actual_],0)
and isnull(a.[TS_80102_Frost_Stat_GBB801],0)=isnull(b.[TS_80102_Frost_Stat_GBB801],0)
and isnull(a.[S_Air_Setpoint_GBB801],0)=isnull(b.[S_Air_Setpoint_GBB801],0)
and isnull(a.[Room_Setpoint_GBB801],0)=isnull(b.[Room_Setpoint_GBB801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[HV80102_Frost_Valve_Actuator_GBB801]=b.[HV80102_Frost_Valve_Actuator_GBB801]
, a.[TT80102A_Supply_Air_Temperature_GBB801_L5]=b.[TT80102A_Supply_Air_Temperature_GBB801_L5]
, a.[TV80102_Heating_Valve_Actuator_GBB801]=b.[TV80102_Heating_Valve_Actuator_GBB801]
, a.[TT80102A_Supply_Air_Temperature_GBB801_L1]=b.[TT80102A_Supply_Air_Temperature_GBB801_L1]
, a.[GBB_801_VSD_Speed_Actual_]=b.[GBB_801_VSD_Speed_Actual_]
, a.[TS_80102_Frost_Stat_GBB801]=b.[TS_80102_Frost_Stat_GBB801]
, a.[S_Air_Setpoint_GBB801]=b.[S_Air_Setpoint_GBB801]
, a.[Room_Setpoint_GBB801]=b.[Room_Setpoint_GBB801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[HV80102_Frost_Valve_Actuator_GBB801]
      ,[TT80102A_Supply_Air_Temperature_GBB801_L5]
      ,[TV80102_Heating_Valve_Actuator_GBB801]
      ,[TT80102A_Supply_Air_Temperature_GBB801_L1]
      ,[GBB_801_VSD_Speed_Actual_]
      ,[TS_80102_Frost_Stat_GBB801]
      ,[S_Air_Setpoint_GBB801]
      ,[Room_Setpoint_GBB801]) 
VALUES (b.[ReadingTime]
      ,b.[HV80102_Frost_Valve_Actuator_GBB801]
      ,b.[TT80102A_Supply_Air_Temperature_GBB801_L5]
      ,b.[TV80102_Heating_Valve_Actuator_GBB801]
      ,b.[TT80102A_Supply_Air_Temperature_GBB801_L1]
      ,b.[GBB_801_VSD_Speed_Actual_]
      ,b.[TS_80102_Frost_Stat_GBB801]
      ,b.[S_Air_Setpoint_GBB801]
      ,b.[Room_Setpoint_GBB801] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC'') drop table ##MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC
SELECT distinct * INTO ##MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBD801_Auto_Mode],0)=isnull(b.[GBD801_Auto_Mode],0)
and isnull(a.[GBD801_Start_Command],0)=isnull(b.[GBD801_Start_Command],0)
and isnull(a.[GBD801_Manual_Mode],0)=isnull(b.[GBD801_Manual_Mode],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
      ,a.[GBD801_Auto_Mode]=b.[GBD801_Auto_Mode]
      ,a.[GBD801_Start_Command]=b.[GBD801_Start_Command]
      ,a.[GBD801_Manual_Mode]=b.[GBD801_Manual_Mode]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBD801_Auto_Mode]
      ,[GBD801_Start_Command]
      ,[GBD801_Manual_Mode]) 
VALUES (b.[ReadingTime]
      ,b.[GBD801_Auto_Mode]
      ,b.[GBD801_Start_Command]
      ,b.[GBD801_Manual_Mode] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote'') drop table ##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TS_80103_Frost_Stat_GBC801],0)=isnull(b.[TS_80103_Frost_Stat_GBC801],0)
and isnull(a.[Glb_Outside_Frost],0)=isnull(b.[Glb_Outside_Frost],0)
and isnull(a.[TT80103A_S_Air_Mv_GBC801],0)=isnull(b.[TT80103A_S_Air_Mv_GBC801],0)
and isnull(a.[HV80103_Frost_Valve_Actuator_GBC801],0)=isnull(b.[HV80103_Frost_Valve_Actuator_GBC801],0)
and isnull(a.[TV80103_Heating_Vavle_Actuator_GBC801],0)=isnull(b.[TV80103_Heating_Vavle_Actuator_GBC801],0)
and isnull(a.[S_Air_Setpoint_GBC801],0)=isnull(b.[S_Air_Setpoint_GBC801],0)
and isnull(a.[Room_Setpoint_GBC801],0)=isnull(b.[Room_Setpoint_GBC801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[TS_80103_Frost_Stat_GBC801]=b.[TS_80103_Frost_Stat_GBC801]
, a.[Glb_Outside_Frost]=b.[Glb_Outside_Frost]
, a.[TT80103A_S_Air_Mv_GBC801]=b.[TT80103A_S_Air_Mv_GBC801]
, a.[HV80103_Frost_Valve_Actuator_GBC801]=b.[HV80103_Frost_Valve_Actuator_GBC801]
, a.[TV80103_Heating_Vavle_Actuator_GBC801]=b.[TV80103_Heating_Vavle_Actuator_GBC801]
, a.[S_Air_Setpoint_GBC801]=b.[S_Air_Setpoint_GBC801]
, a.[Room_Setpoint_GBC801]=b.[Room_Setpoint_GBC801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TS_80103_Frost_Stat_GBC801]
      ,[Glb_Outside_Frost]
      ,[TT80103A_S_Air_Mv_GBC801]
      ,[HV80103_Frost_Valve_Actuator_GBC801]
      ,[TV80103_Heating_Vavle_Actuator_GBC801]
      ,[S_Air_Setpoint_GBC801]
      ,[Room_Setpoint_GBC801]
) 
VALUES (b.[ReadingTime]
      ,b.[TS_80103_Frost_Stat_GBC801]
      ,b.[Glb_Outside_Frost]
      ,b.[TT80103A_S_Air_Mv_GBC801]
      ,b.[HV80103_Frost_Valve_Actuator_GBC801]
      ,b.[TV80103_Heating_Vavle_Actuator_GBC801]
      ,b.[S_Air_Setpoint_GBC801]
      ,b.[Room_Setpoint_GBC801] 
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote]', @mysql_schema,@db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote'') drop table ##MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TV80104_Heating_Valve_Actuator_GBD801],0)=isnull(b.[TV80104_Heating_Valve_Actuator_GBD801],0)
and isnull(a.[HV80104_Frost_Valve_Actuator_GBD801],0)=isnull(b.[HV80104_Frost_Valve_Actuator_GBD801],0)
and isnull(a.[TS_80104_Frost_Stat_GBD801],0)=isnull(b.[TS_80104_Frost_Stat_GBD801],0)
and isnull(a.[TT80104A_S_Air_Mv_GBD801],0)=isnull(b.[TT80104A_S_Air_Mv_GBD801],0)
and isnull(a.[GlB_Outside_Frost],0)=isnull(b.[GlB_Outside_Frost],0)
and isnull(a.[S_Air_Setpoint_GBD801],0)=isnull(b.[S_Air_Setpoint_GBD801],0)
and isnull(a.[Room_Setpoint_GBD801],0)=isnull(b.[Room_Setpoint_GBD801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[TV80104_Heating_Valve_Actuator_GBD801]=b.[TV80104_Heating_Valve_Actuator_GBD801]
, a.[HV80104_Frost_Valve_Actuator_GBD801]=b.[HV80104_Frost_Valve_Actuator_GBD801]
, a.[TS_80104_Frost_Stat_GBD801]=b.[TS_80104_Frost_Stat_GBD801]
, a.[TT80104A_S_Air_Mv_GBD801]=b.[TT80104A_S_Air_Mv_GBD801]
, a.[GlB_Outside_Frost]=b.[GlB_Outside_Frost]
, a.[S_Air_Setpoint_GBD801]=b.[S_Air_Setpoint_GBD801]
, a.[Room_Setpoint_GBD801]=b.[Room_Setpoint_GBD801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TV80104_Heating_Valve_Actuator_GBD801]
      ,[HV80104_Frost_Valve_Actuator_GBD801]
      ,[TS_80104_Frost_Stat_GBD801]
      ,[TT80104A_S_Air_Mv_GBD801]
      ,[GlB_Outside_Frost]
      ,[S_Air_Setpoint_GBD801]
      ,[Room_Setpoint_GBD801]
) 
VALUES (b.[ReadingTime]
      ,b.[TV80104_Heating_Valve_Actuator_GBD801]
      ,b.[HV80104_Frost_Valve_Actuator_GBD801]
      ,b.[TS_80104_Frost_Stat_GBD801]
      ,b.[TT80104A_S_Air_Mv_GBD801]
      ,b.[GlB_Outside_Frost]
      ,b.[S_Air_Setpoint_GBD801]
      ,b.[Room_Setpoint_GBD801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps  'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps'') drop table ##MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps
SELECT distinct * INTO ##MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps] a 
USING ##MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[A2nd_Floor_Process_temp],0)=isnull(b.[A2nd_Floor_Process_temp],0)
and isnull(a.[Room_Temperature_GBD801],0)=isnull(b.[Room_Temperature_GBD801],0)
and isnull(a.[Room_Temperature2_GBA801],0)=isnull(b.[Room_Temperature2_GBA801],0)
and isnull(a.[Room_Temperature1_GBA801],0)=isnull(b.[Room_Temperature1_GBA801],0)
and isnull(a.[Room_Temperature_GBC801],0)=isnull(b.[Room_Temperature_GBC801],0)
and isnull(a.[GBD801_Run_Signal],0)=isnull(b.[GBD801_Run_Signal],0)
and isnull(a.[A1st_Floor_Process_Temp],0)=isnull(b.[A1st_Floor_Process_Temp],0)
and isnull(a.[GBC801_Run_Signal],0)=isnull(b.[GBC801_Run_Signal],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[A2nd_Floor_Process_temp]=b.[A2nd_Floor_Process_temp]
, a.[Room_Temperature_GBD801]=b.[Room_Temperature_GBD801]
, a.[Room_Temperature2_GBA801]=b.[Room_Temperature2_GBA801]
, a.[Room_Temperature1_GBA801]=b.[Room_Temperature1_GBA801]
, a.[Room_Temperature_GBC801]=b.[Room_Temperature_GBC801]
, a.[GBD801_Run_Signal]=b.[GBD801_Run_Signal]
, a.[A1st_Floor_Process_Temp]=b.[A1st_Floor_Process_Temp]
, a.[GBC801_Run_Signal]=b.[GBC801_Run_Signal]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[A2nd_Floor_Process_temp]
      ,[Room_Temperature_GBD801]
      ,[Room_Temperature2_GBA801]
      ,[Room_Temperature1_GBA801]
      ,[Room_Temperature_GBC801]
      ,[GBD801_Run_Signal]
      ,[A1st_Floor_Process_Temp]
      ,[GBC801_Run_Signal]
) 
VALUES (b.[ReadingTime]
      ,b.[A2nd_Floor_Process_temp]
      ,b.[Room_Temperature_GBD801]
      ,b.[Room_Temperature2_GBA801]
      ,b.[Room_Temperature1_GBA801]
      ,b.[Room_Temperature_GBC801]
      ,b.[GBD801_Run_Signal]
      ,b.[A1st_Floor_Process_Temp]
      ,b.[GBC801_Run_Signal]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC]',  @mysql_schema,@db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC'') drop table ##MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC
SELECT distinct * INTO ##MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC] a 
USING ##MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBG801_Run_Signal_i],0)=isnull(b.[GBG801_Run_Signal_i],0)
and isnull(a.[GBE801_Run_Signal_i],0)=isnull(b.[GBE801_Run_Signal_i],0)
and isnull(a.[GBH801_Run_Signal_i],0)=isnull(b.[GBH801_Run_Signal_i],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[GBG801_Run_Signal_i]=b.[GBG801_Run_Signal_i]
, a.[GBE801_Run_Signal_i]=b.[GBE801_Run_Signal_i]
, a.[GBH801_Run_Signal_i]=b.[GBH801_Run_Signal_i]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBG801_Run_Signal_i]
      ,[GBE801_Run_Signal_i]
      ,[GBH801_Run_Signal_i]
) 
VALUES (b.[ReadingTime]
      ,b.[GBG801_Run_Signal_i]
      ,b.[GBE801_Run_Signal_i]
      ,b.[GBH801_Run_Signal_i]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote  'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote]', @mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote'') drop table ##MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote] a 
USING ##MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TT80105A_S_Air_Mv_GBE801],0)=isnull(b.[TT80105A_S_Air_Mv_GBE801],0)
and isnull(a.[Glb_Outside_Frost],0)=isnull(b.[Glb_Outside_Frost],0)
and isnull(a.[TV80105_Heating_Vavle_Actuator_GBE801],0)=isnull(b.[TV80105_Heating_Vavle_Actuator_GBE801],0)
and isnull(a.[HV80105_Frost_Valve_Actuator_GBE801],0)=isnull(b.[HV80105_Frost_Valve_Actuator_GBE801],0)
and isnull(a.[TS_80105_Frost_Stat_GBE801],0)=isnull(b.[TS_80105_Frost_Stat_GBE801],0)
and isnull(a.[S_Air_Setpoint_GBE801],0)=isnull(b.[S_Air_Setpoint_GBE801],0)
and isnull(a.[Room_Setpoint_GBE801],0)=isnull(b.[Room_Setpoint_GBE801],0)
)
WHEN MATCHED THEN 
UPDATE SET  a.[ReadingTime]=b.[ReadingTime]
, a.[TT80105A_S_Air_Mv_GBE801]=b.[TT80105A_S_Air_Mv_GBE801]
, a.[Glb_Outside_Frost]=b.[Glb_Outside_Frost]
, a.[TV80105_Heating_Vavle_Actuator_GBE801]=b.[TV80105_Heating_Vavle_Actuator_GBE801]
, a.[HV80105_Frost_Valve_Actuator_GBE801]=b.[HV80105_Frost_Valve_Actuator_GBE801]
, a.[TS_80105_Frost_Stat_GBE801]=b.[TS_80105_Frost_Stat_GBE801]
, a.[S_Air_Setpoint_GBE801]=b.[S_Air_Setpoint_GBE801]
, a.[Room_Setpoint_GBE801]=b.[Room_Setpoint_GBE801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TT80105A_S_Air_Mv_GBE801]
      ,[Glb_Outside_Frost]
      ,[TV80105_Heating_Vavle_Actuator_GBE801]
      ,[HV80105_Frost_Valve_Actuator_GBE801]
      ,[TS_80105_Frost_Stat_GBE801]
      ,[S_Air_Setpoint_GBE801]
      ,[Room_Setpoint_GBE801]
) 
VALUES (b.[ReadingTime]
      ,b.[TT80105A_S_Air_Mv_GBE801]
      ,b.[Glb_Outside_Frost]
      ,b.[TV80105_Heating_Vavle_Actuator_GBE801]
      ,b.[HV80105_Frost_Valve_Actuator_GBE801]
      ,b.[TS_80105_Frost_Stat_GBE801]
      ,b.[S_Air_Setpoint_GBE801]
      ,b.[Room_Setpoint_GBE801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote]', @mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote'') drop table ##MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote] a 
USING ##MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TV80107_Heating_Valve_Actuator_GBG801],0)=isnull(b.[TV80107_Heating_Valve_Actuator_GBG801],0)
and isnull(a.[Glb_Outside_Frost],0)=isnull(b.[Glb_Outside_Frost],0)
and isnull(a.[TS_80107_Frost_Stat_GBG801],0)=isnull(b.[TS_80107_Frost_Stat_GBG801],0)
and isnull(a.[TT80107A_S_Air_Mv_GBG801],0)=isnull(b.[TT80107A_S_Air_Mv_GBG801],0)
and isnull(a.[HV80107_Frost_Valve_Actuator_GBG801],0)=isnull(b.[HV80107_Frost_Valve_Actuator_GBG801],0)
and isnull(a.[S_Air_Setpoint_GBG801],0)=isnull(b.[S_Air_Setpoint_GBG801],0)
and isnull(a.[Room_Setpoint_GBG801],0)=isnull(b.[Room_Setpoint_GBG801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[TV80107_Heating_Valve_Actuator_GBG801]=b.[TV80107_Heating_Valve_Actuator_GBG801]
, a.[Glb_Outside_Frost]=b.[Glb_Outside_Frost]
, a.[TS_80107_Frost_Stat_GBG801]=b.[TS_80107_Frost_Stat_GBG801]
, a.[TT80107A_S_Air_Mv_GBG801]=b.[TT80107A_S_Air_Mv_GBG801]
, a.[HV80107_Frost_Valve_Actuator_GBG801]=b.[HV80107_Frost_Valve_Actuator_GBG801]
, a.[S_Air_Setpoint_GBG801]=b.[S_Air_Setpoint_GBG801]
, a.[Room_Setpoint_GBG801]=b.[Room_Setpoint_GBG801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TV80107_Heating_Valve_Actuator_GBG801]
      ,[Glb_Outside_Frost]
      ,[TS_80107_Frost_Stat_GBG801]
      ,[TT80107A_S_Air_Mv_GBG801]
      ,[HV80107_Frost_Valve_Actuator_GBG801]
      ,[S_Air_Setpoint_GBG801]
      ,[Room_Setpoint_GBG801]
) 
VALUES (b.[ReadingTime]
      ,b.[TV80107_Heating_Valve_Actuator_GBG801]
      ,b.[Glb_Outside_Frost]
      ,b.[TS_80107_Frost_Stat_GBG801]
      ,b.[TT80107A_S_Air_Mv_GBG801]
      ,b.[HV80107_Frost_Valve_Actuator_GBG801]
      ,b.[S_Air_Setpoint_GBG801]
      ,b.[Room_Setpoint_GBG801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote]',@mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote'') drop table ##MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote] a 
USING ##MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[Output_to_recirc_damper],0)=isnull(b.[Output_to_recirc_damper],0)
and isnull(a.[TV80113_Cooling_Valve_GBH801],0)=isnull(b.[TV80113_Cooling_Valve_GBH801],0)
and isnull(a.[MT80101A_S_Air_Humidity_GBH801],0)=isnull(b.[MT80101A_S_Air_Humidity_GBH801],0)
and isnull(a.[TS_80110_Frost_Stat_GBH801],0)=isnull(b.[TS_80110_Frost_Stat_GBH801],0)
and isnull(a.[TV80110_Heating_Valve_GBH801],0)=isnull(b.[TV80110_Heating_Valve_GBH801],0)
and isnull(a.[XV80110_Control_Dampers_GBH801],0)=isnull(b.[XV80110_Control_Dampers_GBH801],0)
and isnull(a.[TT80103A_S_air_Mv_GBH801],0)=isnull(b.[TT80103A_S_air_Mv_GBH801],0)
and isnull(a.[Supply_Temp_Setpoint_GBH801],0)=isnull(b.[Supply_Temp_Setpoint_GBH801],0)
and isnull(a.[Room_Setpoint_GBH801],0)=isnull(b.[Room_Setpoint_GBH801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[Output_to_recirc_damper]=b.[Output_to_recirc_damper]
, a.[TV80113_Cooling_Valve_GBH801]=b.[TV80113_Cooling_Valve_GBH801]
, a.[MT80101A_S_Air_Humidity_GBH801]=b.[MT80101A_S_Air_Humidity_GBH801]
, a.[TS_80110_Frost_Stat_GBH801]=b.[TS_80110_Frost_Stat_GBH801]
, a.[TV80110_Heating_Valve_GBH801]=b.[TV80110_Heating_Valve_GBH801]
, a.[XV80110_Control_Dampers_GBH801]=b.[XV80110_Control_Dampers_GBH801]
, a.[TT80103A_S_air_Mv_GBH801]=b.[TT80103A_S_air_Mv_GBH801]
, a.[Supply_Temp_Setpoint_GBH801]=b.[Supply_Temp_Setpoint_GBH801]
, a.[Room_Setpoint_GBH801]=b.[Room_Setpoint_GBH801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[Output_to_recirc_damper]
      ,[TV80113_Cooling_Valve_GBH801]
      ,[MT80101A_S_Air_Humidity_GBH801]
      ,[TS_80110_Frost_Stat_GBH801]
      ,[TV80110_Heating_Valve_GBH801]
      ,[XV80110_Control_Dampers_GBH801]
      ,[TT80103A_S_air_Mv_GBH801]
      ,[Supply_Temp_Setpoint_GBH801]
      ,[Room_Setpoint_GBH801]
) 
VALUES (b.[ReadingTime]
      ,b.[Output_to_recirc_damper]
      ,b.[TV80113_Cooling_Valve_GBH801]
      ,b.[MT80101A_S_Air_Humidity_GBH801]
      ,b.[TS_80110_Frost_Stat_GBH801]
      ,b.[TV80110_Heating_Valve_GBH801]
      ,b.[XV80110_Control_Dampers_GBH801]
      ,b.[TT80103A_S_air_Mv_GBH801]
      ,b.[Supply_Temp_Setpoint_GBH801]
      ,b.[Room_Setpoint_GBH801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote]',@mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote'') drop table ##MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote] a 
USING ##MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TV80115_Cooling_Valve_GBK801],0)=isnull(b.[TV80115_Cooling_Valve_GBK801],0)
and isnull(a.[TT80115A_S_air_Temp_Mv_GBK801_],0)=isnull(b.[TT80115A_S_air_Temp_Mv_GBK801_],0)
and isnull(a.[TV80112_Heating_Valve_GBK801],0)=isnull(b.[TV80112_Heating_Valve_GBK801],0)
and isnull(a.[Output_to_Recirc_Dampers],0)=isnull(b.[Output_to_Recirc_Dampers],0)
and isnull(a.[GBK_HUMIDIFIER],0)=isnull(b.[GBK_HUMIDIFIER],0)
and isnull(a.[MT80102A_S_Air_Humidity_GBH801],0)=isnull(b.[MT80102A_S_Air_Humidity_GBH801],0)
and isnull(a.[XV80112_Control_Dampers_GBK801],0)=isnull(b.[XV80112_Control_Dampers_GBK801],0)
and isnull(a.[Supply_Temp_Min_Spt],0)=isnull(b.[Supply_Temp_Min_Spt],0)
and isnull(a.[Supply_Temp_Max_Spt],0)=isnull(b.[Supply_Temp_Max_Spt],0)
and isnull(a.[Room_S_Pt],0)=isnull(b.[Room_S_Pt],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[TV80115_Cooling_Valve_GBK801]=b.[TV80115_Cooling_Valve_GBK801]
, a.[TT80115A_S_air_Temp_Mv_GBK801_]=b.[TT80115A_S_air_Temp_Mv_GBK801_]
, a.[TV80112_Heating_Valve_GBK801]=b.[TV80112_Heating_Valve_GBK801]
, a.[Output_to_Recirc_Dampers]=b.[Output_to_Recirc_Dampers]
, a.[GBK_HUMIDIFIER]=b.[GBK_HUMIDIFIER]
, a.[MT80102A_S_Air_Humidity_GBH801]=b.[MT80102A_S_Air_Humidity_GBH801]
, a.[XV80112_Control_Dampers_GBK801]=b.[XV80112_Control_Dampers_GBK801]
, a.[Supply_Temp_Min_Spt]=b.[Supply_Temp_Min_Spt]
, a.[Supply_Temp_Max_Spt]=b.[Supply_Temp_Max_Spt]
, a.[Room_S_Pt]=b.[Room_S_Pt]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TV80115_Cooling_Valve_GBK801]
      ,[TT80115A_S_air_Temp_Mv_GBK801_]
      ,[TV80112_Heating_Valve_GBK801]
      ,[Output_to_Recirc_Dampers]
      ,[GBK_HUMIDIFIER]
      ,[MT80102A_S_Air_Humidity_GBH801]
      ,[XV80112_Control_Dampers_GBK801]
      ,[Supply_Temp_Min_Spt]
      ,[Supply_Temp_Max_Spt]
      ,[Room_S_Pt]
) 
VALUES (b.[ReadingTime]
      ,b.[TV80115_Cooling_Valve_GBK801]
      ,b.[TT80115A_S_air_Temp_Mv_GBK801_]
      ,b.[TV80112_Heating_Valve_GBK801]
      ,b.[Output_to_Recirc_Dampers]
      ,b.[GBK_HUMIDIFIER]
      ,b.[MT80102A_S_Air_Humidity_GBH801]
      ,b.[XV80112_Control_Dampers_GBK801]
      ,b.[Supply_Temp_Min_Spt]
      ,b.[Supply_Temp_Max_Spt]
      ,b.[Room_S_Pt]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH'') drop table ##MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH
SELECT distinct * INTO ##MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH] a 
USING ##MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBJ803_Run_Signal],0)=isnull(b.[GBJ803_Run_Signal],0)
and isnull(a.[GBX803_Run_Signal],0)=isnull(b.[GBX803_Run_Signal],0)
and isnull(a.[TT80105_Room_Temperature_GBE801],0)=isnull(b.[TT80105_Room_Temperature_GBE801],0)
and isnull(a.[TT80113_Room_Temperature_GBH801],0)=isnull(b.[TT80113_Room_Temperature_GBH801],0)
and isnull(a.[TT80115_Room_Temperature_GBK801],0)=isnull(b.[TT80115_Room_Temperature_GBK801],0)
and isnull(a.[GBH803_Run_Signal],0)=isnull(b.[GBH803_Run_Signal],0)
and isnull(a.[MT80102_Room_Humidity_GBK801],0)=isnull(b.[MT80102_Room_Humidity_GBK801],0)
and isnull(a.[MT80101_Room_Humidity_GBH801],0)=isnull(b.[MT80101_Room_Humidity_GBH801],0)
and isnull(a.[TT80107_Room_Temperature_GBG801],0)=isnull(b.[TT80107_Room_Temperature_GBG801],0)
and isnull(a.[GBK802_Run_Signal],0)=isnull(b.[GBK802_Run_Signal],0)
and isnull(a.[GBG801_Run_Signal],0)=isnull(b.[GBG801_Run_Signal],0)
and isnull(a.[GBE801_Run_Signal],0)=isnull(b.[GBE801_Run_Signal],0)
and isnull(a.[GBH801_Run_Signal],0)=isnull(b.[GBH801_Run_Signal],0)
and isnull(a.[GBA806A_Run_Signal],0)=isnull(b.[GBA806A_Run_Signal],0)
and isnull(a.[TT80113_Room_Temp_Mv_GBH801],0)=isnull(b.[TT80113_Room_Temp_Mv_GBH801],0)
and isnull(a.[GBK801_Run_Signal],0)=isnull(b.[GBK801_Run_Signal],0)
and isnull(a.[TT80107_Room_Temp_Mv_GBG801],0)=isnull(b.[TT80107_Room_Temp_Mv_GBG801],0)
and isnull(a.[MT80101_Room_RH_Mv_GBH801],0)=isnull(b.[MT80101_Room_RH_Mv_GBH801],0)
and isnull(a.[TT80105_Room_Temp_Mv_GBE801],0)=isnull(b.[TT80105_Room_Temp_Mv_GBE801],0)
and isnull(a.[GBT803_Run_Signal],0)=isnull(b.[GBT803_Run_Signal],0)
and isnull(a.[TT80115_Room_Temp_V_GBK],0)=isnull(b.[TT80115_Room_Temp_V_GBK],0)
and isnull(a.[MT80102_RoomRh_V_GHK801],0)=isnull(b.[MT80102_RoomRh_V_GHK801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[GBJ803_Run_Signal]=b.[GBJ803_Run_Signal]
, a.[GBX803_Run_Signal]=b.[GBX803_Run_Signal]
, a.[TT80105_Room_Temperature_GBE801]=b.[TT80105_Room_Temperature_GBE801]
, a.[TT80113_Room_Temperature_GBH801]=b.[TT80113_Room_Temperature_GBH801]
, a.[TT80115_Room_Temperature_GBK801]=b.[TT80115_Room_Temperature_GBK801]
, a.[GBH803_Run_Signal]=b.[GBH803_Run_Signal]
, a.[MT80102_Room_Humidity_GBK801]=b.[MT80102_Room_Humidity_GBK801]
, a.[MT80101_Room_Humidity_GBH801]=b.[MT80101_Room_Humidity_GBH801]
, a.[TT80107_Room_Temperature_GBG801]=b.[TT80107_Room_Temperature_GBG801]
, a.[GBK802_Run_Signal]=b.[GBK802_Run_Signal]
, a.[GBG801_Run_Signal]=b.[GBG801_Run_Signal]
, a.[GBE801_Run_Signal]=b.[GBE801_Run_Signal]
, a.[GBH801_Run_Signal]=b.[GBH801_Run_Signal]
, a.[GBA806A_Run_Signal]=b.[GBA806A_Run_Signal]
, a.[TT80113_Room_Temp_Mv_GBH801]=b.[TT80113_Room_Temp_Mv_GBH801]
, a.[GBK801_Run_Signal]=b.[GBK801_Run_Signal]
, a.[TT80107_Room_Temp_Mv_GBG801]=b.[TT80107_Room_Temp_Mv_GBG801]
, a.[MT80101_Room_RH_Mv_GBH801]=b.[MT80101_Room_RH_Mv_GBH801]
, a.[TT80105_Room_Temp_Mv_GBE801]=b.[TT80105_Room_Temp_Mv_GBE801]
, a.[GBT803_Run_Signal]=b.[GBT803_Run_Signal]
, a.[TT80115_Room_Temp_V_GBK]=b.[TT80115_Room_Temp_V_GBK]
, a.[MT80102_RoomRh_V_GHK801]=b.[MT80102_RoomRh_V_GHK801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBJ803_Run_Signal]
      ,[GBX803_Run_Signal]
      ,[TT80105_Room_Temperature_GBE801]
      ,[TT80113_Room_Temperature_GBH801]
      ,[TT80115_Room_Temperature_GBK801]
      ,[GBH803_Run_Signal]
      ,[MT80102_Room_Humidity_GBK801]
      ,[MT80101_Room_Humidity_GBH801]
      ,[TT80107_Room_Temperature_GBG801]
      ,[GBK802_Run_Signal]
      ,[GBG801_Run_Signal]
      ,[GBE801_Run_Signal]
      ,[GBH801_Run_Signal]
      ,[GBA806A_Run_Signal]
      ,[TT80113_Room_Temp_Mv_GBH801]
      ,[GBK801_Run_Signal]
      ,[TT80107_Room_Temp_Mv_GBG801]
      ,[MT80101_Room_RH_Mv_GBH801]
      ,[TT80105_Room_Temp_Mv_GBE801]
      ,[GBT803_Run_Signal]
      ,[TT80115_Room_Temp_V_GBK]
      ,[MT80102_RoomRh_V_GHK801]
) 
VALUES (b.[ReadingTime]
      ,b.[GBJ803_Run_Signal]
      ,b.[GBX803_Run_Signal]
      ,b.[TT80105_Room_Temperature_GBE801]
      ,b.[TT80113_Room_Temperature_GBH801]
      ,b.[TT80115_Room_Temperature_GBK801]
      ,b.[GBH803_Run_Signal]
      ,b.[MT80102_Room_Humidity_GBK801]
      ,b.[MT80101_Room_Humidity_GBH801]
      ,b.[TT80107_Room_Temperature_GBG801]
      ,b.[GBK802_Run_Signal]
      ,b.[GBG801_Run_Signal]
      ,b.[GBE801_Run_Signal]
      ,b.[GBH801_Run_Signal]
      ,b.[GBA806A_Run_Signal]
      ,b.[TT80113_Room_Temp_Mv_GBH801]
      ,b.[GBK801_Run_Signal]
      ,b.[TT80107_Room_Temp_Mv_GBG801]
      ,b.[MT80101_Room_RH_Mv_GBH801]
      ,b.[TT80105_Room_Temp_Mv_GBE801]
      ,b.[GBT803_Run_Signal]
      ,b.[TT80115_Room_Temp_V_GBK]
      ,b.[MT80102_RoomRh_V_GHK801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC  'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC]',  @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBV803_Run_Signal_i],0)=isnull(b.[GBV803_Run_Signal_i],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
      ,a.[GBV803_Run_Signal_i]=b.[GBV803_Run_Signal_i]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBV803_Run_Signal_i]
) 
VALUES (b.[ReadingTime]
      ,b.[GBV803_Run_Signal_i]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TV80108_Heating_Valve_Actuator_GBL801],0)=isnull(b.[TV80108_Heating_Valve_Actuator_GBL801],0)
and isnull(a.[TT80108A_S_Air_Mv_GBL801],0)=isnull(b.[TT80108A_S_Air_Mv_GBL801],0)
and isnull(a.[TS_80108_Frost_Stat_GBL801],0)=isnull(b.[TS_80108_Frost_Stat_GBL801],0)
and isnull(a.[HV80108_Frost_Valve_Actuator_GBL801],0)=isnull(b.[HV80108_Frost_Valve_Actuator_GBL801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[TS_80108_Frost_Stat_GBL801]=b.[TS_80108_Frost_Stat_GBL801]
, a.[HV80108_Frost_Valve_Actuator_GBL801]=b.[HV80108_Frost_Valve_Actuator_GBL801]
, a.[TV80108_Heating_Valve_Actuator_GBL801]=b.[TV80108_Heating_Valve_Actuator_GBL801]
, a.[TT80108A_S_Air_Mv_GBL801]=b.[TT80108A_S_Air_Mv_GBL801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TS_80108_Frost_Stat_GBL801]
      ,[HV80108_Frost_Valve_Actuator_GBL801]
      ,[TV80108_Heating_Valve_Actuator_GBL801]
      ,[TT80108A_S_Air_Mv_GBL801]
) 
VALUES (b.[ReadingTime]
      ,b.[TS_80108_Frost_Stat_GBL801]
      ,b.[HV80108_Frost_Valve_Actuator_GBL801]
      ,b.[TV80108_Heating_Valve_Actuator_GBL801]
      ,b.[TT80108A_S_Air_Mv_GBL801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TT80109A_S_Air_Mv_GBM801],0)=isnull(b.[TT80109A_S_Air_Mv_GBM801],0)
and isnull(a.[HV80109_Frost_Valve_Actuator_GBM801],0)=isnull(b.[HV80109_Frost_Valve_Actuator_GBM801],0)
and isnull(a.[TT80109A_S_Air_Mv_GBM801],0)=isnull(b.[TT80109A_S_Air_Mv_GBM801],0)
and isnull(a.[outside_frost_graphic_display],0)=isnull(b.[outside_frost_graphic_display],0)
and isnull(a.[TS_80109_Frost_Stat_GBM801],0)=isnull(b.[TS_80109_Frost_Stat_GBM801],0)
and isnull(a.[TV80109_Heating_Valve_Actuator_GBM801],0)=isnull(b.[TV80109_Heating_Valve_Actuator_GBM801],0)
and isnull(a.[S_Air_Setpoint_GBM801],0)=isnull(b.[S_Air_Setpoint_GBM801],0)
and isnull(a.[Room_Setpoint_GBM801],0)=isnull(b.[Room_Setpoint_GBM801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[HV80109_Frost_Valve_Actuator_GBM801]=b.[HV80109_Frost_Valve_Actuator_GBM801]
, a.[TT80109A_S_Air_Mv_GBM801]=b.[TT80109A_S_Air_Mv_GBM801]
, a.[outside_frost_graphic_display]=b.[outside_frost_graphic_display]
, a.[TS_80109_Frost_Stat_GBM801]=b.[TS_80109_Frost_Stat_GBM801]
, a.[TV80109_Heating_Valve_Actuator_GBM801]=b.[TV80109_Heating_Valve_Actuator_GBM801]
, a.[S_Air_Setpoint_GBM801]=b.[S_Air_Setpoint_GBM801]
, a.[Room_Setpoint_GBM801]=b.[Room_Setpoint_GBM801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[HV80109_Frost_Valve_Actuator_GBM801]
      ,[TT80109A_S_Air_Mv_GBM801]
      ,[outside_frost_graphic_display]
      ,[TS_80109_Frost_Stat_GBM801]
      ,[TV80109_Heating_Valve_Actuator_GBM801]
      ,[S_Air_Setpoint_GBM801]
      ,[Room_Setpoint_GBM801]
) 
VALUES (b.[ReadingTime]
      ,b.[HV80109_Frost_Valve_Actuator_GBM801]
      ,b.[TT80109A_S_Air_Mv_GBM801]
      ,b.[outside_frost_graphic_display]
      ,b.[TS_80109_Frost_Stat_GBM801]
      ,b.[TV80109_Heating_Valve_Actuator_GBM801]
      ,b.[S_Air_Setpoint_GBM801]
      ,b.[Room_Setpoint_GBM801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY


IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''


/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBJ801_Start_Command],0)=isnull(b.[GBJ801_Start_Command],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
      ,a.[GBJ801_Start_Command]=b.[GBJ801_Start_Command]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBJ801_Start_Command]
) 
VALUES (b.[ReadingTime]
      ,b.[GBJ801_Start_Command]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TT80116A_S_Air_Mv_GBQ801],0)=isnull(b.[TT80116A_S_Air_Mv_GBQ801],0)
and isnull(a.[TS_80115_Frost_Stat_GBQ801],0)=isnull(b.[TS_80115_Frost_Stat_GBQ801],0)
and isnull(a.[HV80110_Frost_Valve_Actuator_GBQ801],0)=isnull(b.[HV80110_Frost_Valve_Actuator_GBQ801],0)
and isnull(a.[outside_Frost_Display_for_Graphic],0)=isnull(b.[outside_Frost_Display_for_Graphic],0)
and isnull(a.[TV80116_Heating_Vavle_Actuator_GBQ801],0)=isnull(b.[TV80116_Heating_Vavle_Actuator_GBQ801],0)
and isnull(a.[Room_Setpoint_GBQ801],0)=isnull(b.[Room_Setpoint_GBQ801],0)
and isnull(a.[S_Air_Setpoint_GBQ801],0)=isnull(b.[S_Air_Setpoint_GBQ801],0)
)
WHEN MATCHED THEN 
UPDATE SET a.[ReadingTime]=b.[ReadingTime]
, a.[TT80116A_S_Air_Mv_GBQ801]=b.[TT80116A_S_Air_Mv_GBQ801]
, a.[TS_80115_Frost_Stat_GBQ801]=b.[TS_80115_Frost_Stat_GBQ801]
, a.[HV80110_Frost_Valve_Actuator_GBQ801]=b.[HV80110_Frost_Valve_Actuator_GBQ801]
, a.[outside_Frost_Display_for_Graphic]=b.[outside_Frost_Display_for_Graphic]
, a.[TV80116_Heating_Vavle_Actuator_GBQ801]=b.[TV80116_Heating_Vavle_Actuator_GBQ801]
, a.[Room_Setpoint_GBQ801]=b.[Room_Setpoint_GBQ801]
, a.[S_Air_Setpoint_GBQ801]=b.[S_Air_Setpoint_GBQ801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TT80116A_S_Air_Mv_GBQ801]
      ,[TS_80115_Frost_Stat_GBQ801]
      ,[HV80110_Frost_Valve_Actuator_GBQ801]
      ,[outside_Frost_Display_for_Graphic]
      ,[TV80116_Heating_Vavle_Actuator_GBQ801]
      ,[Room_Setpoint_GBQ801]
      ,[S_Air_Setpoint_GBQ801]
) 
VALUES (b.[ReadingTime]
      ,b.[TT80116A_S_Air_Mv_GBQ801]
      ,b.[TS_80115_Frost_Stat_GBQ801]
      ,b.[HV80110_Frost_Valve_Actuator_GBQ801]
      ,b.[outside_Frost_Display_for_Graphic]
      ,b.[TV80116_Heating_Vavle_Actuator_GBQ801]
      ,b.[Room_Setpoint_GBQ801]
      ,b.[S_Air_Setpoint_GBQ801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote
SELECT distinct *
INTO ##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBJ_output_to_recirc_damper],0)=isnull(b.[GBJ_output_to_recirc_damper],0)
and isnull(a.[XV80111Dampers_GBJ801],0)=isnull(b.[XV80111Dampers_GBJ801],0)
and isnull(a.[TS_80111_Frost_Stat_GBJ801],0)=isnull(b.[TS_80111_Frost_Stat_GBJ801],0)
and isnull(a.[TV80111_Heating_Valve_GBJ801],0)=isnull(b.[TV80111_Heating_Valve_GBJ801],0)
and isnull(a.[Room_Setpoint_GBJ801_Graphic_],0)=isnull(b.[Room_Setpoint_GBJ801_Graphic_],0)
and isnull(a.[TT80114A_S_Air_Mv_GBJ801],0)=isnull(b.[TT80114A_S_Air_Mv_GBJ801],0)
and isnull(a.[TV80114_Cooling_Valve_GBJ801],0)=isnull(b.[TV80114_Cooling_Valve_GBJ801],0)
and isnull(a.[Room_Setpoint_GBJ801],0)=isnull(b.[Room_Setpoint_GBJ801],0)
and isnull(a.[S_Air_Setpoint_GBJ801],0)=isnull(b.[S_Air_Setpoint_GBJ801],0)
)
WHEN MATCHED THEN 
UPDATE SET
 a.[XV80111Dampers_GBJ801]=b.[XV80111Dampers_GBJ801]
, a.[TS_80111_Frost_Stat_GBJ801]=b.[TS_80111_Frost_Stat_GBJ801]
, a.[TV80111_Heating_Valve_GBJ801]=b.[TV80111_Heating_Valve_GBJ801]
, a.[Room_Setpoint_GBJ801_Graphic_]=b.[Room_Setpoint_GBJ801_Graphic_]
, a.[TT80114A_S_Air_Mv_GBJ801]=b.[TT80114A_S_Air_Mv_GBJ801]
, a.[TV80114_Cooling_Valve_GBJ801]=b.[TV80114_Cooling_Valve_GBJ801]
, a.[Room_Setpoint_GBJ801]=b.[Room_Setpoint_GBJ801]
, a.[S_Air_Setpoint_GBJ801]=b.[S_Air_Setpoint_GBJ801]

WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[XV80111Dampers_GBJ801]
      ,[TS_80111_Frost_Stat_GBJ801]
      ,[TV80111_Heating_Valve_GBJ801]
      ,[Room_Setpoint_GBJ801_Graphic_]
      ,[TT80114A_S_Air_Mv_GBJ801]
      ,[TV80114_Cooling_Valve_GBJ801]
      ,[GBJ_output_to_recirc_damper]
      ,[Room_Setpoint_GBJ801]
      ,[S_Air_Setpoint_GBJ801]
) 
VALUES (b.[ReadingTime]
      ,b.[XV80111Dampers_GBJ801]
      ,b.[TS_80111_Frost_Stat_GBJ801]
      ,b.[TV80111_Heating_Valve_GBJ801]
      ,b.[Room_Setpoint_GBJ801_Graphic_]
      ,b.[TT80114A_S_Air_Mv_GBJ801]
      ,b.[TV80114_Cooling_Valve_GBJ801]
      ,b.[GBJ_output_to_recirc_damper]
      ,b.[Room_Setpoint_GBJ801]
      ,b.[S_Air_Setpoint_GBJ801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp]',@mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp
SELECT distinct *
INTO ##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TT80108_Room_Temperature_GBL801],0)=isnull(b.[TT80108_Room_Temperature_GBL801],0)
and isnull(a.[GBQ801_Run_Signal],0)=isnull(b.[GBQ801_Run_Signal],0)
and isnull(a.[TT80116_Room_Temperature_GBQ801],0)=isnull(b.[TT80116_Room_Temperature_GBQ801],0)
and isnull(a.[GBM801A_Run_Signal],0)=isnull(b.[GBM801A_Run_Signal],0)
and isnull(a.[GBJ801_Run_Signal],0)=isnull(b.[GBJ801_Run_Signal],0)
and isnull(a.[TT80109_Room_Tempertature_GBM801],0)=isnull(b.[TT80109_Room_Tempertature_GBM801],0)
and isnull(a.[GBL801A_Run_Signal],0)=isnull(b.[GBL801A_Run_Signal],0)
and isnull(a.[TT80114_Room_Temperature_GBJ801],0)=isnull(b.[TT80114_Room_Temperature_GBJ801],0)
)
WHEN MATCHED THEN 
UPDATE SET
 a.[ReadingTime]=b.[ReadingTime]
      ,a.[TT80108_Room_Temperature_GBL801]=b.[TT80108_Room_Temperature_GBL801]
      ,a.[GBQ801_Run_Signal]=b.[GBQ801_Run_Signal]
      ,a.[TT80116_Room_Temperature_GBQ801]=b.[TT80116_Room_Temperature_GBQ801]
      ,a.[GBM801A_Run_Signal]=b.[GBM801A_Run_Signal]
      ,a.[GBJ801_Run_Signal]=b.[GBJ801_Run_Signal]
      ,a.[TT80109_Room_Tempertature_GBM801]=b.[TT80109_Room_Tempertature_GBM801]
      ,a.[GBL801A_Run_Signal]=b.[GBL801A_Run_Signal]
      ,a.[TT80114_Room_Temperature_GBJ801]=b.[TT80114_Room_Temperature_GBJ801]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TT80108_Room_Temperature_GBL801]
      ,[GBQ801_Run_Signal]
      ,[TT80116_Room_Temperature_GBQ801]
      ,[GBM801A_Run_Signal]
      ,[GBJ801_Run_Signal]
      ,[TT80109_Room_Tempertature_GBM801]
      ,[GBL801A_Run_Signal]
      ,[TT80114_Room_Temperature_GBJ801]
) 
VALUES (b.[ReadingTime]
      ,b.[TT80108_Room_Temperature_GBL801]
      ,b.[GBQ801_Run_Signal]
      ,b.[TT80116_Room_Temperature_GBQ801]
      ,b.[GBM801A_Run_Signal]
      ,b.[GBJ801_Run_Signal]
      ,b.[TT80109_Room_Tempertature_GBM801]
      ,b.[GBL801A_Run_Signal]
      ,b.[TT80114_Room_Temperature_GBJ801]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure'') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure
SELECT distinct * INTO ##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure') drop table ##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure
SELECT distinct *
INTO ##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure] a 
USING ##MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBV803_Run_Signal],0)=isnull(b.[GBV803_Run_Signal],0)
)
WHEN MATCHED THEN 
UPDATE SET
 a.[ReadingTime]=b.[ReadingTime]
      ,a.[GBV803_Run_Signal]=b.[GBV803_Run_Signal]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBV803_Run_Signal]
) 
VALUES (b.[ReadingTime]
      ,b.[GBV803_Run_Signal]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data [MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans'') drop table ##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans
SELECT distinct * INTO ##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans') drop table ##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans] a 
USING ##MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GB_809],0)=isnull(b.[GB_809],0)
)
WHEN MATCHED THEN 
UPDATE SET
 a.[ReadingTime]=b.[ReadingTime]
      ,a.[GB_809]=b.[GB_809]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GB_809]
) 
VALUES (b.[ReadingTime]
      ,b.[GB_809]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_1F801_MCC]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_1F801_MCC 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_1F801_MCC]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_4GBF_GB839_1F801_MCC]',@mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_4GBF_GB839_1F801_MCC'') drop table ##MTrend__n1_osp3_4GBF_GB839_1F801_MCC
SELECT distinct * INTO ##MTrend__n1_osp3_4GBF_GB839_1F801_MCC FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_4GBF_GB839_1F801_MCC'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_1F801_MCC') drop table ##MTrend__n1_osp3_4GBF_GB839_1F801_MCC
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_1F801_MCC 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_1F801_MCC')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_1F801_MCC] a 
USING ##MTrend__n1_osp3_4GBF_GB839_1F801_MCC b
ON (a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TT80106_Room_Temperature_GBF801],0)=isnull(b.[TT80106_Room_Temperature_GBF801],0)
and isnull(a.[TT80106a_Supply_Air_Temperature_GBF801],0)=isnull(b.[TT80106a_Supply_Air_Temperature_GBF801],0)
and isnull(a.[TV80106_Heating_Valve_GBF801],0)=isnull(b.[TV80106_Heating_Valve_GBF801],0)
and isnull(a.[GB839_Run_Signal_i],0)=isnull(b.[GB839_Run_Signal_i],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[TT80106_Room_Temperature_GBF801]=b.[TT80106_Room_Temperature_GBF801]
      ,a.[TT80106a_Supply_Air_Temperature_GBF801]=b.[TT80106a_Supply_Air_Temperature_GBF801]
      ,a.[TV80106_Heating_Valve_GBF801]=b.[TV80106_Heating_Valve_GBF801]
      ,a.[GB839_Run_Signal_i]=b.[GB839_Run_Signal_i]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TT80106_Room_Temperature_GBF801]
      ,[TT80106a_Supply_Air_Temperature_GBF801]
      ,[TV80106_Heating_Valve_GBF801]
      ,[GB839_Run_Signal_i]
) 
VALUES (b.[ReadingTime]
      ,b.[TT80106_Room_Temperature_GBF801]
      ,b.[TT80106a_Supply_Air_Temperature_GBF801]
      ,b.[TV80106_Heating_Valve_GBF801]
      ,b.[GB839_Run_Signal_i]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_2B839_MCC]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_2B839_MCC 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_2B839_MCC]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_4GBF_GB839_2B839_MCC]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_4GBF_GB839_2B839_MCC'') drop table ##MTrend__n1_osp3_4GBF_GB839_2B839_MCC
SELECT distinct * INTO ##MTrend__n1_osp3_4GBF_GB839_2B839_MCC FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_4GBF_GB839_2B839_MCC'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_2B839_MCC') drop table ##MTrend__n1_osp3_4GBF_GB839_2B839_MCC
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_2B839_MCC 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_2B839_MCC')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_2B839_MCC] a 
USING ##MTrend__n1_osp3_4GBF_GB839_2B839_MCC b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[LTHW_Valve],0)=isnull(b.[LTHW_Valve],0)
and isnull(a.[Max_Valve_Position],0)=isnull(b.[Max_Valve_Position],0)
and isnull(a.[TT80205_Room_Temperature],0)=isnull(b.[TT80205_Room_Temperature],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[LTHW_Valve]=b.[LTHW_Valve]
      ,a.[Max_Valve_Position]=b.[Max_Valve_Position]
      ,a.[TT80205_Room_Temperature]=b.[TT80205_Room_Temperature]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[LTHW_Valve]
      ,[Max_Valve_Position]
      ,[TT80205_Room_Temperature]
) 
VALUES (b.[ReadingTime]
      ,b.[LTHW_Valve]
      ,b.[Max_Valve_Position]
      ,b.[TT80205_Room_Temperature]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control'') drop table ##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control
SELECT distinct * INTO ##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control') drop table ##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control] a 
USING ##MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TT83901A_S_Air_Mv_GB839],0)=isnull(b.[TT83901A_S_Air_Mv_GB839],0)
and isnull(a.[TT83901B_Room_Temperature_GB839],0)=isnull(b.[TT83901B_Room_Temperature_GB839],0)
and isnull(a.[TT83901A_Room_Temperature_GB839],0)=isnull(b.[TT83901A_Room_Temperature_GB839],0)
and isnull(a.[TV83901_Heating_Valve_Actuator_GB839],0)=isnull(b.[TV83901_Heating_Valve_Actuator_GB839],0)
and isnull(a.[HV83901_Frost_Valve_Actuator_GB839],0)=isnull(b.[HV83901_Frost_Valve_Actuator_GB839],0)
and isnull(a.[Room_Setpoint_GB839],0)=isnull(b.[Room_Setpoint_GB839],0)
and isnull(a.[S_Air_Setpoint_GB839],0)=isnull(b.[S_Air_Setpoint_GB839],0)
and isnull(a.[GB839_Run_Signal],0)=isnull(b.[GB839_Run_Signal],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[TT83901A_S_Air_Mv_GB839]=b.[TT83901A_S_Air_Mv_GB839]
      ,a.[TT83901B_Room_Temperature_GB839]=b.[TT83901B_Room_Temperature_GB839]
      ,a.[TT83901A_Room_Temperature_GB839]=b.[TT83901A_Room_Temperature_GB839]
      ,a.[TV83901_Heating_Valve_Actuator_GB839]=b.[TV83901_Heating_Valve_Actuator_GB839]
      ,a.[HV83901_Frost_Valve_Actuator_GB839]=b.[HV83901_Frost_Valve_Actuator_GB839]
      ,a.[Room_Setpoint_GB839]=b.[Room_Setpoint_GB839]
      ,a.[S_Air_Setpoint_GB839]=b.[S_Air_Setpoint_GB839]
      ,a.[GB839_Run_Signal]=b.[GB839_Run_Signal]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TT83901A_S_Air_Mv_GB839]
      ,[TT83901B_Room_Temperature_GB839]
      ,[TT83901A_Room_Temperature_GB839]
      ,[TV83901_Heating_Valve_Actuator_GB839]
      ,[HV83901_Frost_Valve_Actuator_GB839]
      ,[Room_Setpoint_GB839]
      ,[S_Air_Setpoint_GB839]
      ,[GB839_Run_Signal]
) 
VALUES (b.[ReadingTime]
      ,b.[TT83901A_S_Air_Mv_GB839]
      ,b.[TT83901B_Room_Temperature_GB839]
      ,b.[TT83901A_Room_Temperature_GB839]
      ,b.[TV83901_Heating_Valve_Actuator_GB839]
      ,b.[HV83901_Frost_Valve_Actuator_GB839]
      ,b.[Room_Setpoint_GB839]
      ,b.[S_Air_Setpoint_GB839]
      ,b.[GB839_Run_Signal]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_5C_D_G802]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_5C_D_G802 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_5C_D_G802]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_4GBF_GB839_5C_D_G802]', @mysql_schema,@db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_4GBF_GB839_5C_D_G802'') drop table ##MTrend__n1_osp3_4GBF_GB839_5C_D_G802
SELECT distinct * INTO ##MTrend__n1_osp3_4GBF_GB839_5C_D_G802 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_4GBF_GB839_5C_D_G802'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_5C_D_G802') drop table ##MTrend__n1_osp3_4GBF_GB839_5C_D_G802
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_5C_D_G802 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_5C_D_G802')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_5C_D_G802] a 
USING ##MTrend__n1_osp3_4GBF_GB839_5C_D_G802 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[TT80202_Room_Temperature],0)=isnull(b.[TT80202_Room_Temperature],0)
and isnull(a.[LTHW_Temp_Mv],0)=isnull(b.[LTHW_Temp_Mv],0)
and isnull(a.[LTHW_Supply_Mv],0)=isnull(b.[LTHW_Supply_Mv],0)
and isnull(a.[TT80207_Room_Temperature],0)=isnull(b.[TT80207_Room_Temperature],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[TT80202_Room_Temperature]=b.[TT80202_Room_Temperature]
      ,a.[LTHW_Temp_Mv]=b.[LTHW_Temp_Mv]
      ,a.[LTHW_Supply_Mv]=b.[LTHW_Supply_Mv]
      ,a.[TT80207_Room_Temperature]=b.[TT80207_Room_Temperature]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[TT80202_Room_Temperature]
      ,[LTHW_Temp_Mv]
      ,[LTHW_Supply_Mv]
      ,[TT80207_Room_Temperature]
) 
VALUES (b.[ReadingTime]
      ,b.[TT80202_Room_Temperature]
      ,b.[LTHW_Temp_Mv]
      ,b.[LTHW_Supply_Mv]
      ,b.[TT80207_Room_Temperature]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_6Chiller]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_6Chiller 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_6Chiller]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_4GBF_GB839_6Chiller]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_4GBF_GB839_6Chiller'') drop table ##MTrend__n1_osp3_4GBF_GB839_6Chiller
SELECT distinct * INTO ##MTrend__n1_osp3_4GBF_GB839_6Chiller FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_4GBF_GB839_6Chiller'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_6Chiller') drop table ##MTrend__n1_osp3_4GBF_GB839_6Chiller
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_6Chiller 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_6Chiller')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_6Chiller] a 
USING ##MTrend__n1_osp3_4GBF_GB839_6Chiller b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[Chiller_GB835_Start],0)=isnull(b.[Chiller_GB835_Start],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[Chiller_GB835_Start]=b.[Chiller_GB835_Start]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[Chiller_GB835_Start]
) 
VALUES (b.[ReadingTime]
      ,b.[Chiller_GB835_Start]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System]', @mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System'') drop table ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System
SELECT distinct * INTO ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System') drop table ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System
SELECT distinct *
INTO ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System] a 
USING ##MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[MCCExtract_Fan_GB_809_enable],0)=isnull(b.[MCCExtract_Fan_GB_809_enable],0)
and isnull(a.[MCC_Room_Temperature],0)=isnull(b.[MCC_Room_Temperature],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[MCCExtract_Fan_GB_809_enable]=b.[MCCExtract_Fan_GB_809_enable]
      ,a.[MCC_Room_Temperature]=b.[MCC_Room_Temperature]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[MCCExtract_Fan_GB_809_enable]
      ,[MCC_Room_Temperature]
) 
VALUES (b.[ReadingTime]
      ,b.[MCCExtract_Fan_GB_809_enable]
      ,b.[MCC_Room_Temperature]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_007_UC3224]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_007_UC3224 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_007_UC3224]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_007_UC3224]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_007_UC3224'') drop table ##MTrend__n1_osp3_5Annex_007_UC3224
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_007_UC3224 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_007_UC3224'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_007_UC3224') drop table ##MTrend__n1_osp3_5Annex_007_UC3224
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_007_UC3224 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_007_UC3224')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_007_UC3224] a 
USING ##MTrend__n1_osp3_5Annex_007_UC3224 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[Drum_Warmer_Room_Temp_TT_72905],0)=isnull(b.[Drum_Warmer_Room_Temp_TT_72905],0)
and isnull(a.[AHU_Sup_Fan_Speed_SC_72901],0)=isnull(b.[AHU_Sup_Fan_Speed_SC_72901],0)
and isnull(a.[AHU_Inlet_Temp_TT_72901],0)=isnull(b.[AHU_Inlet_Temp_TT_72901],0)
and isnull(a.[AHU_Ext_Fan_Speed_SC_72902],0)=isnull(b.[AHU_Ext_Fan_Speed_SC_72902],0)
and isnull(a.[AHU_Supply_Temp_TT_72903],0)=isnull(b.[AHU_Supply_Temp_TT_72903],0)
and isnull(a.[GBY_806_Enabled],0)=isnull(b.[GBY_806_Enabled],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[Drum_Warmer_Room_Temp_TT_72905]=b.[Drum_Warmer_Room_Temp_TT_72905]
      ,a.[AHU_Sup_Fan_Speed_SC_72901]=b.[AHU_Sup_Fan_Speed_SC_72901]
      ,a.[AHU_Inlet_Temp_TT_72901]=b.[AHU_Inlet_Temp_TT_72901]
      ,a.[AHU_Ext_Fan_Speed_SC_72902]=b.[AHU_Ext_Fan_Speed_SC_72902]
      ,a.[AHU_Supply_Temp_TT_72903]=b.[AHU_Supply_Temp_TT_72903]
      ,a.[GBY_806_Enabled]=b.[GBY_806_Enabled]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[Drum_Warmer_Room_Temp_TT_72905]
      ,[AHU_Sup_Fan_Speed_SC_72901]
      ,[AHU_Inlet_Temp_TT_72901]
      ,[AHU_Ext_Fan_Speed_SC_72902]
      ,[AHU_Supply_Temp_TT_72903]
      ,[GBY_806_Enabled]
) 
VALUES (b.[ReadingTime]
      ,b.[Drum_Warmer_Room_Temp_TT_72905]
      ,b.[AHU_Sup_Fan_Speed_SC_72901]
      ,b.[AHU_Inlet_Temp_TT_72901]
      ,b.[AHU_Ext_Fan_Speed_SC_72902]
      ,b.[AHU_Supply_Temp_TT_72903]
      ,b.[GBY_806_Enabled]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_008_UC3216]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_008_UC3216 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_008_UC3216]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_008_UC3216]',@mysql_schema,  @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_008_UC3216'') drop table ##MTrend__n1_osp3_5Annex_008_UC3216
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_008_UC3216 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_008_UC3216'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_008_UC3216') drop table ##MTrend__n1_osp3_5Annex_008_UC3216
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_008_UC3216 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_008_UC3216')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_008_UC3216] a 
USING ##MTrend__n1_osp3_5Annex_008_UC3216 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[AHU_3_Port_Heating_Valve_TV_72904],0)=isnull(b.[AHU_3_Port_Heating_Valve_TV_72904],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[AHU_3_Port_Heating_Valve_TV_72904]=b.[AHU_3_Port_Heating_Valve_TV_72904]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[AHU_3_Port_Heating_Valve_TV_72904]
) 
VALUES (b.[ReadingTime]
      ,b.[AHU_3_Port_Heating_Valve_TV_72904]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_013_UC328]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_013_UC328 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_013_UC328]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_013_UC328]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_013_UC328'') drop table ##MTrend__n1_osp3_5Annex_013_UC328
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_013_UC328 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_013_UC328'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_013_UC328') drop table ##MTrend__n1_osp3_5Annex_013_UC328
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_013_UC328 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_013_UC328')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_013_UC328] a 
USING ##MTrend__n1_osp3_5Annex_013_UC328 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[ST_80305_GBY_803_Ext_Fan_Speed_Feedback],0)=isnull(b.[ST_80305_GBY_803_Ext_Fan_Speed_Feedback],0)
and isnull(a.[SC_80305_GBY_803_Ext_Fan_Speed_Control],0)=isnull(b.[SC_80305_GBY_803_Ext_Fan_Speed_Control],0)
and isnull(a.[HLR_80305_Ext_Fan_GBY_803_Run],0)=isnull(b.[HLR_80305_Ext_Fan_GBY_803_Run],0)
and isnull(a.[Ext_Fan_GBY_803_Motor_Ready],0)=isnull(b.[Ext_Fan_GBY_803_Motor_Ready],0)
and isnull(a.[GBY_803_Speed_SP],0)=isnull(b.[GBY_803_Speed_SP],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[ST_80305_GBY_803_Ext_Fan_Speed_Feedback]=b.[ST_80305_GBY_803_Ext_Fan_Speed_Feedback]
      ,a.[SC_80305_GBY_803_Ext_Fan_Speed_Control]=b.[SC_80305_GBY_803_Ext_Fan_Speed_Control]
      ,a.[HLR_80305_Ext_Fan_GBY_803_Run]=b.[HLR_80305_Ext_Fan_GBY_803_Run]
      ,a.[Ext_Fan_GBY_803_Motor_Ready]=b.[Ext_Fan_GBY_803_Motor_Ready]
      ,a.[GBY_803_Speed_SP]=b.[GBY_803_Speed_SP]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[ST_80305_GBY_803_Ext_Fan_Speed_Feedback]
      ,[SC_80305_GBY_803_Ext_Fan_Speed_Control]
      ,[HLR_80305_Ext_Fan_GBY_803_Run]
      ,[Ext_Fan_GBY_803_Motor_Ready]
      ,[GBY_803_Speed_SP]
) 
VALUES (b.[ReadingTime]
      ,b.[ST_80305_GBY_803_Ext_Fan_Speed_Feedback]
      ,b.[SC_80305_GBY_803_Ext_Fan_Speed_Control]
      ,b.[HLR_80305_Ext_Fan_GBY_803_Run]
      ,b.[Ext_Fan_GBY_803_Motor_Ready]
      ,b.[GBY_803_Speed_SP]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_0501]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_0501'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_0501]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_0501]',@mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_0501'') drop table ##MTrend__n1_osp3_5Annex_0501
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_0501 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_0501'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_0501') drop table ##MTrend__n1_osp3_5Annex_0501
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_0501 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0501')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_0501] a 
USING ##MTrend__n1_osp3_5Annex_0501 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[A81_ACTUAL_VOLUME_L_S],0)=isnull(b.[A81_ACTUAL_VOLUME_L_S],0)
and isnull(a.[A12_GBA_805_REHEAT_O_P],0)=isnull(b.[A12_GBA_805_REHEAT_O_P],0)
and isnull(a.[A38_Average_Extract_Temp],0)=isnull(b.[A38_Average_Extract_Temp],0)
and isnull(a.[D80_GBA_805_FROST_STAT_ACTIVATED],0)=isnull(b.[D80_GBA_805_FROST_STAT_ACTIVATED],0)
and isnull(a.[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP],0)=isnull(b.[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP],0)
and isnull(a.[A11_GBA_805_PREHEAT_O_P],0)=isnull(b.[A11_GBA_805_PREHEAT_O_P],0)
and isnull(a.[A51_R_S_GBA_805_S_A_T_],0)=isnull(b.[A51_R_S_GBA_805_S_A_T_],0)
and isnull(a.[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP],0)=isnull(b.[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP],0)
and isnull(a.[OFF_COIL_TEMP],0)=isnull(b.[OFF_COIL_TEMP],0)
and isnull(a.[A25_FROST_COIL_S_P],0)=isnull(b.[A25_FROST_COIL_S_P],0)
and isnull(a.[Supply_Temp_Min_Spt],0)=isnull(b.[Supply_Temp_Min_Spt],0)
and isnull(a.[Supply_Temp_Max_Spt],0)=isnull(b.[Supply_Temp_Max_Spt],0)
and isnull(a.[A28_AHU_CONTROL_S_P],0)=isnull(b.[A28_AHU_CONTROL_S_P],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[A81_ACTUAL_VOLUME_L_S]=b.[A81_ACTUAL_VOLUME_L_S]
      ,a.[A12_GBA_805_REHEAT_O_P]=b.[A12_GBA_805_REHEAT_O_P]
      ,a.[A38_Average_Extract_Temp]=b.[A38_Average_Extract_Temp]
      ,a.[D80_GBA_805_FROST_STAT_ACTIVATED]=b.[D80_GBA_805_FROST_STAT_ACTIVATED]
      ,a.[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP]=b.[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP]
      ,a.[A11_GBA_805_PREHEAT_O_P]=b.[A11_GBA_805_PREHEAT_O_P]
      ,a.[A51_R_S_GBA_805_S_A_T_]=b.[A51_R_S_GBA_805_S_A_T_]
      ,a.[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP]=b.[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP]
      ,a.[OFF_COIL_TEMP]=b.[OFF_COIL_TEMP]
      ,a.[A25_FROST_COIL_S_P]=b.[A25_FROST_COIL_S_P]
      ,a.[Supply_Temp_Min_Spt]=b.[Supply_Temp_Min_Spt]
      ,a.[Supply_Temp_Max_Spt]=b.[Supply_Temp_Max_Spt]
      ,a.[A28_AHU_CONTROL_S_P]=b.[A28_AHU_CONTROL_S_P]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[A81_ACTUAL_VOLUME_L_S]
      ,[A12_GBA_805_REHEAT_O_P]
      ,[A38_Average_Extract_Temp]
      ,[D80_GBA_805_FROST_STAT_ACTIVATED]
      ,[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP]
      ,[A11_GBA_805_PREHEAT_O_P]
      ,[A51_R_S_GBA_805_S_A_T_]
      ,[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP]
      ,[OFF_COIL_TEMP]
      ,[A25_FROST_COIL_S_P]
      ,[Supply_Temp_Min_Spt]
      ,[Supply_Temp_Max_Spt]
      ,[A28_AHU_CONTROL_S_P]
) 
VALUES (b.[ReadingTime]
      ,b.[A81_ACTUAL_VOLUME_L_S]
      ,b.[A12_GBA_805_REHEAT_O_P]
      ,b.[A38_Average_Extract_Temp]
      ,b.[D80_GBA_805_FROST_STAT_ACTIVATED]
      ,b.[A53_R_S_GBB_805_EXT_FAN_NON_CONT_TEMP]
      ,b.[A11_GBA_805_PREHEAT_O_P]
      ,b.[A51_R_S_GBA_805_S_A_T_]
      ,b.[A52_R_S_GBC_805_EXT_FAN_CONT_TEMP]
      ,b.[OFF_COIL_TEMP]
      ,b.[A25_FROST_COIL_S_P]
      ,b.[Supply_Temp_Min_Spt]
      ,b.[Supply_Temp_Max_Spt]
      ,b.[A28_AHU_CONTROL_S_P]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_0502]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_0502 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_0502]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_0502]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_0502'') drop table ##MTrend__n1_osp3_5Annex_0502
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_0502 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_0502'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_0502') drop table ##MTrend__n1_osp3_5Annex_0502
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_0502 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0502')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_0502] a 
USING ##MTrend__n1_osp3_5Annex_0502 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[A82_CAL_INVERTOR_HZ_],0)=isnull(b.[A82_CAL_INVERTOR_HZ_],0)
and isnull(a.[A16_GBC_805_EXTRACT_FAN_VSD_O_P],0)=isnull(b.[A16_GBC_805_EXTRACT_FAN_VSD_O_P],0)
and isnull(a.[A08_R351_353_NUSCHE_D_P],0)=isnull(b.[A08_R351_353_NUSCHE_D_P],0)
and isnull(a.[A15_GBA_805_VSD_O_P],0)=isnull(b.[A15_GBA_805_VSD_O_P],0)
and isnull(a.[A07_R356_SCHENK_FILTER_D_P],0)=isnull(b.[A07_R356_SCHENK_FILTER_D_P],0)
and isnull(a.[A05_R357_B_FILTER_D_P],0)=isnull(b.[A05_R357_B_FILTER_D_P],0)
and isnull(a.[A03_R552_CONT_IBC_D_P],0)=isnull(b.[A03_R552_CONT_IBC_D_P],0)
and isnull(a.[A01_R553_PERSONNEL_A_L_D_P],0)=isnull(b.[A01_R553_PERSONNEL_A_L_D_P],0)
and isnull(a.[A04_R551_GA_785_ROOM_D_P],0)=isnull(b.[A04_R551_GA_785_ROOM_D_P],0)
and isnull(a.[A06_R355_PERSONNEL_A_L_D_P],0)=isnull(b.[A06_R355_PERSONNEL_A_L_D_P],0)
and isnull(a.[A02_R544_MATERIALS_A_L_D_P],0)=isnull(b.[A02_R544_MATERIALS_A_L_D_P],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[A82_CAL_INVERTOR_HZ_]=b.[A82_CAL_INVERTOR_HZ_]
      ,a.[A16_GBC_805_EXTRACT_FAN_VSD_O_P]=b.[A16_GBC_805_EXTRACT_FAN_VSD_O_P]
      ,a.[A08_R351_353_NUSCHE_D_P]=b.[A08_R351_353_NUSCHE_D_P]
      ,a.[A15_GBA_805_VSD_O_P]=b.[A15_GBA_805_VSD_O_P]
      ,a.[A07_R356_SCHENK_FILTER_D_P]=b.[A07_R356_SCHENK_FILTER_D_P]
      ,a.[A05_R357_B_FILTER_D_P]=b.[A05_R357_B_FILTER_D_P]
      ,a.[A03_R552_CONT_IBC_D_P]=b.[A03_R552_CONT_IBC_D_P]
      ,a.[A01_R553_PERSONNEL_A_L_D_P]=b.[A01_R553_PERSONNEL_A_L_D_P]
      ,a.[A04_R551_GA_785_ROOM_D_P]=b.[A04_R551_GA_785_ROOM_D_P]
      ,a.[A06_R355_PERSONNEL_A_L_D_P]=b.[A06_R355_PERSONNEL_A_L_D_P]
      ,a.[A02_R544_MATERIALS_A_L_D_P]=b.[A02_R544_MATERIALS_A_L_D_P]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[A82_CAL_INVERTOR_HZ_]
      ,[A16_GBC_805_EXTRACT_FAN_VSD_O_P]
      ,[A08_R351_353_NUSCHE_D_P]
      ,[A15_GBA_805_VSD_O_P]
      ,[A07_R356_SCHENK_FILTER_D_P]
      ,[A05_R357_B_FILTER_D_P]
      ,[A03_R552_CONT_IBC_D_P]
      ,[A01_R553_PERSONNEL_A_L_D_P]
      ,[A04_R551_GA_785_ROOM_D_P]
      ,[A06_R355_PERSONNEL_A_L_D_P]
      ,[A02_R544_MATERIALS_A_L_D_P]
) 
VALUES (b.[ReadingTime]
      ,b.[A82_CAL_INVERTOR_HZ_]
      ,b.[A16_GBC_805_EXTRACT_FAN_VSD_O_P]
      ,b.[A08_R351_353_NUSCHE_D_P]
      ,b.[A15_GBA_805_VSD_O_P]
      ,b.[A07_R356_SCHENK_FILTER_D_P]
      ,b.[A05_R357_B_FILTER_D_P]
      ,b.[A03_R552_CONT_IBC_D_P]
      ,b.[A01_R553_PERSONNEL_A_L_D_P]
      ,b.[A04_R551_GA_785_ROOM_D_P]
      ,b.[A06_R355_PERSONNEL_A_L_D_P]
      ,b.[A02_R544_MATERIALS_A_L_D_P]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_0503]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_0503 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_0503] 
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
/*
declare @db_name varchar(100) = 'IOT_ETL_ENERGY_ECS'
declare @mysql_schema varchar(100) = 'iot_energy_ecs_rng'
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
*/
declare @strsql nvarchar(max)=''


---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_0503]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_0503'') drop table ##MTrend__n1_osp3_5Annex_0503
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_0503 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_0503'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_0503') drop table ##MTrend__n1_osp3_5Annex_0503
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_0503 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_0503')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_0503] a 
USING ##MTrend__n1_osp3_5Annex_0503 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[A04_R251_254_CONT_DRYER_D_P],0)=isnull(b.[A04_R251_254_CONT_DRYER_D_P],0)
and isnull(a.[A03_R253_PERSONNEL_A_L_D_P],0)=isnull(b.[A03_R253_PERSONNEL_A_L_D_P],0)
and isnull(a.[A08_R153_TANK_ROOM_D_P],0)=isnull(b.[A08_R153_TANK_ROOM_D_P],0)
and isnull(a.[A06_R154_PERSONNEL_A_L_D_P],0)=isnull(b.[A06_R154_PERSONNEL_A_L_D_P],0)
and isnull(a.[A02_R451_DC_725_AREA_D_P],0)=isnull(b.[A02_R451_DC_725_AREA_D_P],0)
and isnull(a.[A07_R152_CONT_PRODUCT_D_P],0)=isnull(b.[A07_R152_CONT_PRODUCT_D_P],0)
and isnull(a.[A41_R453_PERSONNEL_A_L_D_P],0)=isnull(b.[A41_R453_PERSONNEL_A_L_D_P],0)
and isnull(a.[A45_R155_PRODUCT_A_L_D_P],0)=isnull(b.[A45_R155_PRODUCT_A_L_D_P],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[A04_R251_254_CONT_DRYER_D_P]=b.[A04_R251_254_CONT_DRYER_D_P]
      ,a.[A03_R253_PERSONNEL_A_L_D_P]=b.[A03_R253_PERSONNEL_A_L_D_P]
      ,a.[A08_R153_TANK_ROOM_D_P]=b.[A08_R153_TANK_ROOM_D_P]
      ,a.[A06_R154_PERSONNEL_A_L_D_P]=b.[A06_R154_PERSONNEL_A_L_D_P]
      ,a.[A02_R451_DC_725_AREA_D_P]=b.[A02_R451_DC_725_AREA_D_P]
      ,a.[A07_R152_CONT_PRODUCT_D_P]=b.[A07_R152_CONT_PRODUCT_D_P]
      ,a.[A41_R453_PERSONNEL_A_L_D_P]=b.[A41_R453_PERSONNEL_A_L_D_P]
      ,a.[A45_R155_PRODUCT_A_L_D_P]=b.[A45_R155_PRODUCT_A_L_D_P]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[A04_R251_254_CONT_DRYER_D_P]
      ,[A03_R253_PERSONNEL_A_L_D_P]
      ,[A08_R153_TANK_ROOM_D_P]
      ,[A06_R154_PERSONNEL_A_L_D_P]
      ,[A02_R451_DC_725_AREA_D_P]
      ,[A07_R152_CONT_PRODUCT_D_P]
      ,[A41_R453_PERSONNEL_A_L_D_P]
      ,[A45_R155_PRODUCT_A_L_D_P]
) 
VALUES (b.[ReadingTime]
      ,b.[A04_R251_254_CONT_DRYER_D_P]
      ,b.[A03_R253_PERSONNEL_A_L_D_P]
      ,b.[A08_R153_TANK_ROOM_D_P]
      ,b.[A06_R154_PERSONNEL_A_L_D_P]
      ,b.[A02_R451_DC_725_AREA_D_P]
      ,b.[A07_R152_CONT_PRODUCT_D_P]
      ,b.[A41_R453_PERSONNEL_A_L_D_P]
      ,b.[A45_R155_PRODUCT_A_L_D_P]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_4Extract]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_4Extract 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_4Extract]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_4Extract]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)


set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_4Extract'') drop table ##MTrend__n1_osp3_5Annex_4Extract
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_4Extract FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_4Extract'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_4Extract') drop table ##MTrend__n1_osp3_5Annex_4Extract
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_4Extract 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_4Extract')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_4Extract] a 
USING ##MTrend__n1_osp3_5Annex_4Extract b
ON (a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[Rm_Press_No_2],0)=isnull(b.[Rm_Press_No_2],0)
and isnull(a.[Rm_Press_No_1],0)=isnull(b.[Rm_Press_No_1],0)
and isnull(a.[VSD_No_1_Speed_Control_],0)=isnull(b.[VSD_No_1_Speed_Control_],0)
and isnull(a.[VSD_Speed_Control_Output],0)=isnull(b.[VSD_Speed_Control_Output],0)
and isnull(a.[Actual_Duct_Press_No_2],0)=isnull(b.[Actual_Duct_Press_No_2],0)
and isnull(a.[Actual_Duct_Press_No_1],0)=isnull(b.[Actual_Duct_Press_No_1],0)
and isnull(a.[Actual_volume],0)=isnull(b.[Actual_volume],0)
and isnull(a.[VSD_No_2_Speed_Control],0)=isnull(b.[VSD_No_2_Speed_Control],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[Rm_Press_No_2]=b.[Rm_Press_No_2]
      ,a.[Rm_Press_No_1]=b.[Rm_Press_No_1]
      ,a.[VSD_No_1_Speed_Control_]=b.[VSD_No_1_Speed_Control_]
      ,a.[VSD_Speed_Control_Output]=b.[VSD_Speed_Control_Output]
      ,a.[Actual_Duct_Press_No_2]=b.[Actual_Duct_Press_No_2]
      ,a.[Actual_Duct_Press_No_1]=b.[Actual_Duct_Press_No_1]
      ,a.[Actual_volume]=b.[Actual_volume]
      ,a.[VSD_No_2_Speed_Control]=b.[VSD_No_2_Speed_Control]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[Rm_Press_No_2]
      ,[Rm_Press_No_1]
      ,[VSD_No_1_Speed_Control_]
      ,[VSD_Speed_Control_Output]
      ,[Actual_Duct_Press_No_2]
      ,[Actual_Duct_Press_No_1]
      ,[Actual_volume]
      ,[VSD_No_2_Speed_Control]
) 
VALUES (b.[ReadingTime]
      ,b.[Rm_Press_No_2]
      ,b.[Rm_Press_No_1]
      ,b.[VSD_No_1_Speed_Control_]
      ,b.[VSD_Speed_Control_Output]
      ,b.[Actual_Duct_Press_No_2]
      ,b.[Actual_Duct_Press_No_1]
      ,b.[Actual_volume]
      ,b.[VSD_No_2_Speed_Control]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_5Downflow_booth]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_5Downflow_booth 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_5Downflow_booth]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_5Downflow_booth]',  @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_5Downflow_booth'') drop table ##MTrend__n1_osp3_5Annex_5Downflow_booth
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_5Downflow_booth FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_5Downflow_booth'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_5Downflow_booth') drop table ##MTrend__n1_osp3_5Annex_5Downflow_booth
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_5Downflow_booth 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_5Downflow_booth')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_5Downflow_booth] a 
USING ##MTrend__n1_osp3_5Annex_5Downflow_booth b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[A759_TE_34_R],0)=isnull(b.[A759_TE_34_R],0)
and isnull(a.[A725_TE_34_R],0)=isnull(b.[A725_TE_34_R],0)
and isnull(a.[TE_76034],0)=isnull(b.[TE_76034],0)
and isnull(a.[A751_TE_34_R],0)=isnull(b.[A751_TE_34_R],0)
and isnull(a.[A750_TE_34_R],0)=isnull(b.[A750_TE_34_R],0)
and isnull(a.[A726_TE_34],0)=isnull(b.[A726_TE_34],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[A759_TE_34_R]=b.[A759_TE_34_R]
      ,a.[A725_TE_34_R]=b.[A725_TE_34_R]
      ,a.[TE_76034]=b.[TE_76034]
      ,a.[A751_TE_34_R]=b.[A751_TE_34_R]
      ,a.[A750_TE_34_R]=b.[A750_TE_34_R]
      ,a.[A726_TE_34]=b.[A726_TE_34]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[A759_TE_34_R]
      ,[A725_TE_34_R]
      ,[TE_76034]
      ,[A751_TE_34_R]
      ,[A750_TE_34_R]
      ,[A726_TE_34]
) 
VALUES (b.[ReadingTime]
      ,b.[A759_TE_34_R]
      ,b.[A725_TE_34_R]
      ,b.[TE_76034]
      ,b.[A751_TE_34_R]
      ,b.[A750_TE_34_R]
      ,b.[A726_TE_34]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_6GBN_801]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [energy_ecs_ahu].SP_Merge_ahu_MTrend__n1_osp3_5Annex_6GBN_801 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'


ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_ahu_MTrend__n1_osp3_5Annex_6GBN_801]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

declare @loadedRow as int
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)

declare @strsql nvarchar(max)=''

---------------------------------------------------------------------------------------------------------------------------------------------------------

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Merging data on [MTrend__n1_osp3_5Annex_6GBN_801]', @mysql_schema, @db_name, @mssql_schema, @log_id output

BEGIN TRY

IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)

set @strsql='
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG=''tempdb'' and TABLE_NAME = ''##MTrend__n1_osp3_5Annex_6GBN_801'') drop table ##MTrend__n1_osp3_5Annex_6GBN_801
SELECT distinct * INTO ##MTrend__n1_osp3_5Annex_6GBN_801 FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT * FROM ' + @mysql_schema + '.MTrend__n1_osp3_5Annex_6GBN_801'')'
EXEC sp_executesql @strsql;

SET @loadedRow = @@ROWCOUNT
set @strsql=''

/*
declare @insertedRow int, @updatedRow int;
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
declare @strsql nvarchar(max)=''
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##MTrend__n1_osp3_5Annex_6GBN_801') drop table ##MTrend__n1_osp3_5Annex_6GBN_801
SELECT distinct *
INTO ##MTrend__n1_osp3_5Annex_6GBN_801 
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT * FROM iot_energy_ecs_rng.MTrend__n1_osp3_5Annex_6GBN_801')
IF EXISTS(select TABLE_NAME from tempdb.information_schema.tables where TABLE_CATALOG='tempdb' and TABLE_NAME = '##tableVar') drop table ##tableVar
create table ##tableVar(MergeAction VARCHAR(20), InsertedID datetime2, DeletedID datetime2)
*/

set @strsql='
MERGE ' + @mssql_schema + '.[MTrend__n1_osp3_5Annex_6GBN_801] a 
USING ##MTrend__n1_osp3_5Annex_6GBN_801 b
ON ( a.[ReadingTime]=b.[ReadingTime]
and isnull(a.[GBN_801_Airflow],0)=isnull(b.[GBN_801_Airflow],0)
and isnull(a.[GBN_802_Run_Signal],0)=isnull(b.[GBN_802_Run_Signal],0)
and isnull(a.[GBM_802_Run_Signal],0)=isnull(b.[GBM_802_Run_Signal],0)
and isnull(a.[GBN_801_Fan_Enable],0)=isnull(b.[GBN_801_Fan_Enable],0)
and isnull(a.[Fan_Enable],0)=isnull(b.[Fan_Enable],0)
)
WHEN MATCHED THEN 
UPDATE SET
      a.[ReadingTime]=b.[ReadingTime]
      ,a.[GBN_801_Airflow]=b.[GBN_801_Airflow]
      ,a.[GBN_802_Run_Signal]=b.[GBN_802_Run_Signal]
      ,a.[GBM_802_Run_Signal]=b.[GBM_802_Run_Signal]
      ,a.[GBN_801_Fan_Enable]=b.[GBN_801_Fan_Enable]
      ,a.[Fan_Enable]=b.[Fan_Enable]
WHEN NOT MATCHED BY TARGET THEN 
INSERT ([ReadingTime]
      ,[GBN_801_Airflow]
      ,[GBN_802_Run_Signal]
      ,[GBM_802_Run_Signal]
      ,[GBN_801_Fan_Enable]
      ,[Fan_Enable]
) 
VALUES (b.[ReadingTime]
      ,b.[GBN_801_Airflow]
      ,b.[GBN_802_Run_Signal]
      ,b.[GBM_802_Run_Signal]
      ,b.[GBN_801_Fan_Enable]
      ,b.[Fan_Enable]
) OUTPUT
      $action, inserted.ReadingTime ''inserted'', deleted.ReadingTime ''deleted'' INTO ##tableVar
;'

--print @strsql

EXEC sp_executesql @strsql;

SET @insertedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='INSERT');

SET @updatedRow = (select x.row_no
					from (SELECT MergeAction, COUNT(*) as row_no
						  FROM ##tableVar GROUP BY MergeAction) x
					where MergeAction='UPDATE');

--print 'inserted: ' + cast(isnull(@insertedRow,0) as varchar)

--print 'updated: ' + cast(@updatedRow as varchar)

END TRY  
BEGIN CATCH  
	set @errMsg = error_message()
	set @errNo = error_number()
END CATCH;

if isnull(@errNo,0) <> 0
begin 

	-- close the log 
	set @message = 'Merging failed.'
	set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage
end

if isnull(@errNo,0) = 0 -- closing merge
begin 
	set @logmessage = 'Merging completed.'

	update energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
	set loaded=isnull(@loadedRow,0)
	,inserted=isnull(@insertedRow,0)
	,updated=isnull(@updatedRow,0)
	where ID = @log_id;

	exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @logmessage

end
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_Energy_ECS_AHU_All_Tables]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- select * from energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
-- delete from energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs;

-- exec [energy_ecs_ahu].SP_Merge_Energy_ECS_AHU_All_Tables 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_Energy_ECS_AHU_All_Tables]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS

BEGIN

declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @strsql nvarchar(max)=''

exec energy_ecs_ahu.[SP_Merge_StartLog] 'Start merging data on Energy_ECS_AHU:', @mysql_schema, @db_name, @mssql_schema, 0

set @strsql= @mssql_schema + '.SP_Merge_ahu_Alarms ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_AuditTrail ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MapEvents ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MapStatus ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MemoryStatus ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_1A_B801_MCC ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_2A801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_3B801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_4C_D801_MCC ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_5C801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_6D801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_1GBA_B_C_D_7A_B_C_D_Temps ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_1E_G801_MCC ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_2E801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_3G801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_5H801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_6K801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_2GBE_G_H_K_7E_G_H_K_Temp_RH ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_1L_M801_MCC ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_2L801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_3M801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_4Q_J801_MCC ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_5Q801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_6J801_Remote ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_7L_M_Q_J_Temp ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_3GBL_M_Q_J_8l_M801_Pressure ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_1F801_MCC ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_2B839_MCC ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_17_Hydrog_EX_Fans ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_3B839_Temp_Control ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_5C_D_G802 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_6Chiller ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_4GBF_GB839_8New_MCC_Extract_System ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_4Extract ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_5Downflow_booth ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_6GBN_801 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_007_UC3224 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_008_UC3216 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_013_UC328 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''


set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_0501 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''


set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_0502 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''


set @strsql= @mssql_schema + '.SP_Merge_ahu_MTrend__n1_osp3_5Annex_0503 ' + '''' + @mysql_schema + '''' + ', ' + '''' +  @db_name + '''' + ', ' + '''' + @mssql_schema + ''''
EXEC sp_executesql @strsql;
set @strsql=''

exec energy_ecs_ahu.[SP_Merge_StartLog] 'End merging data on Energy_ECS_AHU.', @mysql_schema, @db_name, @mssql_schema, 0


END;
GO
/****** Object:  StoredProcedure [energy_ecs_ahu].[SP_Merge_Energy_ECS_AHU_Main]    Script Date: 3/8/2020 10:31:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- EXEC [energy_ecs_ahu].[SP_Merge_Energy_ECS_AHU_Main] 'iot_energy_ecs_rng', 'IOT_ETL_ENERGY_ECS', 'energy_ecs_ahu'

-- select * from energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs
-- delete from energy_ecs_ahu.IOT_ETL_Energy_ECS_Logs;

ALTER PROCEDURE [energy_ecs_ahu].[SP_Merge_Energy_ECS_AHU_Main]
(
@mysql_schema varchar(100) --= 'iot_energy_ecs_rng'
, @db_name varchar(100) --= 'IOT_ETL_ENERGY_ECS'
, @mssql_schema varchar(100) --= 'energy_ecs_ahu'
)
AS
BEGIN

declare @STRSQL nvarchar(max)
declare @insertedRow int, @updatedRow int;
declare @log_id as int
declare @logmessage nvarchar(max)
declare @errMsg as nvarchar(max)
declare @errNo as bigint
declare @message varchar(500)
declare @subjectContent varchar(150)
declare @row_count as int
/*
declare @mysql_schema varchar(100) = 'iot_energy_ecs_rng'
declare @db_name varchar(100) = 'IOT_ETL_ENERGY_ECS'
declare @mssql_schema varchar(100) = 'energy_ecs_ahu'
*/

	exec energy_ecs_ahu.[SP_Merge_StartLog] 'Checking table structures', @mysql_schema, @db_name, @mssql_schema, @log_id output

	BEGIN TRY
		/*
		-- declare @row_count as int
		SELECT @row_count=count(*)
		-- SELECT table_name, column_name
		FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT table_name, column_name FROM information_schema.columns WHERE table_schema=''iot_energy_ecs_rng''') a
		WHERE NOT EXISTS (SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.columns b 
						  WHERE TABLE_CATALOG='IOT_ETL_ENERGY_ECS' and TABLE_SCHEMA='energy_ecs_ahu' 
						  and b.TABLE_NAME=a.table_name and b.COLUMN_NAME=a.column_name);
		-- select @row_count
		*/

		SET @STRSQL = 'select *
		FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", ''SELECT table_name, column_name FROM information_schema.columns WHERE table_schema=''''' + @mysql_schema + ''''''') a
		WHERE NOT EXISTS (SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.columns b 
						  WHERE TABLE_CATALOG=''' + @db_name + ''' and TABLE_SCHEMA=''' + @mssql_schema + ''' 
						  and b.TABLE_NAME=a.table_name and b.COLUMN_NAME=a.column_name);'

		PRINT @STRSQL

		EXEC sp_executesql @STRSQL;

		SET @row_count=@@ROWCOUNT

	END TRY  
	BEGIN CATCH  
		set @errMsg = error_message()
		set @errNo = error_number()
	END CATCH;

	if isnull(@errNo,0) <> 0 and @row_count <> 0
	begin 

		-- close the log 
		set @message = 'Checking table structures failed or different table structure.'
		set @logmessage =  cast(@errNo as varchar) + ': ' + @errMsg
		exec energy_ecs_ahu.[SP_Merge_EndLog] @log_id, @message, @logmessage

		print 'failed'
		--send email notice here

	end

	if isnull(@errNo,0) = 0 and @row_count = 0 -- closing merge
	begin 
		set @logmessage = 'Checking table structure completed: '

		exec [energy_ecs_ahu].[SP_Merge_EndLog] @log_id, @logmessage

		exec [energy_ecs_ahu].[SP_Merge_Energy_ECS_AHU_All_Tables] @mysql_schema, @db_name, @mssql_schema

	end
END;

GO
