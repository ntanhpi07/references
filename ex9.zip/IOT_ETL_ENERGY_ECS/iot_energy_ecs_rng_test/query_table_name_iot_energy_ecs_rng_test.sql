-- mysql

-- SELECT table_name FROM information_schema.tables WHERE table_schema='iot_energy_ecs_rng';

-- sqlserver

SELECT [name] FROM  SYSOBJECTS
WHERE xtype = 'U';

select *
FROM OPENQUERY("MYSQL_DBLINK_ENERGY_DEV", 'SELECT table_name FROM information_schema.tables WHERE table_schema=''iot_energy_ecs_rng''')